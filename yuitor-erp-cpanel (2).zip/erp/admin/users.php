<?php
require_once __DIR__ . '/../includes/auth.php';
send_security_headers();
$user = require_role('admin');
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $act = $_POST['act'] ?? '';
    if ($act === 'create_user') {
        $role = in_array($_POST['role'] ?? '', ['admin','teacher','student','parent','staff'], true) ? $_POST['role'] : 'staff';
        $fullName = trim($_POST['full_name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $branchId = !empty($_POST['branch_id']) ? (int)$_POST['branch_id'] : null;
        $pass = (string)($_POST['password'] ?? '');
        if ($fullName === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($pass) < 6) {
            flash_set('error', 'Name, valid email, and minimum 6-char password required.');
        } else {
            try {
                $hash = password_hash($pass, PASSWORD_DEFAULT);
                $pdo->prepare("INSERT INTO users (branch_id, role, full_name, email, phone, password_hash, is_active) VALUES (?, ?, ?, ?, ?, ?, 1)")
                    ->execute([$branchId, $role, $fullName, $email, $phone, $hash]);
                $newUid = (int)$pdo->lastInsertId();
                audit_log('user_created', 'users', $newUid, "Role {$role} Email {$email}");
                if (!empty($_POST['send_welcome'])) {
                    $loginUrl = 'https://' . ($_SERVER['HTTP_HOST'] ?? 'yuitor.com') . erp_url('index.php');
                    send_welcome_email($email, $fullName, $role, $loginUrl, $pass);
                }
                flash_set('success', 'User account created and welcome notification processed.');
            } catch (Throwable $e) {
                flash_set('error', 'Could not create user (email may already exist).');
            }
        }
    } elseif ($act === 'toggle_status') {
        $uid = (int)$_POST['id'];
        if ($uid !== (int)$user['id']) {
            $pdo->prepare("UPDATE users SET is_active = 1 - is_active WHERE id = ?")->execute([$uid]);
            audit_log('user_status_toggled', 'users', $uid, 'Toggled active status');
            flash_set('success', 'User status updated.');
        }
    } elseif ($act === 'assign_teacher_batch') {
        $tUid = (int)$_POST['teacher_user_id'];
        $bId = (int)$_POST['batch_id'];
        $subj = trim($_POST['subject'] ?? 'All Subjects');
        $pdo->prepare("INSERT IGNORE INTO teacher_batches (teacher_user_id, batch_id, subject) VALUES (?, ?, ?)")->execute([$tUid, $bId, $subj]);
        audit_log('teacher_batch_assigned', 'teacher_batches', $tUid, "Batch {$bId} ({$subj})");
        flash_set('success', 'Batch assigned to Teacher.');
    } elseif ($act === 'remove_teacher_batch') {
        $pdo->prepare("DELETE FROM teacher_batches WHERE id = ?")->execute([(int)$_POST['id']]);
        flash_set('success', 'Teacher batch assignment removed.');
    } elseif ($act === 'link_parent_student') {
        $pUid = (int)$_POST['parent_user_id'];
        $stId = (int)$_POST['student_id'];
        $rel = trim($_POST['relation'] ?? 'Guardian');
        $pdo->prepare("INSERT IGNORE INTO parent_students (parent_user_id, student_id, relation) VALUES (?, ?, ?)")->execute([$pUid, $stId, $rel]);
        flash_set('success', 'Parent linked to student.');
    }
    redirect_to('admin/users.php');
}

$branches = $pdo->query("SELECT id, code, name FROM branches WHERE deleted_at IS NULL")->fetchAll();
$users = $pdo->query("SELECT u.*, b.name AS branch_name FROM users u LEFT JOIN branches b ON b.id = u.branch_id WHERE u.deleted_at IS NULL ORDER BY u.id DESC")->fetchAll();
$teachers = array_filter($users, function($x){ return $x['role']==='teacher'; });
$parents = array_filter($users, function($x){ return $x['role']==='parent'; });
$batches = $pdo->query("SELECT ba.id, ba.name, b.code FROM batches ba JOIN branches b ON b.id = ba.branch_id WHERE ba.deleted_at IS NULL")->fetchAll();
$studentsList = $pdo->query("SELECT s.id, s.admission_no, u.full_name FROM students s JOIN users u ON u.id = s.user_id WHERE s.deleted_at IS NULL ORDER BY u.full_name")->fetchAll();
$tbMap = $pdo->query("SELECT tb.*, u.full_name AS teacher_name, ba.name AS batch_name FROM teacher_batches tb JOIN users u ON u.id = tb.teacher_user_id JOIN batches ba ON ba.id = tb.batch_id")->fetchAll();

$pageTitle = 'Users, Teachers & Access Control';
$showPanelSidebar = true;
include __DIR__ . '/../includes/site_header.php';
include __DIR__ . '/../includes/panel_nav.php';
?>
<div class="yu-page-head">
  <div><h1>Users, Faculty Access &amp; Parent Links</h1><p>Create accounts with branded welcome emails, assign teacher batches &amp; link parents.</p></div>
</div>

<div class="yu-card">
  <div class="yu-card-title">Create User Account</div>
  <form method="post">
    <?php echo csrf_field(); ?><input type="hidden" name="act" value="create_user">
    <div class="yu-form-row">
      <div class="yu-field"><label>Role</label><select name="role"><option value="teacher">Teacher (Faculty)</option><option value="staff">Operations / Branch Staff</option><option value="parent">Parent / Guardian</option><option value="admin">Admin</option></select></div>
      <div class="yu-field"><label>Full Name</label><input type="text" name="full_name" required></div>
      <div class="yu-field"><label>Email</label><input type="email" name="email" required></div>
      <div class="yu-field"><label>Phone</label><input type="text" name="phone"></div>
      <div class="yu-field"><label>Branch</label><select name="branch_id"><option value="">All / HQ</option><?php foreach($branches as $b): ?><option value="<?php echo (int)$b['id']; ?>"><?php echo e($b['code'].' - '.$b['name']); ?></option><?php endforeach; ?></select></div>
      <div class="yu-field"><label>Initial Password</label><input type="password" name="password" minlength="6" required></div>
    </div>
    <label style="font-size:13px;display:flex;gap:8px;align-items:center;margin-bottom:12px;"><input type="checkbox" name="send_welcome" value="1" checked> Send branded Welcome Email with full name from No-reply@yuitor.com</label>
    <button class="yu-btn yu-btn-primary yu-btn-sm" type="submit">Create User</button>
  </form>
</div>

<div class="yu-grid-2">
  <div class="yu-card">
    <div class="yu-card-title">Assign Batch to Teacher</div>
    <form method="post">
      <?php echo csrf_field(); ?><input type="hidden" name="act" value="assign_teacher_batch">
      <div class="yu-form-row">
        <div class="yu-field"><label>Teacher</label><select name="teacher_user_id"><?php foreach($teachers as $t): ?><option value="<?php echo (int)$t['id']; ?>"><?php echo e($t['full_name']); ?></option><?php endforeach; ?></select></div>
        <div class="yu-field"><label>Batch</label><select name="batch_id"><?php foreach($batches as $b): ?><option value="<?php echo (int)$b['id']; ?>"><?php echo e($b['code'].' - '.$b['name']); ?></option><?php endforeach; ?></select></div>
        <div class="yu-field"><label>Subject</label><input type="text" name="subject" value="All Subjects"></div>
      </div>
      <button class="yu-btn yu-btn-teal yu-btn-sm" type="submit">Assign Batch</button>
    </form>
    <div class="yu-table-wrap" style="margin-top:12px;"><table class="yu-table">
      <tr><th>Teacher</th><th>Batch</th><th>Subject</th><th></th></tr>
      <?php foreach ($tbMap as $m): ?>
        <tr>
          <td><?php echo e($m['teacher_name']); ?></td><td><?php echo e($m['batch_name']); ?></td><td><?php echo e($m['subject']); ?></td>
          <td><form method="post" style="margin:0;"><?php echo csrf_field(); ?><input type="hidden" name="act" value="remove_teacher_batch"><input type="hidden" name="id" value="<?php echo (int)$m['id']; ?>"><button class="yu-btn yu-btn-outline yu-btn-sm" type="submit">Remove</button></form></td>
        </tr>
      <?php endforeach; ?>
    </table></div>
  </div>

  <div class="yu-card">
    <div class="yu-card-title">Link Parent to Student</div>
    <form method="post">
      <?php echo csrf_field(); ?><input type="hidden" name="act" value="link_parent_student">
      <div class="yu-form-row">
        <div class="yu-field"><label>Parent User</label><select name="parent_user_id"><?php foreach($parents as $p): ?><option value="<?php echo (int)$p['id']; ?>"><?php echo e($p['full_name'].' ('.$p['email'].')'); ?></option><?php endforeach; ?></select></div>
        <div class="yu-field"><label>Student</label><select name="student_id"><?php foreach($studentsList as $st): ?><option value="<?php echo (int)$st['id']; ?>"><?php echo e($st['admission_no'].' - '.$st['full_name']); ?></option><?php endforeach; ?></select></div>
        <div class="yu-field"><label>Relation</label><input type="text" name="relation" value="Parent"></div>
      </div>
      <button class="yu-btn yu-btn-teal yu-btn-sm" type="submit">Link Parent</button>
    </form>
  </div>
</div>

<div class="yu-card">
  <div class="yu-card-title">All Registered System Users</div>
  <div class="yu-table-wrap"><table class="yu-table">
    <tr><th>Name</th><th>Role</th><th>Email</th><th>Branch</th><th>Status</th><th>Action</th></tr>
    <?php foreach ($users as $row): ?>
      <tr>
        <td><strong><?php echo e($row['full_name']); ?></strong></td>
        <td><?php echo e(strtoupper($row['role'])); ?></td>
        <td><?php echo e($row['email']); ?></td>
        <td><?php echo e($row['branch_name'] ?: 'All Branches'); ?></td>
        <td><?php echo (int)$row['is_active']===1 ? '<span class="yu-status-text st-ok">Active</span>' : '<span class="yu-status-text st-bad">Disabled</span>'; ?></td>
        <td>
          <?php if ((int)$row['id'] !== (int)$user['id']): ?>
            <form method="post" style="margin:0;"><?php echo csrf_field(); ?><input type="hidden" name="act" value="toggle_status"><input type="hidden" name="id" value="<?php echo (int)$row['id']; ?>"><button class="yu-btn yu-btn-outline yu-btn-sm" type="submit"><?php echo (int)$row['is_active']===1 ? 'Disable' : 'Enable'; ?></button></form>
          <?php else: ?>--<?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
  </table></div>
</div>
<?php include __DIR__ . '/../includes/site_footer.php'; ?>
