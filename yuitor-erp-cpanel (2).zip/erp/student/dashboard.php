<?php
require_once __DIR__ . '/../includes/auth.php';
send_security_headers();
$user = require_role('student');
$pdo = db();
$st = current_student_record($user['id']);
if (!$st) { die('Student profile not linked.'); }

$attTot = (int)$pdo->query("SELECT COUNT(*) FROM attendance WHERE student_id = " . (int)$st['id'])->fetchColumn();
$attPres = (int)$pdo->query("SELECT COUNT(*) FROM attendance WHERE student_id = " . (int)$st['id'] . " AND status IN ('present','late')")->fetchColumn();
$attPct = $attTot > 0 ? round(($attPres / $attTot) * 100, 1) : 100;

$feeAcc = $pdo->query("SELECT * FROM student_fee_accounts WHERE student_id = " . (int)$st['id'] . " ORDER BY id DESC LIMIT 1")->fetch();
$due = $feeAcc ? max(0, (float)$feeAcc['net_amount'] - (float)$feeAcc['paid_amount']) : 0;

$tt = $pdo->prepare("SELECT * FROM timetable WHERE batch_id = ? ORDER BY FIELD(day_of_week,'Mon','Tue','Wed','Thu','Fri','Sat','Sun'), start_time");
$tt->execute([(int)$st['batch_id']]);
$slots = $tt->fetchAll();

$notices = $pdo->prepare("SELECT * FROM notices WHERE deleted_at IS NULL AND (batch_id = ? OR audience IN ('all','students')) ORDER BY id DESC LIMIT 5");
$notices->execute([(int)$st['batch_id']]);
$noticeRows = $notices->fetchAll();

$pageTitle = 'Student Dashboard';
$showPanelSidebar = true;
include __DIR__ . '/../includes/site_header.php';
include __DIR__ . '/../includes/panel_nav.php';
?>
<div class="yu-page-head">
  <div><h1>Welcome, <?php echo e($user['full_name']); ?></h1><p>Admission #: <strong><?php echo e($st['admission_no']); ?></strong> &bull; <?php echo e($st['branch_name'].' / '.$st['batch_name']); ?></p></div>
  <a href="<?php echo e(erp_url('student/id_card.php')); ?>" class="yu-btn yu-btn-teal yu-btn-sm"><?php echo yu_icon('qr', 14); ?> My QR ID Card</a>
</div>
<div class="yu-kpi-grid">
  <div class="yu-kpi">
    <div class="yu-kpi-head"><div class="yu-kpi-label">Attendance</div><span class="yu-kpi-ico"><?php echo yu_icon('attendance', 17); ?></span></div>
    <div class="yu-kpi-val"><?php echo $attPct; ?>%</div>
    <div class="yu-kpi-sub"><?php echo $attPres; ?> / <?php echo $attTot; ?> classes</div>
  </div>
  <div class="yu-kpi">
    <div class="yu-kpi-head"><div class="yu-kpi-label">Fee Balance Due</div><span class="yu-kpi-ico teal"><?php echo yu_icon('fees', 17); ?></span></div>
    <div class="yu-kpi-val"><?php echo format_inr($due); ?></div>
    <div class="yu-kpi-sub"><a href="<?php echo e(erp_url('student/fees.php')); ?>">Pay via UPI &rarr;</a></div>
  </div>
  <div class="yu-kpi">
    <div class="yu-kpi-head"><div class="yu-kpi-label">Course</div><span class="yu-kpi-ico"><?php echo yu_icon('graduation', 17); ?></span></div>
    <div class="yu-kpi-val" style="font-size:17px;"><?php echo e($st['course_title']); ?></div>
  </div>
</div>
<div class="yu-grid-2">
  <div class="yu-card">
    <div class="yu-card-title">My Batch Timetable</div>
    <div class="yu-table-wrap"><table class="yu-table">
      <tr><th>Day</th><th>Timing</th><th>Subject</th><th>Room</th></tr>
      <?php foreach($slots as $sl): ?>
        <tr><td><strong><?php echo e($sl['day_of_week']); ?></strong></td><td><?php echo e($sl['start_time'].' - '.$sl['end_time']); ?></td><td><?php echo e($sl['subject']); ?></td><td><?php echo e($sl['room']); ?></td></tr>
      <?php endforeach; ?>
    </table></div>
  </div>
  <div class="yu-card">
    <div class="yu-card-title">Notices &amp; Announcements</div>
    <?php foreach($noticeRows as $n): ?>
      <div style="padding:10px 0;border-bottom:1px solid #ebf1f6;"><strong><?php echo e($n['title']); ?></strong><div style="font-size:13px;color:#475569;"><?php echo e($n['body']); ?></div></div>
    <?php endforeach; ?>
  </div>
</div>
<?php include __DIR__ . '/../includes/site_footer.php'; ?>
