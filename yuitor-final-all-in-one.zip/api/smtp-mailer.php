<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/erp/config/demo_defaults.php';

function yu_smtp_configuration(): array
{
    if (!extension_loaded('openssl') || !function_exists('stream_socket_client')) {
        throw new RuntimeException('PHP OpenSSL and stream-socket support are required for SMTP.');
    }

    $host = trim(yu_private_setting('YU_SMTP_HOST', yu_env('SMTP_HOST', '')));
    $port = (int) yu_private_setting('YU_SMTP_PORT', yu_env('SMTP_PORT', '587'));
    $username = yu_private_setting('YU_SMTP_USERNAME', yu_env('SMTP_USER', ''));
    $password = yu_private_setting('YU_SMTP_PASSWORD', yu_env('SMTP_PASS', ''));
    $encryption = strtolower(trim(yu_private_setting('YU_SMTP_ENCRYPTION', yu_env('SMTP_SECURE', 'tls'))));
    $rawFrom = trim(yu_private_setting('YU_SMTP_FROM', yu_env('MAIL_FROM_EMAIL', 'No-reply@yuitor.com')));
    $fromEmail = yu_normalize_sender_email($rawFrom);
    $fromName = trim(yu_private_setting('YU_SMTP_FROM_NAME', yu_env('MAIL_FROM_NAME', 'Yuitor Smart Classes')));

    if ($host === '' || preg_match('/[\r\n\/\x00]/', $host)) {
        throw new RuntimeException('SMTP host is not configured.');
    }
    if ($port < 1 || $port > 65535) {
        throw new RuntimeException('SMTP port is invalid.');
    }
    $isLocal = in_array(strtolower($host), ['127.0.0.1', 'localhost', '::1'], true);
    if (!$isLocal && ($username === '' || $password === '')) {
        throw new RuntimeException('SMTP credentials are not configured.');
    }
    if (!in_array($encryption, array('tls', 'ssl', 'none'), true)) {
        throw new RuntimeException('SMTP encryption must be TLS, SSL, or none.');
    }
    if (!filter_var($fromEmail, FILTER_VALIDATE_EMAIL)) {
        throw new RuntimeException('SMTP sender email is invalid.');
    }

    return array(
        'host'       => $host,
        'port'       => $port,
        'username'   => $username,
        'password'   => $password,
        'encryption' => $encryption,
        'from_email' => $fromEmail,
        'from_name'  => $fromName !== '' ? $fromName : 'Yuitor Smart Classes',
        'is_local'   => $isLocal,
    );
}

function yu_smtp_read_response($socket, array $expectedCodes): string
{
    $response = '';
    $code = 0;
    $lineCount = 0;
    do {
        $line = fgets($socket, 2048);
        if ($line === false) {
            throw new RuntimeException('SMTP server closed the connection unexpectedly.');
        }
        $response .= $line;
        $lineCount++;
        if ($lineCount > 50) {
            throw new RuntimeException('SMTP server returned an invalid response.');
        }
        if (preg_match('/^([0-9]{3})([ -])/', $line, $matches) !== 1) {
            throw new RuntimeException('SMTP server returned an invalid response.');
        }
        $code = (int) $matches[1];
        $continuation = $matches[2] === '-';
    } while ($continuation);

    if (!in_array($code, $expectedCodes, true)) {
        throw new RuntimeException('SMTP server rejected a delivery command with status ' . $code . '.');
    }
    return $response;
}

function yu_smtp_write_all($socket, string $data): void
{
    $length = strlen($data);
    $offset = 0;
    while ($offset < $length) {
        $written = fwrite($socket, substr($data, $offset));
        if ($written === false || $written === 0) {
            throw new RuntimeException('Could not send data to the SMTP server.');
        }
        $offset += $written;
    }
}

function yu_smtp_command($socket, string $command, array $expectedCodes): string
{
    yu_smtp_write_all($socket, $command . "\r\n");
    return yu_smtp_read_response($socket, $expectedCodes);
}

function yu_smtp_send_message(string $recipient, string $subject, string $body): void
{
    $config = yu_smtp_configuration();
    $transport = $config['encryption'] === 'ssl' ? 'ssl' : 'tcp';
    $endpoint = $transport . '://' . $config['host'] . ':' . $config['port'];
    $context = stream_context_create(array(
        'ssl' => array(
            'verify_peer'      => !$config['is_local'],
            'verify_peer_name' => !$config['is_local'],
            'peer_name'        => $config['host'],
            'SNI_enabled'      => true,
        ),
    ));
    $socket = @stream_socket_client(
        $endpoint,
        $errorNumber,
        $errorMessage,
        12,
        STREAM_CLIENT_CONNECT,
        $context
    );
    if ($socket === false) {
        throw new RuntimeException('Could not connect to the configured SMTP server.');
    }
    stream_set_timeout($socket, 12);
    try {
        yu_smtp_read_response($socket, array(220));
        yu_smtp_command($socket, 'EHLO ' . YU_MAIL_DOMAIN, array(250));
        if ($config['encryption'] === 'tls') {
            yu_smtp_command($socket, 'STARTTLS', array(220));
            $cryptoEnabled = @stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT);
            if ($cryptoEnabled !== true) {
                throw new RuntimeException('Could not establish TLS with the SMTP server.');
            }
            yu_smtp_command($socket, 'EHLO ' . YU_MAIL_DOMAIN, array(250));
        }
        if ($config['username'] !== '' && $config['password'] !== '') {
            yu_smtp_command($socket, 'AUTH LOGIN', array(334));
            yu_smtp_command($socket, base64_encode($config['username']), array(334));
            yu_smtp_command($socket, base64_encode($config['password']), array(235));
        }
        yu_smtp_command($socket, 'MAIL FROM:<' . $config['from_email'] . '>', array(250));
        yu_smtp_command($socket, 'RCPT TO:<' . $recipient . '>', array(250, 251));
        yu_smtp_command($socket, 'DATA', array(354));

        $cleanSubject = str_replace(array("\r", "\n"), ' ', $subject);
        $encodedSubject = '=?UTF-8?B?' . base64_encode($cleanSubject) . '?=';
        $encodedName = '=?UTF-8?B?' . base64_encode($config['from_name']) . '?=';
        $messageId = bin2hex(random_bytes(12)) . '@' . YU_MAIL_DOMAIN;
        $encodedBody = chunk_split(base64_encode(str_replace(array("\r\n", "\r"), "\n", $body)), 76, "\r\n");

        $message = array(
            'Date: ' . gmdate('D, d M Y H:i:s') . ' +0000',
            'From: ' . $encodedName . ' <' . $config['from_email'] . '>',
            'Sender: ' . $config['from_email'],
            'Return-Path: <' . $config['from_email'] . '>',
            'Reply-To: ' . $config['from_email'],
            'To: <' . $recipient . '>',
            'Subject: ' . $encodedSubject,
            'Message-ID: <' . $messageId . '>',
            'MIME-Version: 1.0',
            'Content-Type: text/plain; charset=UTF-8',
            'Content-Transfer-Encoding: base64',
            '',
            rtrim($encodedBody, "\r\n"),
            '.',
        );
        yu_smtp_write_all($socket, implode("\r\n", $message) . "\r\n");
        yu_smtp_read_response($socket, array(250));
        yu_smtp_command($socket, 'QUIT', array(221));
    } finally {
        fclose($socket);
    }
}
