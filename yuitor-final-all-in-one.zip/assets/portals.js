(() => {
  "use strict";
  // Legacy portal shell neutralized: Student, Teacher, and Restricted Admin portals
  // run on dedicated, server-enforced PHP MySQL endpoints (/student/*, /teacher/*).
})();
