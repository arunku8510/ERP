<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/fee_helpers.php';
send_security_headers();
$user = require_role('admin');
$pdo = db();

if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    csv_download_headers('yuitor_students_' . date('Ymd') . '.csv');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['Admission No', 'Full Name', 'Email', 'Phone', 'Branch', 'Course', 'Batch', 'Father Name', 'Status', 'Admission Date']);
    $rows = $pdo->query("SELECT s.admission_no, u.full_name, u.email, u.phone, b.name AS branch_name, c.title AS course_title, ba.name AS batch_name, s.father_name, s.status, s.admission_date
                         FROM students s JOIN users u ON u.id=s.user_id JOIN branches b ON b.id=s.branch_id JOIN courses c ON c.id=s.course_id JOIN batches ba ON ba.id=s.batch_id
                         WHERE s.deleted_at IS NULL ORDER BY s.id DESC")->fetchAll();
    foreach ($rows as $r) fputcsv($out, $r);
    fclose($out);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $act = $_POST['act'] ?? '';
    if ($act === 'add_student') {
        $fullName = trim($_POST['full_name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $branchId = (int)$_POST['branch_id'];
        $courseId = (int)$_POST['course_id'];
        $batchId = (int)$_POST['batch_id'];
        $sessId = current_academic_session_id();
        $pass = (string)($_POST['password'] ?? 'Yuitor@1234');
        $feeTotal = (float)($_POST['total_fee'] ?? 0);
        $disc = (float)($_POST['discount'] ?? 0);
        try {
            $pdo->beginTransaction();
            $hash = password_hash($pass, PASSWORD_DEFAULT);
            $pdo->prepare("INSERT INTO users (branch_id, role, full_name, email, phone, password_hash, is_active) VALUES (?, 'student', ?, ?, ?, ?, 1)")
                ->execute([$branchId, $fullName, $email, $phone, $hash]);
            $uId = (int)$pdo->lastInsertId();
            $bSt = $pdo->prepare("SELECT code FROM branches WHERE id = ?"); $bSt->execute([$branchId]); $bCode = (string)($bSt->fetchColumn() ?: 'YS01');
            $admNo = $bCode . '-ADM-' . date('y') . '-' . sprintf('%04d', random_int(100, 9999));
            $qr = bin2hex(random_bytes(16));
            $pdo->prepare("INSERT INTO students (user_id, branch_id, session_id, course_id, batch_id, admission_no, roll_no, father_name, guardian_phone, address, qr_token, admission_date, status)
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURDATE(), 'active')")
                ->execute([$uId, $branchId, $sessId, $courseId, $batchId, $admNo, trim($_POST['roll_no'] ?? ''), trim($_POST['father_name'] ?? ''), trim($_POST['guardian_phone'] ?? $phone), trim($_POST['address'] ?? ''), $qr]);
            $stId = (int)$pdo->lastInsertId();
            $pdo->commit();
            if ($feeTotal > 0) {
                allocate_student_fee_account($stId, $branchId, $sessId, $feeTotal, $disc, 'Admission Allocation', 3);
            }
            $loginUrl = 'https://' . ($_SERVER['HTTP_HOST'] ?? 'yuitor.com') . erp_url('index.php');
            send_welcome_email($email, $fullName, 'student', $loginUrl, $pass);
            audit_log('student_admitted', 'students', $stId, "Admission {$admNo} - {$fullName}");
            flash_set('success', "Student admitted ({$admNo}) and welcome email sent.");
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            error_log('Student admit error: ' . $e->getMessage());
            flash_set('error', 'Error admitting student. Check if email already exists.');
        }
    } elseif ($act === 'transfer_student') {
        $stId = (int)$_POST['student_id'];
        $toBranch = (int)$_POST['to_branch_id'];
        $toBatch = (int)$_POST['to_batch_id'];
        $reason = trim($_POST['reason'] ?? 'Batch/Branch Transfer');
        $cur = $pdo->prepare("SELECT branch_id, batch_id, user_id FROM students WHERE id = ?");
        $cur->execute([$stId]);
        $sRow = $cur->fetch();
        if ($sRow) {
            $pdo->prepare("INSERT INTO student_transfers (student_id, from_branch_id, to_branch_id, from_batch_id, to_batch_id, reason, transferred_by) VALUES (?, ?, ?, ?, ?, ?, ?)")
                ->execute([$stId, $sRow['branch_id'], $toBranch, $sRow['batch_id'], $toBatch, $reason, $user['id']]);
            $pdo->prepare("UPDATE students SET branch_id = ?, batch_id = ? WHERE id = ?")->execute([$toBranch, $toBatch, $stId]);
            $pdo->prepare("UPDATE users SET branch_id = ? WHERE id = ?")->execute([$toBranch, $sRow['user_id']]);
            audit_log('student_transferred', 'students', $stId, "To Branch {$toBranch} Batch {$toBatch}");
            flash_set('success', 'Student transferred and transfer history logged.');
        }
    } elseif ($act === 'soft_delete') {
        $stId = (int)$_POST['id'];
        $pdo->prepare("UPDATE students SET deleted_at = NOW(), status='dropped' WHERE id = ?")->execute([$stId]);
        audit_log('student_archived', 'students', $stId, 'Soft deleted student');
        flash_set('success', 'Student moved to archive.');
    } elseif ($act === 'restore') {
        $stId = (int)$_POST['id'];
        $pdo->prepare("UPDATE students SET deleted_at = NULL, status='active' WHERE id = ?")->execute([$stId]);
        audit_log('student_restored', 'students', $stId, 'Restored student');
        flash_set('success', 'Student restored.');
    }
    redirect_to('admin/students.php');
}

$q = trim((string)($_GET['q'] ?? ''));
$where = "WHERE 1=1";
$params = [];
if ($q !== '') {
    $where .= " AND (u.full_name LIKE ? OR s.admission_no LIKE ? OR u.email LIKE ?)";
    $like = '%' . $q . '%';
    $params = [$like, $like, $like];
}
$stStmt = $pdo->prepare("SELECT s.*, u.full_name, u.email, u.phone, b.name AS branch_name, ba.name AS batch_name, c.title AS course_title
                         FROM students s JOIN users u ON u.id=s.user_id JOIN branches b ON b.id=s.branch_id JOIN batches ba ON ba.id=s.batch_id JOIN courses c ON c.id=s.course_id
                         {$where} ORDER BY s.deleted_at IS NOT NULL, s.id DESC LIMIT 100");
$stStmt->execute($params);
$students = $stStmt->fetchAll();

$branches = $pdo->query("SELECT id, code, name FROM branches WHERE deleted_at IS NULL")->fetchAll();
$courses = $pdo->query("SELECT id, title, default_fee FROM courses WHERE deleted_at IS NULL")->fetchAll();
$batches = $pdo->query("SELECT id, name FROM batches WHERE deleted_at IS NULL")->fetchAll();

$pageTitle = 'Students, Admissions & Transfers';
$showPanelSidebar = true;
$pageNoIndex = true;
$portalMode = 'admin';
include __DIR__ . '/../includes/site_header.php';
include __DIR__ . '/../includes/panel_nav.php';
?>
<div class="yu-page-head">
  <div><h1>Students &amp; Admissions</h1><p>Admit students, transfer branches/batches with history, or export UTF-8 CSV.</p></div>
  <div style="display:flex;gap:8px;flex-wrap:wrap;">
    <a href="?export=csv" class="yu-btn yu-btn-outline yu-btn-sm">Export CSV</a>
  </div>
</div>

<div class="yu-grid-2">
  <div class="yu-card">
    <div class="yu-card-title">New Student Admission</div>
    <form method="post">
      <?php echo csrf_field(); ?><input type="hidden" name="act" value="add_student">
      <div class="yu-form-row">
        <div class="yu-field"><label>Full Name</label><input type="text" name="full_name" required></div>
        <div class="yu-field"><label>Email</label><input type="email" name="email" required></div>
        <div class="yu-field"><label>Phone</label><input type="text" name="phone" required></div>
      </div>
      <div class="yu-form-row">
        <div class="yu-field"><label>Branch</label><select name="branch_id"><?php foreach($branches as $b): ?><option value="<?php echo (int)$b['id']; ?>"><?php echo e($b['code'].' - '.$b['name']); ?></option><?php endforeach; ?></select></div>
        <div class="yu-field"><label>Course</label><select name="course_id"><?php foreach($courses as $c): ?><option value="<?php echo (int)$c['id']; ?>"><?php echo e($c['title']); ?></option><?php endforeach; ?></select></div>
        <div class="yu-field"><label>Batch</label><select name="batch_id"><?php foreach($batches as $ba): ?><option value="<?php echo (int)$ba['id']; ?>"><?php echo e($ba['name']); ?></option><?php endforeach; ?></select></div>
      </div>
      <div class="yu-form-row">
        <div class="yu-field"><label>Father Name</label><input type="text" name="father_name"></div>
        <div class="yu-field"><label>Total Fee (Rs.)</label><input type="number" step="0.01" name="total_fee" value="18000"></div>
        <div class="yu-field"><label>Discount (Rs.)</label><input type="number" step="0.01" name="discount" value="0"></div>
        <div class="yu-field"><label>Portal Password</label><input type="text" name="password" value="Yuitor@1234"></div>
      </div>
      <button class="yu-btn yu-btn-primary yu-btn-sm" type="submit">Admit Student</button>
    </form>
  </div>

  <div class="yu-card">
    <div class="yu-card-title">Transfer Student Batch / Branch</div>
    <form method="post">
      <?php echo csrf_field(); ?><input type="hidden" name="act" value="transfer_student">
      <div class="yu-field" style="margin-bottom:10px;"><label>Select Student</label>
        <select name="student_id"><?php foreach($students as $st): if($st['deleted_at']) continue; ?><option value="<?php echo (int)$st['id']; ?>"><?php echo e($st['admission_no'].' - '.$st['full_name'].' ('.$st['batch_name'].')'); ?></option><?php endforeach; ?></select>
      </div>
      <div class="yu-form-row">
        <div class="yu-field"><label>New Branch</label><select name="to_branch_id"><?php foreach($branches as $b): ?><option value="<?php echo (int)$b['id']; ?>"><?php echo e($b['name']); ?></option><?php endforeach; ?></select></div>
        <div class="yu-field"><label>New Batch</label><select name="to_batch_id"><?php foreach($batches as $ba): ?><option value="<?php echo (int)$ba['id']; ?>"><?php echo e($ba['name']); ?></option><?php endforeach; ?></select></div>
      </div>
      <div class="yu-field" style="margin-bottom:12px;"><label>Reason</label><input type="text" name="reason" placeholder="Timing change / branch relocation"></div>
      <button class="yu-btn yu-btn-teal yu-btn-sm" type="submit">Transfer &amp; Log History</button>
    </form>
  </div>
</div>

<div class="yu-card">
  <div class="yu-card-title">
    <span>Student Directory</span>
    <form method="get" style="display:flex;gap:6px;"><input type="search" name="q" value="<?php echo e($q); ?>" placeholder="Filter name or adm no..." style="padding:6px 10px;border:1px solid #cbd9e6;border-radius:8px;font-size:13px;"><button class="yu-btn yu-btn-outline yu-btn-sm" type="submit">Filter</button></form>
  </div>
  <div class="yu-table-wrap"><table class="yu-table">
    <tr><th>Adm No</th><th>Student</th><th>Branch / Batch</th><th>Phone</th><th>Status</th><th>Actions</th></tr>
    <?php foreach ($students as $st): ?>
      <tr>
        <td><strong><?php echo e($st['admission_no']); ?></strong></td>
        <td><?php echo e($st['full_name']); ?><div style="font-size:12px;color:#64748b;"><?php echo e($st['email']); ?></div></td>
        <td><?php echo e($st['branch_name']); ?><div style="font-size:12px;color:#0b7b82;"><?php echo e($st['batch_name']); ?></div></td>
        <td><?php echo e($st['phone']); ?></td>
        <td><?php echo $st['deleted_at'] ? '<span class="yu-status-text st-muted">Archived</span>' : '<span class="yu-status-text st-ok">'.e(ucfirst($st['status'])).'</span>'; ?></td>
        <td style="white-space:nowrap;">
          <a class="yu-btn yu-btn-outline yu-btn-sm" href="<?php echo e(erp_url('student/id_card.php?student_id='.(int)$st['id'])); ?>" target="_blank">ID Card</a>
          <form method="post" style="display:inline;">
            <?php echo csrf_field(); ?><input type="hidden" name="id" value="<?php echo (int)$st['id']; ?>">
            <input type="hidden" name="act" value="<?php echo $st['deleted_at'] ? 'restore' : 'soft_delete'; ?>">
            <button class="yu-btn yu-btn-outline yu-btn-sm" type="submit"><?php echo $st['deleted_at'] ? 'Restore' : 'Archive'; ?></button>
          </form>
        </td>
      </tr>
    <?php endforeach; ?>
  </table></div>
</div>
<?php include __DIR__ . '/../includes/site_footer.php'; ?>
