<?php
require_once __DIR__ . '/includes/auth.php';
send_security_headers();
start_secure_session();

$portal = strtolower(trim((string) ($_GET['portal'] ?? ($_POST['portal'] ?? 'student'))));
$gate = trim((string) ($_GET['gate'] ?? ($_POST['gate'] ?? '')));
$isAdminGate = ($gate !== '' && hash_equals(yu_admin_login_slug(), $gate));
if ($isAdminGate) {
    send_noindex_headers();
    $portal = 'admin';
} elseif (!in_array($portal, ['student', 'teacher', 'parent'], true)) {
    $portal = 'student';
}

$backUrl = $portal === 'teacher'
    ? '/teacher/login.php'
    : ($portal === 'parent'
        ? '/erp/parent/login.php'
        : ($isAdminGate ? yu_admin_login_url() : '/student/login.php'));

$step = $_GET['step'] ?? 'request';
$msg = '';
$err = '';
$emailVal = trim((string) ($_POST['email'] ?? ($_GET['email'] ?? '')));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? 'request';
    $pdo = db();
    $ip = client_ip();

    if ($action === 'request') {
        $email = strtolower(trim((string) ($_POST['email'] ?? '')));
        $emailVal = $email;
        if (!check_rate_limit($pdo, 'forgot_pw', $ip, 5, 15, true)) {
            $err = 'Too many password reset requests. Please try again in 15 minutes.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $err = 'Please enter a valid email address.';
        } else {
            if ($isAdminGate) {
                $stmt = $pdo->prepare("SELECT id, full_name, email, is_active FROM users WHERE email = ? AND role IN ('admin', 'staff') AND deleted_at IS NULL LIMIT 1");
            } else {
                $stmt = $pdo->prepare("SELECT id, full_name, email, is_active FROM users WHERE email = ? AND role = ? AND deleted_at IS NULL LIMIT 1");
            }
            $isAdminGate ? $stmt->execute([$email]) : $stmt->execute([$email, $portal]);
            $u = $stmt->fetch();
            if ($u && (int) $u['is_active'] === 1) {
                $otp = generate_6digit_otp((int) $u['id'], 'password_reset', 15);
                $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://';
                $host = !empty($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : YU_MAIL_DOMAIN;
                $qs = $isAdminGate ? ('gate=' . urlencode($gate)) : ('portal=' . urlencode($portal));
                $resetUrl = $scheme . $host . erp_url('forgot-password.php?step=reset&' . $qs . '&email=' . urlencode($email));
                send_forgot_password_email($u['email'], $u['full_name'], $otp, $resetUrl);
                audit_log('password_reset_requested', 'users', (int) $u['id'], '6-digit reset OTP dispatched', (int) $u['id']);
            }
            $msg = 'If an active ' . e($portal) . ' account matches that email, a 6-digit reset OTP has been sent from ' . YU_MAIL_FROM_EMAIL . '.';
            $step = 'reset';
        }
    } elseif ($action === 'reset') {
        $step = 'reset';
        $email = strtolower(trim((string) ($_POST['email'] ?? '')));
        $code = trim((string) ($_POST['otp_code'] ?? ''));
        $pw1 = (string) ($_POST['new_password'] ?? '');
        $pw2 = (string) ($_POST['confirm_password'] ?? '');

        if (!check_rate_limit($pdo, 'forgot_pw_verify', $ip . '|' . $email, 6, 15, true)) {
            $err = 'Too many failed reset attempts. Request a new OTP after 15 minutes.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $err = 'Invalid email address.';
        } elseif (strlen($pw1) < 8 || $pw1 !== $pw2) {
            $err = 'Password must be at least 8 characters and match confirmation.';
        } else {
            if ($isAdminGate) {
                $stmt = $pdo->prepare("SELECT id, full_name, email FROM users WHERE email = ? AND role IN ('admin', 'staff') AND is_active = 1 AND deleted_at IS NULL LIMIT 1");
                $stmt->execute([$email]);
            } else {
                $stmt = $pdo->prepare("SELECT id, full_name, email FROM users WHERE email = ? AND role = ? AND is_active = 1 AND deleted_at IS NULL LIMIT 1");
                $stmt->execute([$email, $portal]);
            }
            $u = $stmt->fetch();
            if (!$u || !verify_6digit_otp((int) $u['id'], 'password_reset', $code)) {
                $err = 'Invalid or expired 6-digit reset OTP code.';
            } else {
                $hash = password_hash($pw1, PASSWORD_DEFAULT);
                $pdo->prepare("UPDATE users SET password_hash = ?, failed_attempts = 0, locked_until = NULL WHERE id = ?")
                    ->execute([$hash, (int) $u['id']]);
                audit_log('password_reset_completed', 'users', (int) $u['id'], 'Password updated via 6-digit OTP', (int) $u['id']);
                flash_set('success', 'Your password has been updated. Sign in with your new password.');
                redirect_to($backUrl);
            }
        }
    }
}

$pageTitle = 'Forgot Password';
$pageNoIndex = $isAdminGate;
$portalMode = $portal;
$showPanelSidebar = false;
include __DIR__ . '/includes/site_header.php';
$brandLogo = get_setting('institute_logo', '/erp/assets/images/yuitor-smart-classes-logo.png');
?>
<div style="max-width:480px;margin:24px auto;">
  <div class="yu-card">
    <div style="display:flex;align-items:center;gap:12px;margin-bottom:10px;">
      <div style="width:46px;height:46px;border-radius:50%;background:#eef6fa;border:1.5px solid #bfe3eb;padding:3px;flex-shrink:0;overflow:hidden;">
        <img src="<?php echo e($brandLogo); ?>" alt="Yuitor Smart Classes" style="width:100%;height:100%;object-fit:contain;border-radius:50%;">
      </div>
      <div>
        <div style="font-size:11px;font-weight:700;color:#0b7b82;text-transform:uppercase;letter-spacing:.08em;display:flex;align-items:center;gap:5px;"><?php echo yu_icon('lock', 13); ?> <?php echo e(($isAdminGate ? 'Console' : ucfirst($portal))); ?> Account Recovery</div>
        <h1 style="margin:2px 0 0;font-family:'Manrope',sans-serif;font-size:22px;">Reset Your Password</h1>
      </div>
    </div>
    <p style="margin:0 0 16px;font-size:13.5px;color:#52687c;">We send a 6-digit reset code with your registered name from <code><?php echo e(YU_MAIL_FROM_EMAIL); ?></code>.</p>
    <?php if ($msg !== ''): ?><div class="yu-alert yu-alert-success" style="display:flex;align-items:center;gap:8px;"><?php echo yu_icon('check', 16); ?> <span><?php echo e($msg); ?></span></div><?php endif; ?>
    <?php if ($err !== ''): ?><div class="yu-alert yu-alert-danger" style="display:flex;align-items:center;gap:8px;"><?php echo yu_icon('alert', 16); ?> <span><?php echo e($err); ?></span></div><?php endif; ?>

    <?php if ($step === 'request'): ?>
      <form method="post">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="action" value="request">
        <input type="hidden" name="portal" value="<?php echo e($portal); ?>">
        <?php if ($isAdminGate): ?><input type="hidden" name="gate" value="<?php echo e($gate); ?>"><?php endif; ?>
        <div class="yu-field" style="margin-bottom:14px;">
          <label for="fpEmail">Registered Email Address</label>
          <input id="fpEmail" type="email" name="email" required value="<?php echo e($emailVal); ?>" placeholder="Enter your email">
        </div>
        <button type="submit" class="yu-btn yu-btn-primary" style="width:100%;"><?php echo yu_icon('send', 15); ?> Send 6-Digit Reset OTP</button>
      </form>
    <?php else: ?>
      <form method="post">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="action" value="reset">
        <input type="hidden" name="portal" value="<?php echo e($portal); ?>">
        <?php if ($isAdminGate): ?><input type="hidden" name="gate" value="<?php echo e($gate); ?>"><?php endif; ?>
        <div class="yu-field" style="margin-bottom:12px;"><label>Email Address</label><input type="email" name="email" required value="<?php echo e($emailVal); ?>"></div>
        <div class="yu-field" style="margin-bottom:12px;"><label>6-Digit Reset OTP</label><input type="text" name="otp_code" maxlength="6" pattern="\d{6}" required placeholder="000000"></div>
        <div class="yu-field" style="margin-bottom:12px;"><label>New Password (min 8 chars)</label><input type="password" name="new_password" minlength="8" required></div>
        <div class="yu-field" style="margin-bottom:14px;"><label>Confirm New Password</label><input type="password" name="confirm_password" minlength="8" required></div>
        <button type="submit" class="yu-btn yu-btn-primary" style="width:100%;"><?php echo yu_icon('check', 15); ?> Update Password</button>
      </form>
    <?php endif; ?>

    <div style="margin-top:14px;text-align:center;">
      <a href="<?php echo e($backUrl); ?>" style="font-size:13px;color:#2563eb;font-weight:600;text-decoration:none;">&larr; Back to <?php echo e(($isAdminGate ? 'Console' : ucfirst($portal))); ?> Sign In</a>
    </div>
  </div>
</div>
<?php include __DIR__ . '/includes/site_footer.php'; ?>
