<?php
// Yuitor Coaching ERP - PDO Database Singleton & Core Settings
require_once __DIR__ . '/../config/security.php';

$dbCfg = __DIR__ . '/../config/database.php';
$appCfg = __DIR__ . '/../config/app.php';
if (!file_exists($dbCfg) || !file_exists($appCfg)) {
    if (strpos($_SERVER['REQUEST_URI'] ?? '', '/install/') === false) {
        header('Location: /erp/install/install.php');
        exit;
    }
} else {
    require_once $appCfg;
    require_once $dbCfg;
}

function db() {
    static $pdo = null;
    if ($pdo !== null) {
        return $pdo;
    }
    if (!defined('DB_HOST') || !defined('DB_NAME') || !defined('DB_USER')) {
        throw new RuntimeException('Database configuration is missing. Run /erp/install/install.php first.');
    }
    $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
    $opts = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ];
    $pdo = new PDO($dsn, DB_USER, DB_PASS, $opts);
    return $pdo;
}

function load_settings($force = false) {
    static $cache = null;
    if ($cache !== null && !$force) {
        return $cache;
    }
    $cache = [];
    try {
        $stmt = db()->query("SELECT setting_key, setting_value, is_encrypted FROM settings");
        foreach ($stmt->fetchAll() as $row) {
            $val = (string)($row['setting_value'] ?? '');
            if ((int)$row['is_encrypted'] === 1 && $val !== '') {
                $val = decrypt_secret($val);
            }
            $cache[$row['setting_key']] = $val;
        }
    } catch (Throwable $ex) {
        // Fallback during install
    }
    return $cache;
}

function get_setting($key, $default = '') {
    $all = load_settings();
    return isset($all[$key]) && $all[$key] !== '' ? $all[$key] : $default;
}

function save_setting($key, $value, $encrypt = false) {
    $stored = $encrypt ? encrypt_secret($value) : (string)$value;
    $sql = "INSERT INTO settings (setting_key, setting_value, is_encrypted) VALUES (?, ?, ?)
            ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), is_encrypted = VALUES(is_encrypted)";
    db()->prepare($sql)->execute([$key, $stored, $encrypt ? 1 : 0]);
    load_settings(true);
}

function audit_log($action, $entityType = '', $entityId = null, $details = '', $userId = null) {
    try {
        if ($userId === null && !empty($_SESSION['user_id'])) {
            $userId = (int)$_SESSION['user_id'];
        }
        $stmt = db()->prepare("INSERT INTO audit_logs (user_id, action, entity_type, entity_id, details, ip_address) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $userId,
            substr((string)$action, 0, 80),
            substr((string)$entityType, 0, 60),
            $entityId !== null ? (int)$entityId : null,
            (string)$details,
            client_ip()
        ]);
    } catch (Throwable $e) {
        // Silent fail so audit never crashes primary workflow
    }
}

function next_receipt_no($branchCode = 'YS01') {
    $year = date('Y');
    $prefix = preg_replace('/[^A-Z0-9]/', '', strtoupper((string)$branchCode));
    if ($prefix === '') $prefix = 'YS01';
    $pattern = $prefix . '-' . $year . '-%';
    $stmt = db()->prepare("SELECT receipt_no FROM fee_payments WHERE receipt_no LIKE ? ORDER BY id DESC LIMIT 1");
    $stmt->execute([$pattern]);
    $last = $stmt->fetchColumn();
    $seq = 1;
    if ($last && preg_match('/-(\d+)$/', $last, $m)) {
        $seq = (int)$m[1] + 1;
    }
    return sprintf('%s-%s-%04d', $prefix, $year, $seq);
}
