<?php
require_once __DIR__ . '/../includes/auth.php';
send_security_headers();
$user = require_role('student');
$st = current_student_record($user['id']);
$rows = db()->prepare("SELECT * FROM attendance WHERE student_id = ? ORDER BY att_date DESC LIMIT 90");
$rows->execute([(int)$st['id']]);
$list = $rows->fetchAll();

$pageTitle = 'My Attendance';
$showPanelSidebar = true;
include __DIR__ . '/../includes/site_header.php';
include __DIR__ . '/../includes/panel_nav.php';
?>
<div class="yu-page-head"><div><h1>My Attendance History</h1></div></div>
<div class="yu-card">
  <div class="yu-table-wrap"><table class="yu-table">
    <tr><th>Date</th><th>Status</th><th>Mode</th><th>Remarks</th></tr>
    <?php foreach($list as $r): ?>
      <tr>
        <td><?php echo e($r['att_date']); ?></td>
        <td><span class="yu-status-text <?php echo $r['status']==='present'?'st-ok':($r['status']==='absent'?'st-bad':'st-warn'); ?>"><?php echo e(ucfirst($r['status'])); ?></span></td>
        <td><?php echo e(strtoupper($r['mode'])); ?></td>
        <td><?php echo e($r['remarks']); ?></td>
      </tr>
    <?php endforeach; ?>
  </table></div>
</div>
<?php include __DIR__ . '/../includes/site_footer.php'; ?>
