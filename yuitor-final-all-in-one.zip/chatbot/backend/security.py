"""Pre-answer security layer and ban-list enforcement."""
from __future__ import annotations

import re
import unicodedata

REFUSAL_MESSAGE = "Maaf kijiye, yeh jaankari share nahi ki sakti."

# Normalized exact / phrase triggers (English, Hinglish & Hindi Devanagari)
BAN_PHRASES: tuple[str, ...] = (
    # Admin & credentials
    "admin panel",
    "admin login",
    "admin url",
    "admin link",
    "admin gate",
    "admin password",
    "admin email",
    "admin phone",
    "admin dashboard",
    "admin portal",
    "console gate",
    "console url",
    "yt-ctrl",
    "ctrl_desk",
    "root password",
    "superuser",
    "wp-admin",
    "phpmyadmin",
    "cpanel login",
    "cpanel password",
    "ftp password",
    "ssh key",
    "api key",
    "apikey",
    "api token",
    "auth token",
    "access token",
    "bearer token",
    "jwt token",
    "secret key",
    "app_key",
    "smtp_pass",
    "db_pass",
    "credentials",
    "login credentials",
    "otp code",
    "2fa code",
    "pin number",
    "atm pin",
    "एडमिन पैनल",
    "एडमिन लॉगिन",
    "एडमिन पासवर्ड",
    "पासवर्ड",
    "सीक्रेट की",
    "एपीआई की",
    "ओटीपी बताओ",
    # Database, server, backend, source code, system prompt, internal docs
    "database dump",
    "database schema",
    "database password",
    "sql query",
    "show tables",
    "select * from",
    "drop table",
    "sqlite file",
    "mysql password",
    "server ip",
    "server logs",
    "php error log",
    "php_error.log",
    "error_log",
    "hidden instructions",
    "internal config",
    "backend/main.py",
    "backend/engine.py",
    "backend/security.py",
    "marks of ",
    "स्टूडेंट के मार्क्स",
    "अटेंडेंस दिखाओ",
    ".env file",
    "env file",
    "htaccess",
    "source code",
    "backend code",
    "system prompt",
    "system instructions",
    "hidden prompt",
    "developer prompt",
    "internal document",
    "confidential file",
    "confidential document",
    "private config",
    "ban list",
    "banlist",
    "security rules",
    "डेटाबेस",
    "सोर्स कोड",
    "सिस्टम प्रॉम्प्ट",
    "बैकएंड कोड",
    "गोपनीय दस्तावेज",
    "नियम दिखाओ",
    # Personal data, salaries, bank/card details, personal phone numbers
    "student data",
    "student list",
    "student database",
    "student phone",
    "student mobile",
    "student number",
    "student address",
    "student marks",
    "student attendance",
    "student email",
    "customer data",
    "customer list",
    "staff salary",
    "teacher salary",
    "faculty salary",
    "salaries",
    "payroll",
    "bank account",
    "account number",
    "ifsc code",
    "credit card",
    "debit card",
    "card number",
    "cvv",
    "upi pin",
    "owner personal",
    "owner number",
    "owner phone",
    "owner ka personal",
    "staff personal",
    "teacher personal",
    "personal mobile",
    "personal phone",
    "ghar ka address",
    "home address of",
    "aadhaar number",
    "aadhar number",
    "pan number",
    "स्टूडेंट डेटा",
    "स्टूडेंट लिस्ट",
    "स्टूडेंट का नंबर",
    "पर्सनल नंबर",
    "सैलरी",
    "वेतन",
    "बैंक अकाउंट",
    "कार्ड नंबर",
    "क्रेडिट कार्ड",
    "डेबिट कार्ड",
    "आधार नंबर",
    # Prompt injection / jailbreaks
    "ignore previous instructions",
    "ignore all previous",
    "ignore your instructions",
    "ignore all instructions",
    "ignore your rules",
    "forget previous instructions",
    "forget your rules",
    "forget all rules",
    "disregard previous",
    "disregard instructions",
    "override instructions",
    "override your prompt",
    "bypass security",
    "bypass filter",
    "act as admin",
    "act as administrator",
    "act as root",
    "act as developer",
    "pretend to be admin",
    "developer mode",
    "jailbreak",
    "dan mode",
    "do anything now",
    "reveal your rules",
    "reveal your prompt",
    "reveal instructions",
    "show your prompt",
    "print your prompt",
    "repeat your instructions",
    "what are your system",
    "pichli instructions",
    "pichle rules",
    "purane rules bhool",
    "naye rules maano",
    "rules tod do",
    "admin ban jao",
    "developer mode on",
    "system prompt batao",
    "instructions dikhao",
    "rules dikhao",
    "पिछले निर्देश भूल जाओ",
    "सारे नियम भूल जाओ",
    "एडमिन बन जाओ",
    "डेवलपर मोड",
)

# Regex patterns catching broader variations & obfuscated phrasing
BAN_REGEXES: tuple[re.Pattern[str], ...] = (
    re.compile(r"\b(?:admin|administrator|sysadmin)\b.{0,30}\b(?:panel|login|url|link|pass|password|id|user|email|gate|slug|route|portal|page|dashboard)\b", re.I),
    re.compile(r"\b(?:panel|login|url|link|pass|password|slug|route)\b.{0,30}\b(?:admin|administrator)\b", re.I),
    re.compile(r"\b(?:password|passcode|otp|2fa|pin|api[_\s-]?key|secret[_\s-]?key|token|credentials?)\b.{0,30}\b(?:kya|what|give|show|batao|bata|tell|share|leak|send|nikalo|chahiye|do|de)\b", re.I),
    re.compile(r"\b(?:give|show|tell|share|batao|bata|dikhao|de|nikalo|print|dump|export|leak)\b.{0,35}\b(?:password|passcode|otp|pin|api[_\s-]?key|secret|token|credentials?|database|schema|source\s*code|system\s*prompt|env|\.env|salaries?|salary|bank\s*account|card\s*number|cvv|personal\s*(?:number|phone|mobile|email|data)|student\s*(?:list|data|phone|number|marks|attendance|email|address))\b", re.I),
    re.compile(r"\b(?:salary|salaries|payroll|vetan|tankhwah)\b", re.I),
    re.compile(r"\b(?:cvv|credit\s*card|debit\s*card|atm\s*pin|bank\s*account\s*no|account\s*number|ifsc)\b", re.I),
    re.compile(r"\b(?:source\s*code|backend\s*(?:code|file|/)|system\s*prompt|hidden\s*(?:prompt|instructions?)|internal\s*(?:doc|document|documents|config|file|files|notes?)|confidential|php_error\.log|error\.log)\b", re.I),
    re.compile(r"\b(?:marks\s+of|attendance\s+(?:of|record)|how\s+much\s+fee\s+did)\b", re.I),
    re.compile(r"\b(?:database|mysql|sqlite|postgres|mongodb)\b.{0,30}\b(?:dump|table|schema|query|user|pass|host|file|access|connect|show|batao|dikhao|list)\b", re.I),
    re.compile(r"\b(?:ignore|forget|disregard|bypass|override|skip|break|tod)\b.{0,30}\b(?:instruction|rule|prompt|security|filter|guideline|policy|limit|niyam|nirdesh)\b", re.I),
    re.compile(r"\b(?:act|behave|pretend|switch|become|ban)\b.{0,20}\b(?:admin|root|developer|sudo|unrestricted|jailbreak|dan)\b", re.I),
    re.compile(r"\b(?:student|students|bachon|bachho|staff|teacher|teachers|faculty|owner|director|sir|mam|customer)\b.{0,30}\b(?:personal|private|ghar|home|phone|mobile|number|email|marks|result\s*sheet|attendance\s*record|fee\s*paid|aadhaar|aadhar|pan)\b", re.I),
    re.compile(r"\b(?:personal|private)\b.{0,20}\b(?:number|phone|mobile|contact|email|data|info|details)\b", re.I),
    re.compile(r"(?:SELECT\s+.+\s+FROM|UNION\s+SELECT|DROP\s+TABLE|OR\s+1\s*=\s*1|<\s*script)", re.I),
)


def normalize_for_security(text: str) -> str:
    """Normalize unicode, strip zero-width chars, collapse leetspeak & whitespace."""
    cleaned = unicodedata.normalize("NFKC", text or "")
    # Remove invisible zero-width formatting characters
    cleaned = re.sub(r"[\u200B-\u200F\u202A-\u202E\uFEFF]", "", cleaned)
    lowered = cleaned.lower()
    # Map common leetspeak tricks used in prompt injection
    leet = str.maketrans({"@": "a", "0": "o", "1": "i", "3": "e", "4": "a", "5": "s", "7": "t", "$": "s"})
    deleet = lowered.translate(leet)
    # Collapse repeated punctuation/spaces (e.g., a.d.m.i.n -> admin)
    collapsed = re.sub(r"(?<=\w)[.\-_*]+(?=\w)", "", lowered)
    return " ".join([lowered, deleet, collapsed])


def is_security_violation(message: str) -> tuple[bool, str]:
    """Return (True, reason) if message hits ban list or security rules."""
    raw = (message or "").strip()
    if not raw:
        return False, ""

    haystack = normalize_for_security(raw)
    # Also test space-stripped lowercase to defeat spaced-out keywords like "a d m i n"
    compact = re.sub(r"\s+", "", raw.lower())

    for phrase in BAN_PHRASES:
        if phrase in haystack:
            return True, f"ban_phrase:{phrase}"
        if len(phrase) >= 6 and " " in phrase and phrase.replace(" ", "") in compact:
            return True, f"ban_compact:{phrase}"

    for rx in BAN_REGEXES:
        if rx.search(raw) or rx.search(haystack):
            return True, f"ban_regex:{rx.pattern[:32]}"

    return False, ""
