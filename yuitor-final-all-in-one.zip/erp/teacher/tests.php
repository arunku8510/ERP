<?php
require_once __DIR__ . '/../includes/auth.php';
send_security_headers();
$user = require_role('teacher');
$pdo = db();

$batchIds = teacher_assigned_batch_ids($user['id']);
$ids = array_values(array_map('intval', $batchIds)); $ph = $ids ? implode(',', array_fill(0, count($ids), '?')) : '';
$batches = []; if ($ids) { $qb = $pdo->prepare("SELECT id, name FROM batches WHERE id IN ({$ph}) AND deleted_at IS NULL"); $qb->execute($ids); $batches = $qb->fetchAll(); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $act = $_POST['act'] ?? '';
    if ($act === 'create_test') {
        $bId = (int)$_POST['batch_id'];
        assert_teacher_batch_access($user['id'], $bId);
        $pdo->prepare("INSERT INTO batch_tests (batch_id, title, subject, test_date, max_marks, created_by) VALUES (?, ?, ?, ?, ?, ?)")
            ->execute([$bId, trim($_POST['title']), trim($_POST['subject']), $_POST['test_date'], (float)$_POST['max_marks'], $user['id']]);
        flash_set('success', 'Batch test created.');
    } elseif ($act === 'save_marks') {
        $testId = (int)$_POST['test_id'];
        $trSt = $pdo->prepare("SELECT batch_id FROM batch_tests WHERE id = ?"); $trSt->execute([$testId]); $tRow = $trSt->fetch();
        if ($tRow) {
            assert_teacher_batch_access($user['id'], $tRow['batch_id']);
            foreach (($_POST['marks'] ?? []) as $stId => $mk) {
                $abs = !empty($_POST['absent'][$stId]) ? 1 : 0;
                $pdo->prepare("INSERT INTO test_marks (test_id, student_id, marks_obtained, is_absent, updated_by) VALUES (?, ?, ?, ?, ?)
                               ON DUPLICATE KEY UPDATE marks_obtained = VALUES(marks_obtained), is_absent = VALUES(is_absent), updated_by = VALUES(updated_by)")
                    ->execute([$testId, (int)$stId, (float)$mk, $abs, $user['id']]);
            }
            flash_set('success', 'Test marks saved.');
        }
    }
    redirect_to('teacher/tests.php?test_id=' . (int)($_POST['test_id'] ?? 0));
}

$tests = []; if ($ids) { $qt = $pdo->prepare("SELECT t.*, ba.name AS batch_name FROM batch_tests t JOIN batches ba ON ba.id=t.batch_id WHERE t.batch_id IN ({$ph}) AND t.deleted_at IS NULL ORDER BY t.id DESC"); $qt->execute($ids); $tests = $qt->fetchAll(); }
$selTestId = isset($_GET['test_id']) ? (int)$_GET['test_id'] : (!empty($tests) ? (int)$tests[0]['id'] : 0);
$roster = [];
if ($selTestId) {
    $trQ = $pdo->prepare("SELECT * FROM batch_tests WHERE id = ?"); $trQ->execute([$selTestId]); $tr = $trQ->fetch();
    if ($tr) {
        assert_teacher_batch_access($user['id'], $tr['batch_id']);
        $st = $pdo->prepare("SELECT s.id, s.admission_no, u.full_name, tm.marks_obtained, tm.is_absent
                             FROM students s JOIN users u ON u.id=s.user_id
                             LEFT JOIN test_marks tm ON tm.test_id = ? AND tm.student_id = s.id
                             WHERE s.batch_id = ? AND s.deleted_at IS NULL AND s.status='active' ORDER BY u.full_name");
        $st->execute([$selTestId, $tr['batch_id']]);
        $roster = $st->fetchAll();
    }
}

$pageTitle = 'Batch Tests & Marks';
$showPanelSidebar = true;
$portalMode = 'teacher';
include __DIR__ . '/../includes/site_header.php';
include __DIR__ . '/../includes/panel_nav.php';
?>
<div class="yu-page-head"><div><h1>Batch Tests &amp; Marks Upload</h1></div></div>
<div class="yu-grid-2">
  <div class="yu-card">
    <div class="yu-card-title">Create Test</div>
    <form method="post">
      <?php echo csrf_field(); ?><input type="hidden" name="act" value="create_test">
      <div class="yu-form-row">
        <div class="yu-field"><label>Batch</label><select name="batch_id"><?php foreach($batches as $b): ?><option value="<?php echo (int)$b['id']; ?>"><?php echo e($b['name']); ?></option><?php endforeach; ?></select></div>
        <div class="yu-field"><label>Title</label><input type="text" name="title" required></div>
      </div>
      <div class="yu-form-row">
        <div class="yu-field"><label>Subject</label><input type="text" name="subject" value="Mathematics"></div>
        <div class="yu-field"><label>Date</label><input type="date" name="test_date" value="<?php echo date('Y-m-d'); ?>"></div>
        <div class="yu-field"><label>Max Marks</label><input type="number" step="0.5" name="max_marks" value="100"></div>
      </div>
      <button class="yu-btn yu-btn-primary yu-btn-sm" type="submit">Create Test</button>
    </form>
  </div>
  <div class="yu-card">
    <div class="yu-card-title">Select Test to Enter Marks</div>
    <form method="get" style="display:flex;gap:8px;">
      <select name="test_id" style="flex:1;padding:8px 10px;border:1px solid #cbd9e6;border-radius:8px;">
        <?php foreach($tests as $t): ?><option value="<?php echo (int)$t['id']; ?>" <?php echo $selTestId===(int)$t['id']?'selected':''; ?>><?php echo e($t['batch_name'].' - '.$t['title'].' ('.$t['test_date'].')'); ?></option><?php endforeach; ?>
      </select>
      <button class="yu-btn yu-btn-outline yu-btn-sm" type="submit">Load Roster</button>
    </form>
  </div>
</div>

<?php if ($selTestId && $roster): ?>
<div class="yu-card">
  <div class="yu-card-title">Enter Student Marks</div>
  <form method="post">
    <?php echo csrf_field(); ?><input type="hidden" name="act" value="save_marks"><input type="hidden" name="test_id" value="<?php echo $selTestId; ?>">
    <div class="yu-table-wrap"><table class="yu-table">
      <tr><th>Adm No</th><th>Student</th><th>Marks Obtained</th><th>Absent?</th></tr>
      <?php foreach($roster as $r): ?>
        <tr>
          <td><?php echo e($r['admission_no']); ?></td><td><strong><?php echo e($r['full_name']); ?></strong></td>
          <td><input type="number" step="0.5" name="marks[<?php echo (int)$r['id']; ?>]" value="<?php echo e($r['marks_obtained'] ?? '0'); ?>" style="width:100px;padding:6px;border:1px solid #cbd9e6;border-radius:8px;"></td>
          <td><input type="checkbox" name="absent[<?php echo (int)$r['id']; ?>]" value="1" <?php echo !empty($r['is_absent'])?'checked':''; ?>></td>
        </tr>
      <?php endforeach; ?>
    </table></div>
    <button class="yu-btn yu-btn-teal" style="margin-top:12px;" type="submit">Save Test Marks</button>
  </form>
</div>
<?php endif; ?>
<?php include __DIR__ . '/../includes/site_footer.php'; ?>
