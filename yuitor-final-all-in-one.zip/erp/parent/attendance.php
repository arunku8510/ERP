<?php
require_once __DIR__ . '/../includes/auth.php';
send_security_headers();
$user = require_role('parent');
$ids = parent_linked_student_ids($user['id']);
$stId = isset($_GET['student_id']) ? (int)$_GET['student_id'] : ($ids[0] ?? 0);
if ($stId) assert_student_access($user, $stId);

$rows = []; if ($stId) { $rSt = db()->prepare("SELECT * FROM attendance WHERE student_id = ? ORDER BY att_date DESC LIMIT 60"); $rSt->execute([$stId]); $rows = $rSt->fetchAll(); }
$pageTitle = 'Child Attendance Record';
$showPanelSidebar = true;
$portalMode = 'parent';
include __DIR__ . '/../includes/site_header.php';
include __DIR__ . '/../includes/panel_nav.php';
?>
<div class="yu-page-head"><div><h1>Child Attendance Record</h1></div></div>
<div class="yu-card">
  <div class="yu-table-wrap"><table class="yu-table">
    <tr><th>Date</th><th>Status</th><th>Mode</th><th>Remarks</th></tr>
    <?php foreach($rows as $r): ?>
      <tr><td><?php echo e($r['att_date']); ?></td><td><span class="yu-status-text <?php echo $r['status']==='present'?'st-ok':'st-bad'; ?>"><?php echo e(ucfirst($r['status'])); ?></span></td><td><?php echo e(strtoupper($r['mode'])); ?></td><td><?php echo e($r['remarks']); ?></td></tr>
    <?php endforeach; ?>
  </table></div>
</div>
<?php include __DIR__ . '/../includes/site_footer.php'; ?>
