<?php
require_once dirname(__DIR__) . '/erp/includes/auth.php';
send_security_headers();
start_secure_session();
$u = current_user();
if ($u && $u['role'] === 'teacher') {
    redirect_to('/erp/teacher/dashboard.php');
}
header('Location: /teacher/login.php');
exit;
