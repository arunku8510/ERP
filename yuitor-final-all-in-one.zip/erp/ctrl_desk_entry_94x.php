<?php
require_once __DIR__ . '/includes/auth.php';
send_security_headers();
send_noindex_headers();
start_secure_session();

$reqUri = (string) ($_SERVER['REQUEST_URI'] ?? '');
if (stripos($reqUri, 'ctrl_desk_entry_94x') !== false) {
    http_response_code(404);
    $code = 404;
    include __DIR__ . '/error.php';
    exit;
}
$providedSlug = trim((string) ($_GET['slug'] ?? ''));
$expectedSlug = yu_admin_login_slug();
if ($providedSlug === '' || !hash_equals($expectedSlug, $providedSlug)) {
    http_response_code(404);
    $code = 404;
    include __DIR__ . '/error.php';
    exit;
}

$existing = current_user();
if ($existing) {
    if (in_array($existing['role'], ['admin', 'staff'], true)) {
        redirect_to(role_home($existing['role']));
    }
    http_response_code(403);
    $code = 403;
    include __DIR__ . '/error.php';
    exit;
}

$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $email = strtolower(trim((string) ($_POST['email'] ?? '')));
    $pass = (string) ($_POST['password'] ?? '');
    $ip = client_ip();
    $pdo = db();

    if (($_SESSION['admin_login_fail_count'] ?? 0) >= 3) {
        $capAns = trim((string) ($_POST['captcha'] ?? ''));
        $capExp = (string) ($_SESSION['admin_captcha_expected'] ?? '');
        if ($capExp === '' || $capAns !== $capExp) {
            $err = 'Security verification sum is incorrect.';
        }
    }

    if ($err === '') {
        if (!check_rate_limit($pdo, 'admin_login_ip', $ip, 8, 15, false)) {
            $err = 'Too many failed attempts from this IP. Please try again in 15 minutes.';
        } elseif ($email === '' || $pass === '') {
            $err = 'Email and password are required.';
        } else {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? AND role IN ('admin', 'staff') AND deleted_at IS NULL LIMIT 1");
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if ($user && !empty($user['locked_until']) && strtotime($user['locked_until']) > time()) {
                $err = 'Account is temporarily locked due to repeated failed attempts.';
            } elseif (!$user || !password_verify($pass, $user['password_hash'])) {
                $_SESSION['admin_login_fail_count'] = (int) ($_SESSION['admin_login_fail_count'] ?? 0) + 1;
                check_rate_limit($pdo, 'admin_login_ip', $ip, 8, 15, true);
                if ($user) {
                    $fails = (int) $user['failed_attempts'] + 1;
                    $lock = $fails >= 5 ? date('Y-m-d H:i:s', time() + 900) : null;
                    $pdo->prepare("UPDATE users SET failed_attempts = ?, locked_until = ? WHERE id = ?")
                        ->execute([$fails, $lock, (int) $user['id']]);
                    audit_log('admin_login_failed', 'users', (int) $user['id'], 'Failed admin gate login attempt', (int) $user['id']);
                }
                $err = 'Invalid administrator credentials.';
            } elseif ((int) $user['is_active'] !== 1) {
                $err = 'This account is currently disabled.';
            } else {
                $_SESSION['admin_login_fail_count'] = 0;
                clear_rate_limit($pdo, 'admin_login_ip', $ip);
                $twoFaOn = get_setting('admin_2fa_enabled', '1') === '1';
                if ($user['role'] === 'admin' && ((int) $user['twofa_enabled'] === 1 || $twoFaOn)) {
                    $otp = generate_6digit_otp((int) $user['id'], 'admin_2fa', 10);
                    $otpDest = get_setting('admin_2fa_email', $user['email']);
                    if (!filter_var($otpDest, FILTER_VALIDATE_EMAIL)) {
                        $otpDest = $user['email'];
                    }
                    $_SESSION['pending_2fa_uid'] = (int) $user['id'];
                    $_SESSION['pending_2fa_email'] = $otpDest;
                    $_SESSION['pending_2fa_tries'] = 0;
                    $mailRes = send_otp_email($otpDest, $user['full_name'], $otp);
                    if (!$mailRes['ok']) {
                        $_SESSION['otp_mail_warn'] = 'OTP delivery notice: check server SMTP settings.';
                    }
                    redirect_to('verify-otp.php');
                }
                complete_user_login($user);
                redirect_to(role_home($user['role']));
            }
        }
    }
}

$needCaptcha = ($_SESSION['admin_login_fail_count'] ?? 0) >= 3;
if ($needCaptcha) {
    $a = random_int(2, 12);
    $b = random_int(2, 9);
    $_SESSION['admin_captcha_expected'] = $a + $b;
    $_SESSION['admin_captcha_q'] = $a . ' + ' . $b;
}

$pageTitle = 'Restricted Operations Console';
$pageNoIndex = true;
$portalMode = 'admin';
$showPanelSidebar = false;
include __DIR__ . '/includes/site_header.php';
$brandLogo = get_setting('institute_logo', '/erp/assets/images/yuitor-smart-classes-logo.png');
?>
<div style="max-width:460px;margin:28px auto;">
  <div class="yu-card">
    <div style="display:flex;align-items:center;gap:12px;margin-bottom:14px;">
      <div style="width:46px;height:46px;border-radius:50%;background:#eef6fa;border:1.5px solid #bfe3eb;padding:3px;flex-shrink:0;overflow:hidden;">
        <img src="<?php echo e($brandLogo); ?>" alt="Yuitor Smart Classes" style="width:100%;height:100%;object-fit:contain;border-radius:50%;">
      </div>
      <div>
        <div style="font-size:11px;font-weight:700;color:#0b7b82;text-transform:uppercase;letter-spacing:.08em;display:flex;align-items:center;gap:5px;"><?php echo yu_icon('shield', 13); ?> Authorized Access Only</div>
        <h1 style="margin:2px 0 0;font-family:'Manrope',sans-serif;font-size:21px;">Operations Console Sign In</h1>
      </div>
    </div>

    <?php echo render_flash(); ?>
    <?php if ($err !== ''): ?><div class="yu-alert yu-alert-danger"><?php echo e($err); ?></div><?php endif; ?>

    <form method="post">
      <?php echo csrf_field(); ?>
      <div class="yu-field" style="margin-bottom:12px;">
        <label for="gateEmail">Console Email</label>
        <input id="gateEmail" type="email" name="email" required autocomplete="username">
      </div>
      <div class="yu-field" style="margin-bottom:12px;">
        <label for="gatePass">Password</label>
        <input id="gatePass" type="password" name="password" required autocomplete="current-password">
      </div>
      <?php if ($needCaptcha): ?>
        <div class="yu-field" style="margin-bottom:12px;">
          <label for="gateCap">Security Check: What is <?php echo e($_SESSION['admin_captcha_q']); ?>?</label>
          <input id="gateCap" type="number" name="captcha" required>
        </div>
      <?php endif; ?>
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;font-size:13px;">
        <a href="<?php echo e(erp_url('forgot-password.php?gate=' . urlencode($expectedSlug))); ?>" style="color:#2563eb;font-weight:600;text-decoration:none;">Forgot Password?</a>
        <span style="color:#657b8e;font-size:12px;">2FA OTP Required</span>
      </div>
      <button type="submit" class="yu-btn yu-btn-primary" style="width:100%;padding:12px;"><?php echo yu_icon('shield', 16); ?> Sign In to Console</button>
    </form>
  </div>
</div>
<?php include __DIR__ . '/includes/site_footer.php'; ?>
