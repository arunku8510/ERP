<?php
// Yuitor Coaching ERP - Strict Security Configuration, Headers, Encryption & CSRF

require_once __DIR__ . '/demo_defaults.php';

@ini_set('display_errors', '0');
@ini_set('display_startup_errors', '0');
@ini_set('log_errors', '1');
$logDir = __DIR__ . '/../logs';
if (!is_dir($logDir)) {
    @mkdir($logDir, 0750, true);
}
@ini_set('error_log', $logDir . '/php_error.log');

if (strpos($_SERVER['SCRIPT_NAME'] ?? '', '/install/') === false) {
    set_exception_handler(function (Throwable $ex) use ($logDir) {
        $msg = '[' . date('Y-m-d H:i:s') . '] Uncaught ' . get_class($ex) . ': ' . $ex->getMessage() . ' in ' . $ex->getFile() . ':' . $ex->getLine() . "\n";
        @file_put_contents($logDir . '/php_error.log', $msg, FILE_APPEND);
        error_log($msg);
        if (!headers_sent()) {
            http_response_code(500);
            header('Content-Type: text/html; charset=UTF-8');
        }
        echo '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>500 - Temporary Error | Yuitor Smart Classes</title></head><body style="margin:0;background:#f5f9fc;font-family:Arial,sans-serif;color:#0f172a;padding:40px 16px;"><div style="max-width:520px;margin:auto;background:#fff;border:1px solid #dbe6ef;border-radius:16px;padding:30px;text-align:center;"><div style="font-size:38px;font-weight:800;color:#2563eb;">500</div><h1 style="margin:8px 0 10px;font-size:20px;">Temporary Server Error</h1><p style="color:#52687c;font-size:14px;line-height:1.6;">The request could not be completed right now. Details have been recorded in the server error log (<code>erp/logs/php_error.log</code>).</p><a href="/" style="display:inline-block;margin-top:12px;background:#2563eb;color:#fff;padding:10px 20px;border-radius:10px;text-decoration:none;font-weight:700;">Return Home</a></div></body></html>';
        exit;
    });
}

function app_secret_key() {
    $envKey = yu_env('APP_KEY', '');
    if (strlen($envKey) >= 16) return $envKey;
    if (defined('APP_KEY') && strlen(APP_KEY) >= 16) return APP_KEY;
    error_log('[SECURITY WARNING] APP_KEY is missing or too short.');
    return hash('sha256', __FILE__ . php_uname('n'));
}

function yu_admin_login_slug(): string {
    $defaultSlug = 'yt-ctrl-94x2-gate';
    $slug = yu_env('CONSOLE_GATE_SLUG', yu_env('ADMIN_LOGIN_SLUG', $defaultSlug));
    if (!preg_match('/^[a-zA-Z0-9_-]{8,64}$/', $slug)) {
        return $defaultSlug;
    }
    $lower = strtolower($slug);
    foreach (['admin', 'login', 'panel', 'staff', 'root', 'dashboard', 'erp', 'wp-'] as $blocked) {
        if (strpos($lower, $blocked) !== false) {
            return $defaultSlug;
        }
    }
    return $slug;
}

function yu_admin_login_url(): string {
    return '/erp/' . yu_admin_login_slug();
}

function encrypt_secret($plain) {
    $plain = (string) $plain;
    if ($plain === '') return '';
    if (!function_exists('openssl_encrypt')) {
        return 'b64:' . base64_encode($plain);
    }
    $key = hash('sha256', app_secret_key(), true);
    $iv = random_bytes(16);
    $cipher = openssl_encrypt($plain, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
    return base64_encode($iv . $cipher);
}

function decrypt_secret($encoded) {
    $encoded = (string) $encoded;
    if ($encoded === '') return '';
    if (strpos($encoded, 'b64:') === 0) {
        return (string) base64_decode(substr($encoded, 4));
    }
    if (!function_exists('openssl_decrypt')) return '';
    $raw = base64_decode($encoded, true);
    if ($raw === false || strlen($raw) < 17) return '';
    $iv = substr($raw, 0, 16);
    $cipher = substr($raw, 16);
    $key = hash('sha256', app_secret_key(), true);
    $out = openssl_decrypt($cipher, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
    return $out === false ? '' : $out;
}

function send_security_headers() {
    if (headers_sent()) return;
    header('X-Frame-Options: SAMEORIGIN');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('X-XSS-Protection: 1; mode=block');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
}

function send_noindex_headers() {
    if (headers_sent()) return;
    header('X-Robots-Tag: noindex, nofollow, noarchive, nosnippet', true);
}

function start_secure_session() {
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }
    $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower((string) $_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https')
        || (isset($_SERVER['SERVER_PORT']) && (int) $_SERVER['SERVER_PORT'] === 443);

    if (!headers_sent()) {
        @ini_set('session.use_strict_mode', '1');
        @ini_set('session.use_only_cookies', '1');
        @ini_set('session.cookie_httponly', '1');
        @session_set_cookie_params([
            'lifetime' => 0,
            'path'     => '/',
            'domain'   => '',
            'secure'   => $isHttps,
            'httponly' => true,
            'samesite' => 'Strict',
        ]);
        @session_name('YUITORERPSESS');
    }
    @session_start();

    $ua = isset($_SERVER['HTTP_USER_AGENT']) ? substr((string) $_SERVER['HTTP_USER_AGENT'], 0, 180) : '';
    if (!isset($_SESSION['_ua'])) {
        $_SESSION['_ua'] = hash('sha256', $ua);
    } elseif (!hash_equals($_SESSION['_ua'], hash('sha256', $ua))) {
        $_SESSION = [];
        session_destroy();
        session_start();
        $_SESSION['_ua'] = hash('sha256', $ua);
    }

    $now = time();
    if (isset($_SESSION['_last_activity']) && ($now - (int) $_SESSION['_last_activity']) > 1800) {
        $wasLogged = !empty($_SESSION['user_id']);
        $_SESSION = [];
        session_destroy();
        session_start();
        if ($wasLogged) {
            $_SESSION['flash'] = ['type' => 'warning', 'msg' => 'Session expired after 30 minutes of inactivity. Please sign in again.'];
        }
    }
    $_SESSION['_last_activity'] = $now;
}

function e($value) {
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function csrf_token() {
    start_secure_session();
    if (empty($_SESSION['_csrf_token'])) {
        $_SESSION['_csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['_csrf_token'];
}

function csrf_field() {
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}

function verify_csrf($providedToken = null) {
    start_secure_session();
    $token = $providedToken !== null
        ? (string) $providedToken
        : (isset($_POST['csrf_token']) ? (string) $_POST['csrf_token'] : (string) ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? ''));
    if (empty($_SESSION['_csrf_token']) || $token === '' || !hash_equals($_SESSION['_csrf_token'], $token)) {
        http_response_code(403);
        die('Invalid or expired security token (CSRF). Please refresh the page and try again.');
    }
}

function client_ip() {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    return filter_var($ip, FILTER_VALIDATE_IP) ? substr($ip, 0, 60) : '0.0.0.0';
}

function generate_public_captcha(): string {
    start_secure_session();
    $a = random_int(2, 9);
    $b = random_int(1, 9);
    $_SESSION['public_captcha_ans'] = (string) ($a + $b);
    return "{$a} + {$b}";
}

function verify_public_captcha(?string $answer): bool {
    start_secure_session();
    $expected = $_SESSION['public_captcha_ans'] ?? '';
    unset($_SESSION['public_captcha_ans']);
    return $expected !== '' && trim((string) $answer) === $expected;
}
