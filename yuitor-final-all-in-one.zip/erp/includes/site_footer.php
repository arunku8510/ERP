<?php
require_once __DIR__ . '/icons.php';
$instName = function_exists('get_setting') ? get_setting('institute_name', 'Yuitor Smart Classes') : 'Yuitor Smart Classes';
$instLogo = function_exists('get_setting') ? get_setting('institute_logo', '/erp/assets/images/yuitor-smart-classes-logo.png') : '/erp/assets/images/yuitor-smart-classes-logo.png';
?>
  </div><!-- /.yuitor-erp-layout -->
</main>

<footer class="yu-shared-footer">
  <div class="yu-footer-strip">
    <div class="yu-container">
      <div class="yu-strip-grid">
        <div class="yu-strip-item">
          <div class="yu-strip-icon"><?php echo yu_icon('users', 20); ?></div>
          <div>
            <div style="font-size:17px;font-weight:800;color:#fff;line-height:1.15;">Classes 6–12</div>
            <div style="font-size:12px;color:#cde0ea;">School learning</div>
          </div>
        </div>
        <div class="yu-strip-item">
          <div class="yu-strip-icon"><?php echo yu_icon('trophy', 20); ?></div>
          <div>
            <div style="font-size:17px;font-weight:800;color:#fff;line-height:1.15;">JEE · NEET · CUET</div>
            <div style="font-size:12px;color:#cde0ea;">Entrance preparation</div>
          </div>
        </div>
        <div class="yu-strip-item">
          <div class="yu-strip-icon"><?php echo yu_icon('graduation', 20); ?></div>
          <div>
            <div style="font-size:17px;font-weight:800;color:#fff;line-height:1.15;">AI-assisted</div>
            <div style="font-size:12px;color:#cde0ea;">Practice &amp; revision</div>
          </div>
        </div>
        <div class="yu-strip-item">
          <div class="yu-strip-icon"><?php echo yu_icon('map-pin', 20); ?></div>
          <div>
            <div style="font-size:17px;font-weight:800;color:#fff;line-height:1.15;">Muradnagar</div>
            <div style="font-size:12px;color:#cde0ea;">In-person learning centre</div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="yu-container yu-footer-main">
    <div class="yu-footer-cols">
      <div>
        <a href="/" style="display:flex;align-items:center;gap:14px;text-decoration:none;margin-bottom:16px;">
          <div style="width:52px;height:52px;border-radius:50%;background:#eef6fa;border:1.5px solid #bfe3eb;padding:3px;flex-shrink:0;overflow:hidden;">
            <img src="<?php echo e($instLogo); ?>" alt="<?php echo e($instName); ?>" style="width:100%;height:100%;object-fit:contain;display:block;border-radius:50%;">
          </div>
          <div>
            <div style="font-family:'Manrope',sans-serif;font-size:21px;font-weight:800;color:#fff;line-height:1.1;"><?php echo e($instName); ?></div>
            <div style="font-size:10px;font-weight:700;letter-spacing:0.14em;color:#78d3d3;text-transform:uppercase;margin-top:3px;">AI-ASSISTED · EXPERT-LED</div>
          </div>
        </a>
        <p style="margin:0 0 16px;color:#d4e2e9;font-size:14px;">Student-focused learning on campus, with programmes for school classes, entrance exams, coding and spoken English.</p>
        <div style="display:inline-flex;align-items:center;gap:10px;background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.12);border-radius:12px;padding:10px 14px;">
          <div style="width:32px;height:32px;border-radius:50%;background:#eef6fa;padding:2px;overflow:hidden;flex-shrink:0;">
            <img src="<?php echo e($instLogo); ?>" alt="" style="width:100%;height:100%;object-fit:contain;border-radius:50%;">
          </div>
          <div>
            <div style="font-size:12px;font-weight:700;color:#78d3d3;">Local Learning Centre</div>
            <div style="font-size:11px;color:#b8cdd8;">Structured, student-focused learning</div>
          </div>
        </div>
      </div>

      <div>
        <p class="yu-footer-heading"><span class="bar"></span>Quick Links</p>
        <ul class="yu-footer-list">
          <li><a style="display:inline-flex;align-items:center;gap:7px;" href="/about"><?php echo yu_icon('book', 13); ?> About Us</a></li>
          <li><a style="display:inline-flex;align-items:center;gap:7px;" href="/comparison"><?php echo yu_icon('graduation', 13); ?> All Courses</a></li>
          <li><a style="display:inline-flex;align-items:center;gap:7px;" href="/fee-calculator"><?php echo yu_icon('calculator', 13); ?> Fee Calculator</a></li>
          <li><a style="display:inline-flex;align-items:center;gap:7px;" href="/scholarship"><?php echo yu_icon('award', 13); ?> Scholarship Test</a></li>
          <li><a style="display:inline-flex;align-items:center;gap:7px;" href="/results"><?php echo yu_icon('trophy', 13); ?> Results &amp; Toppers</a></li>
          <li><a style="display:inline-flex;align-items:center;gap:7px;" href="/student/login.php"><?php echo yu_icon('graduation', 13); ?> Student Login</a></li>
          <li><a style="display:inline-flex;align-items:center;gap:7px;" href="/teacher/login.php"><?php echo yu_icon('users', 13); ?> Teacher Login</a></li>
          <li><a style="display:inline-flex;align-items:center;gap:7px;" href="<?php echo e(erp_url('admission-test/index.php')); ?>"><?php echo yu_icon('tests', 13); ?> Online Admission Test</a></li>
        </ul>
      </div>

      <div>
        <p class="yu-footer-heading"><span class="bar"></span>Our Courses</p>
        <ul class="yu-footer-list">
          <li><a style="display:inline-flex;align-items:center;gap:7px;" href="/class/7"><?php echo yu_icon('chevron-right', 13); ?> Class 5 – 8 Coaching</a></li>
          <li><a style="display:inline-flex;align-items:center;gap:7px;" href="/class/9"><?php echo yu_icon('chevron-right', 13); ?> Class 9 &amp; 10 Coaching</a></li>
          <li><a style="display:inline-flex;align-items:center;gap:7px;" href="/class/11"><?php echo yu_icon('chevron-right', 13); ?> Class 11 &amp; 12 Coaching</a></li>
          <li><a style="display:inline-flex;align-items:center;gap:7px;" href="/exam/neet"><?php echo yu_icon('chevron-right', 13); ?> NEET Coaching</a></li>
          <li><a style="display:inline-flex;align-items:center;gap:7px;" href="/exam/jee"><?php echo yu_icon('chevron-right', 13); ?> JEE Coaching</a></li>
          <li><a style="display:inline-flex;align-items:center;gap:7px;" href="/exam/cuet"><?php echo yu_icon('chevron-right', 13); ?> CUET Coaching</a></li>
          <li><a style="display:inline-flex;align-items:center;gap:7px;" href="/course/coding"><?php echo yu_icon('chevron-right', 13); ?> Coding Classes</a></li>
          <li><a style="display:inline-flex;align-items:center;gap:7px;" href="/course/spoken-english"><?php echo yu_icon('chevron-right', 13); ?> Spoken English</a></li>
        </ul>
      </div>

      <div>
        <p class="yu-footer-heading"><span class="bar"></span>Get In Touch</p>
        <ul class="yu-footer-list">
          <li>
            <div style="font-size:10.5px;text-transform:uppercase;letter-spacing:.1em;color:#8eb5c6;display:flex;align-items:center;gap:5px;"><?php echo yu_icon('phone', 12); ?> Phone / WhatsApp</div>
            <a href="tel:+917827289292" style="color:#fff;font-weight:600;">+91 78-2728-9292</a>
          </li>
          <li>
            <div style="font-size:10.5px;text-transform:uppercase;letter-spacing:.1em;color:#8eb5c6;display:flex;align-items:center;gap:5px;"><?php echo yu_icon('branches', 12); ?> Branch Desk</div>
            <a href="tel:+911232314337" style="color:#fff;font-weight:600;">+91 1232314337</a>
          </li>
          <li>
            <div style="font-size:10.5px;text-transform:uppercase;letter-spacing:.1em;color:#8eb5c6;display:flex;align-items:center;gap:5px;"><?php echo yu_icon('mail', 12); ?> Email</div>
            <div><a href="mailto:<?php echo e(YU_INSTITUTE_EMAIL); ?>"><?php echo e(YU_INSTITUTE_EMAIL); ?></a></div>
            <div><a href="mailto:<?php echo e(YU_INQUIRY_EMAIL); ?>"><?php echo e(YU_INQUIRY_EMAIL); ?></a></div>
          </li>
          <li>
            <div style="font-size:10.5px;text-transform:uppercase;letter-spacing:.1em;color:#8eb5c6;display:flex;align-items:center;gap:5px;"><?php echo yu_icon('map-pin', 12); ?> Address</div>
            <div style="color:#d4e2e9;font-size:13.5px;">Trimurti Vihar, near Venus Academy,<br>Muradnagar - 201206</div>
          </li>
        </ul>
      </div>
    </div>

    <div class="yu-footer-bottom">
      <div style="display:flex;align-items:center;gap:10px;">
        <div style="width:28px;height:28px;border-radius:50%;background:rgba(255,255,255,0.14);padding:2px;overflow:hidden;">
          <img src="<?php echo e($instLogo); ?>" alt="" style="width:100%;height:100%;object-fit:contain;border-radius:50%;">
        </div>
        <span>&copy; <?php echo date('Y'); ?> <?php echo e($instName); ?>. All rights reserved. Muradnagar, India.</span>
      </div>
      <div style="display:flex;align-items:center;gap:10px;">
        <a href="/privacy" style="color:#b8cdd8;text-decoration:none;">Privacy Policy</a>
        <span>•</span>
        <a href="/terms" style="color:#b8cdd8;text-decoration:none;">Terms of Use</a>
        <span>•</span>
        <a href="/refund" style="color:#b8cdd8;text-decoration:none;">Refund Policy</a>
      </div>
    </div>
  </div>
</footer>

<script>
(function(){
  var btn = document.getElementById('yuCoursesBtn');
  var wrap = document.getElementById('yuCoursesMenu');
  if (btn && wrap) {
    btn.addEventListener('click', function(e){
      e.stopPropagation();
      var open = wrap.classList.toggle('is-open');
      btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
    document.addEventListener('click', function(){
      wrap.classList.remove('is-open');
      btn.setAttribute('aria-expanded', 'false');
    });
  }
  var openBtn = document.getElementById('yuMobileOpenBtn');
  var closeBtn = document.getElementById('yuMobileCloseBtn');
  var drawer = document.getElementById('yuMobileDrawer');
  if (openBtn && drawer) {
    openBtn.addEventListener('click', function(){ drawer.classList.add('is-open'); drawer.setAttribute('aria-hidden','false'); });
  }
  if (closeBtn && drawer) {
    closeBtn.addEventListener('click', function(){ drawer.classList.remove('is-open'); drawer.setAttribute('aria-hidden','true'); });
  }
})();
</script>
</body>
</html>
