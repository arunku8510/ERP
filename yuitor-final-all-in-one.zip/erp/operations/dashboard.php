<?php
require_once __DIR__ . '/../includes/auth.php';
send_security_headers();
$user = require_role('staff');
$pdo = db();
$brId = (int)$user['branch_id'];
if (!$brId) die('Your Operations Staff account is not assigned to a branch.');

$q1 = $pdo->prepare("SELECT name FROM branches WHERE id = ?"); $q1->execute([$brId]); $brName = (string)$q1->fetchColumn();
$q2 = $pdo->prepare("SELECT COUNT(*) FROM students WHERE branch_id = ? AND deleted_at IS NULL AND status='active'"); $q2->execute([$brId]); $activeSt = (int)$q2->fetchColumn();
$q3 = $pdo->prepare("SELECT COUNT(*) FROM inquiries WHERE branch_id = ? AND deleted_at IS NULL AND status IN ('new','follow_up','demo_scheduled')"); $q3->execute([$brId]); $openInq = (int)$q3->fetchColumn();
$q4 = $pdo->prepare("SELECT COUNT(*) FROM fee_payments WHERE branch_id = ? AND status='pending_verification'"); $q4->execute([$brId]); $pendingUpi = (int)$q4->fetchColumn();
$q5 = $pdo->prepare("SELECT COUNT(*) FROM attendance WHERE branch_id = ? AND att_date = CURDATE() AND status IN ('present','late')"); $q5->execute([$brId]); $todayAtt = (int)$q5->fetchColumn();

$pageTitle = 'Operations Branch Dashboard';
$showPanelSidebar = true;
$portalMode = 'admin';
$pageNoIndex = true;
include __DIR__ . '/../includes/site_header.php';
include __DIR__ . '/../includes/panel_nav.php';
?>
<div class="yu-page-head">
  <div><h1>Branch Operations Desk</h1><p>Assigned Branch: <strong><?php echo e($brName); ?></strong> (Cross-branch access blocked)</p></div>
</div>
<div class="yu-kpi-grid">
  <div class="yu-kpi"><div class="yu-kpi-head"><div class="yu-kpi-label">Branch Active Students</div><span class="yu-kpi-ico"><?php echo yu_icon('students', 17); ?></span></div><div class="yu-kpi-val"><?php echo $activeSt; ?></div></div>
  <div class="yu-kpi"><div class="yu-kpi-head"><div class="yu-kpi-label">Open Inquiries</div><span class="yu-kpi-ico teal"><?php echo yu_icon('admission', 17); ?></span></div><div class="yu-kpi-val"><?php echo $openInq; ?></div></div>
  <div class="yu-kpi"><div class="yu-kpi-head"><div class="yu-kpi-label">Pending UPI Proofs</div><span class="yu-kpi-ico"><?php echo yu_icon('fees', 17); ?></span></div><div class="yu-kpi-val"><?php echo $pendingUpi; ?></div></div>
  <div class="yu-kpi"><div class="yu-kpi-head"><div class="yu-kpi-label">Today's Check-ins</div><span class="yu-kpi-ico teal"><?php echo yu_icon('qr', 17); ?></span></div><div class="yu-kpi-val"><?php echo $todayAtt; ?></div></div>
</div>
<div class="yu-card">
  <div class="yu-card-title">Quick Branch Actions</div>
  <div style="display:flex;flex-wrap:wrap;gap:10px;">
    <a class="yu-btn yu-btn-primary" href="<?php echo e(erp_url('operations/admissions.php')); ?>"><?php echo yu_icon('admission', 15); ?> New Inquiry / Admission</a>
    <a class="yu-btn yu-btn-teal" href="<?php echo e(erp_url('operations/attendance.php')); ?>"><?php echo yu_icon('qr', 15); ?> Branch Attendance &amp; QR</a>
    <a class="yu-btn yu-btn-outline" href="<?php echo e(erp_url('operations/payments.php')); ?>"><?php echo yu_icon('fees', 15); ?> Cash Entry &amp; UPI Verify</a>
    <a class="yu-btn yu-btn-outline" href="<?php echo e(erp_url('operations/change_requests.php')); ?>"><?php echo yu_icon('requests', 15); ?> Submit Edit/Delete Request</a>
  </div>
</div>
<?php include __DIR__ . '/../includes/site_footer.php'; ?>
