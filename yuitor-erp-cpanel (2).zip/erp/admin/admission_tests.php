<?php
require_once __DIR__ . '/../includes/auth.php';
send_security_headers();
$user = require_role('admin');
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $act = $_POST['act'] ?? '';
    if ($act === 'create_test') {
        $pdo->prepare("INSERT INTO admission_tests (branch_id, title, course_label, duration_minutes, total_marks, pass_percentage, created_by) VALUES (?, ?, ?, ?, ?, ?, ?)")
            ->execute([(int)$_POST['branch_id'], trim($_POST['title']), trim($_POST['course_label']), (int)$_POST['duration_minutes'], (int)$_POST['total_marks'], (float)$_POST['pass_percentage'], $user['id']]);
        flash_set('success', 'Online Admission Test created.');
    } elseif ($act === 'add_question') {
        $pdo->prepare("INSERT INTO admission_test_questions (test_id, question_text, option_a, option_b, option_c, option_d, correct_option, marks) VALUES (?, ?, ?, ?, ?, ?, ?, ?)")
            ->execute([(int)$_POST['test_id'], trim($_POST['question_text']), trim($_POST['option_a']), trim($_POST['option_b']), trim($_POST['option_c']), trim($_POST['option_d']), $_POST['correct_option'], (int)$_POST['marks']]);
        flash_set('success', 'MCQ Question added to test.');
    }
    redirect_to('admin/admission_tests.php');
}

$branches = $pdo->query("SELECT id, code, name FROM branches WHERE deleted_at IS NULL")->fetchAll();
$tests = $pdo->query("SELECT t.*, (SELECT COUNT(*) FROM admission_test_questions q WHERE q.test_id=t.id) AS q_cnt FROM admission_tests t ORDER BY t.id DESC")->fetchAll();
$attempts = $pdo->query("SELECT a.*, t.title AS test_title FROM admission_test_attempts a JOIN admission_tests t ON t.id=a.test_id ORDER BY a.id DESC LIMIT 40")->fetchAll();

$pageTitle = 'Online Admission & Scholarship Tests';
$showPanelSidebar = true;
include __DIR__ . '/../includes/site_header.php';
include __DIR__ . '/../includes/panel_nav.php';
?>
<div class="yu-page-head">
  <div><h1>Online Admission &amp; Scholarship Tests</h1><p>Build timed MCQ tests &amp; view public candidate scores.</p></div>
  <a href="<?php echo e(erp_url('admission-test/index.php')); ?>" target="_blank" class="yu-btn yu-btn-teal yu-btn-sm">Open Public Test Portal</a>
</div>

<div class="yu-grid-2">
  <div class="yu-card">
    <div class="yu-card-title">Create Admission Test</div>
    <form method="post">
      <?php echo csrf_field(); ?><input type="hidden" name="act" value="create_test">
      <div class="yu-form-row">
        <div class="yu-field"><label>Branch</label><select name="branch_id"><?php foreach($branches as $b): ?><option value="<?php echo (int)$b['id']; ?>"><?php echo e($b['name']); ?></option><?php endforeach; ?></select></div>
        <div class="yu-field"><label>Test Title</label><input type="text" name="title" placeholder="Yuitor Scholarship Test 2026" required></div>
      </div>
      <div class="yu-form-row">
        <div class="yu-field"><label>Course Label</label><input type="text" name="course_label" placeholder="Class 9-12 / JEE / NEET"></div>
        <div class="yu-field"><label>Minutes</label><input type="number" name="duration_minutes" value="30"></div>
        <div class="yu-field"><label>Pass %</label><input type="number" name="pass_percentage" value="40"></div>
        <input type="hidden" name="total_marks" value="100">
      </div>
      <button class="yu-btn yu-btn-primary yu-btn-sm" type="submit">Create Test</button>
    </form>
  </div>

  <div class="yu-card">
    <div class="yu-card-title">Add MCQ Question</div>
    <form method="post">
      <?php echo csrf_field(); ?><input type="hidden" name="act" value="add_question">
      <div class="yu-field" style="margin-bottom:8px;"><label>Select Test</label><select name="test_id"><?php foreach($tests as $t): ?><option value="<?php echo (int)$t['id']; ?>"><?php echo e($t['title'].' ('.$t['q_cnt'].' Qs)'); ?></option><?php endforeach; ?></select></div>
      <div class="yu-field" style="margin-bottom:8px;"><label>Question</label><textarea name="question_text" rows="2" required></textarea></div>
      <div class="yu-form-row">
        <div class="yu-field"><label>Option A</label><input type="text" name="option_a" required></div>
        <div class="yu-field"><label>Option B</label><input type="text" name="option_b" required></div>
        <div class="yu-field"><label>Option C</label><input type="text" name="option_c" required></div>
        <div class="yu-field"><label>Option D</label><input type="text" name="option_d" required></div>
      </div>
      <div class="yu-form-row">
        <div class="yu-field"><label>Correct</label><select name="correct_option"><option>A</option><option>B</option><option>C</option><option>D</option></select></div>
        <div class="yu-field"><label>Marks</label><input type="number" name="marks" value="4"></div>
      </div>
      <button class="yu-btn yu-btn-teal yu-btn-sm" type="submit">Add Question</button>
    </form>
  </div>
</div>

<div class="yu-card">
  <div class="yu-card-title">Candidate Attempts &amp; Scholarship Awarded</div>
  <div class="yu-table-wrap"><table class="yu-table">
    <tr><th>Code</th><th>Candidate</th><th>Phone</th><th>Test</th><th class="num">Score</th><th class="num">Scholarship</th><th>PDF</th></tr>
    <?php foreach ($attempts as $a): ?>
      <tr>
        <td><code><?php echo e($a['candidate_code']); ?></code></td>
        <td><strong><?php echo e($a['full_name']); ?></strong><div style="font-size:12px;color:#64748b;"><?php echo e($a['target_class']); ?></div></td>
        <td><?php echo e($a['phone']); ?></td>
        <td><?php echo e($a['test_title']); ?></td>
        <td class="num"><?php echo e($a['score'].' / '.$a['max_score'].' ('.$a['percentage'].'%)'); ?></td>
        <td class="num st-ok"><strong><?php echo (int)$a['scholarship_pct']; ?>% OFF</strong></td>
        <td><a class="yu-btn yu-btn-outline yu-btn-sm" target="_blank" href="<?php echo e(erp_url('admission-test/result_pdf.php?code='.urlencode($a['candidate_code']))); ?>">PDF</a></td>
      </tr>
    <?php endforeach; ?>
  </table></div>
</div>
<?php include __DIR__ . '/../includes/site_footer.php'; ?>
