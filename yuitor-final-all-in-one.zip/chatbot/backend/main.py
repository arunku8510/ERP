"""FastAPI application exposing POST /chat, GET /health, GET /stats, and /widget static assets."""
from __future__ import annotations

import os
from contextlib import asynccontextmanager
from pathlib import Path

from dotenv import load_dotenv
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from backend.engine import ChatbotEngine

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent.parent
_engine: ChatbotEngine | None = None


def get_engine() -> ChatbotEngine:
    global _engine
    if _engine is None:
        _engine = ChatbotEngine(base_dir=BASE_DIR)
    return _engine


@asynccontextmanager
async def lifespan(_app: FastAPI):
    get_engine()
    yield


app = FastAPI(
    title="Yuitor Customer Support Chatbot API",
    version="1.0.0",
    lifespan=lifespan,
)

origins_raw = os.getenv("ALLOWED_ORIGINS", "*").strip()
allowed_origins = ["*"] if origins_raw == "*" else [o.strip() for o in origins_raw.split(",") if o.strip()]

app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins,
    allow_credentials=False,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["Content-Type"],
)

widget_dir = BASE_DIR / "widget"
if widget_dir.is_dir():
    app.mount("/widget", StaticFiles(directory=str(widget_dir), html=True), name="widget")


class ChatRequest(BaseModel):
    message: str = Field(..., min_length=1, max_length=600)


class ChatResponse(BaseModel):
    reply: str
    category: str
    confidence: float
    blocked: bool = False


@app.get("/")
async def root():
    return RedirectResponse(url="/widget/demo.html")


@app.get("/health")
async def health():
    return {"status": "ok"}


@app.get("/stats")
async def stats():
    return get_engine().stats()


@app.post("/chat", response_model=ChatResponse)
async def chat(payload: ChatRequest, request: Request):
    client_ip = request.client.host if request.client else "unknown"
    status_code, body = get_engine().answer(payload.message, client_ip=client_ip)
    return JSONResponse(status_code=status_code, content=body)


if __name__ == "__main__":
    import uvicorn

    host = os.getenv("HOST", "0.0.0.0")
    port = int(os.getenv("PORT", "8000"))
    uvicorn.run("backend.main:app", host=host, port=port, reload=False)
