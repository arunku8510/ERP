(() => {
  "use strict";

  const root = document.getElementById("root");
  if (!root) return;

  const DEFAULT_META_COLOR = "#0F172A";
  const DISMISS_STORAGE_PREFIX = "yuitor_festival_dismissed_";

  const controllerState = {
    serverConfig: null,
    transientConfig: null,
    resolution: null,
    fetching: false,
  };

  function getEngine() {
    return window.YuitorFestivalEngine || null;
  }

  function escapeHtml(value) {
    return String(value ?? "").replace(/[&<>"']/g, (ch) => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;",
    })[ch]);
  }

  function getUrlPreviewOverrides() {
    try {
      const params = new URLSearchParams(window.location.search);
      const fest = params.get("festival");
      const dateParam = params.get("festivalDate");
      if (fest === "none" || fest === "off" || fest === "disabled") {
        return { mode: "disabled", manualFestivalId: null, simulatedDateIST: null };
      }
      if (fest) {
        return { mode: "manual", manualFestivalId: fest, simulatedDateIST: null };
      }
      if (dateParam && /^\d{4}-\d{2}-\d{2}$/.test(dateParam)) {
        return { mode: "automatic", manualFestivalId: null, simulatedDateIST: dateParam };
      }
    } catch {
      // Ignore malformed query strings
    }
    return null;
  }

  function getEffectiveConfig() {
    const engine = getEngine();
    const base = engine ? { ...engine.DEFAULT_ADMIN_CONFIG } : {
      mode: "automatic",
      manualFestivalId: null,
      simulatedDateIST: null,
      overrides: {},
    };
    const merged = {
      ...base,
      ...(controllerState.serverConfig || {}),
      ...(controllerState.transientConfig || {}),
      overrides: {
        ...(controllerState.serverConfig?.overrides || {}),
        ...(controllerState.transientConfig?.overrides || {}),
      },
    };
    const urlOverride = getUrlPreviewOverrides();
    if (urlOverride) {
      return { ...merged, ...urlOverride };
    }
    return merged;
  }

  function getMotifEmblemSvg(motif, accent) {
    switch (motif) {
      case "diwali_diyas":
        return `<svg viewBox="0 0 48 48" width="32" height="32" aria-hidden="true">
          <defs>
            <radialGradient id="yuFlameGlow" cx="50%" cy="45%" r="50%">
              <stop offset="0%" stop-color="#FFFBEB"/>
              <stop offset="55%" stop-color="#F59E0B"/>
              <stop offset="100%" stop-color="#EA580C" stop-opacity="0"/>
            </radialGradient>
          </defs>
          <circle cx="24" cy="18" r="14" fill="url(#yuFlameGlow)"/>
          <path class="yu-diya-flame" d="M24 7c3.6 5.2 5.4 9.1 5.4 12.2a5.4 5.4 0 0 1-10.8 0C18.6 16.1 20.4 12.2 24 7Z" fill="#FBBF24"/>
          <path class="yu-diya-flame" d="M24 11.5c1.8 2.8 2.7 5 2.7 6.8a2.7 2.7 0 0 1-5.4 0c0-1.8.9-4 2.7-6.8Z" fill="#FEF3C7"/>
          <path d="M9 28h30c-1.8 7.5-7.8 11.8-15 11.8S10.8 35.5 9 28Z" fill="#D97706"/>
          <path d="M12 28h24c-1.4 4.2-6 6.8-12 6.8S13.4 32.2 12 28Z" fill="#F59E0B"/>
          <ellipse cx="24" cy="28" rx="15" ry="2.6" fill="#FCD34D"/>
        </svg>`;
      case "eid_crescent":
        return `<svg viewBox="0 0 48 48" width="32" height="32" aria-hidden="true">
          <path d="M28.5 10a13.5 13.5 0 1 0 9.5 23 11 11 0 1 1-9.5-23Z" fill="#D4AF37"/>
          <polygon points="34,13 35.4,16.6 39.2,16.8 36.2,19.1 37.2,22.8 34,20.7 30.8,22.8 31.8,19.1 28.8,16.8 32.6,16.6" fill="#FDE68A"/>
        </svg>`;
      case "holi_gulal":
        return `<svg viewBox="0 0 48 48" width="32" height="32" aria-hidden="true">
          <circle cx="19" cy="20" r="10" fill="#EC4899" opacity="0.85"/>
          <circle cx="30" cy="22" r="9" fill="#0D9488" opacity="0.82"/>
          <circle cx="24" cy="30" r="8.5" fill="#F59E0B" opacity="0.88"/>
          <circle cx="34" cy="14" r="3" fill="#7C3AED"/>
          <circle cx="12" cy="31" r="2.6" fill="#DB2777"/>
        </svg>`;
      case "christmas_snow":
        return `<svg viewBox="0 0 48 48" width="32" height="32" aria-hidden="true">
          <path d="M24 8l6 10h-4l6 9h-5l5 8H16l5-8h-5l6-9h-4l6-10Z" fill="#16A34A"/>
          <rect x="21.5" y="35" width="5" height="6" rx="1" fill="#B45309"/>
          <polygon points="24,4 25.3,7.3 28.8,7.5 26,9.7 27,13 24,11 21,13 22,9.7 19.2,7.5 22.7,7.3" fill="#FACC15"/>
        </svg>`;
      case "patriotic_tricolor":
        return `<svg viewBox="0 0 48 48" width="32" height="32" aria-hidden="true">
          <rect x="8" y="10" width="32" height="9" rx="2" fill="#EA580C"/>
          <rect x="8" y="19" width="32" height="10" fill="#FFFFFF" stroke="#CBD5E1" stroke-width="0.6"/>
          <rect x="8" y="29" width="32" height="9" rx="2" fill="#15803D"/>
          <circle cx="24" cy="24" r="4" fill="none" stroke="#1D4ED8" stroke-width="1.5"/>
          <circle cx="24" cy="24" r="1.2" fill="#1D4ED8"/>
        </svg>`;
      case "rakhi_threads":
        return `<svg viewBox="0 0 48 48" width="32" height="32" aria-hidden="true">
          <path d="M6 24h36" stroke="#D97706" stroke-width="3" stroke-linecap="round"/>
          <circle cx="24" cy="24" r="10" fill="#BE185D" stroke="#FBBF24" stroke-width="2.5"/>
          <circle cx="24" cy="24" r="4.5" fill="#FDE68A"/>
        </svg>`;
      case "navratri_garba":
        return `<svg viewBox="0 0 48 48" width="32" height="32" aria-hidden="true">
          <circle cx="24" cy="24" r="15" fill="none" stroke="#F59E0B" stroke-width="2" stroke-dasharray="4 3"/>
          <line x1="14" y1="34" x2="34" y2="14" stroke="#FB7185" stroke-width="3.2" stroke-linecap="round"/>
          <line x1="14" y1="14" x2="34" y2="34" stroke="#FBBF24" stroke-width="3.2" stroke-linecap="round"/>
        </svg>`;
      case "sikh_lamps":
        return `<svg viewBox="0 0 48 48" width="32" height="32" aria-hidden="true">
          <circle cx="24" cy="24" r="13" fill="none" stroke="#D97706" stroke-width="2.2"/>
          <path d="M24 9v30M15 16c4 5 4 11 0 16M33 16c-4 5-4 11 0 16" stroke="#1E3A8A" stroke-width="2.4" fill="none" stroke-linecap="round"/>
        </svg>`;
      default:
        return `<svg viewBox="0 0 48 48" width="32" height="32" aria-hidden="true">
          <circle cx="24" cy="24" r="11" fill="${escapeHtml(accent || "#F59E0B")}" opacity="0.22"/>
          <polygon points="24,8 27.6,18.2 38.4,18.4 29.8,24.9 33,35.2 24,29 15,35.2 18.2,24.9 9.6,18.4 20.4,18.2" fill="${escapeHtml(accent || "#F59E0B")}"/>
        </svg>`;
    }
  }

  function buildDiyaSvg() {
    return `<svg class="yu-diya-svg" viewBox="0 0 64 64" aria-hidden="true">
      <defs>
        <radialGradient id="yuHeroDiyaAura" cx="50%" cy="35%" r="50%">
          <stop offset="0%" stop-color="#FEF3C7" stop-opacity="0.95"/>
          <stop offset="55%" stop-color="#F59E0B" stop-opacity="0.35"/>
          <stop offset="100%" stop-color="#F59E0B" stop-opacity="0"/>
        </radialGradient>
      </defs>
      <circle cx="32" cy="22" r="20" fill="url(#yuHeroDiyaAura)"/>
      <path class="yu-diya-flame" d="M32 9c5 7.2 7.5 12.6 7.5 16.8a7.5 7.5 0 0 1-15 0C24.5 21.6 27 16.2 32 9Z" fill="#F59E0B"/>
      <path class="yu-diya-flame" d="M32 15c2.6 4 3.9 7 3.9 9.4a3.9 3.9 0 0 1-7.8 0c0-2.4 1.3-5.4 3.9-9.4Z" fill="#FEF9C3"/>
      <path d="M12 37h40c-2.5 10.5-10.8 16.5-20 16.5S14.5 47.5 12 37Z" fill="#B45309"/>
      <path d="M15 37h34c-2 6.2-8.2 10-17 10s-15-3.8-17-10Z" fill="#D97706"/>
      <ellipse cx="32" cy="37" rx="20" ry="3.4" fill="#FBBF24"/>
    </svg>`;
  }

  function buildTrimGarland(motif) {
    if (motif === "diwali_diyas") {
      return `
        <svg viewBox="0 0 180 22" width="140" height="18" aria-hidden="true">
          <path d="M0 4 Q30 18 60 4 T120 4 T180 4" fill="none" stroke="#FBBF24" stroke-width="1.6"/>
          <circle cx="30" cy="11" r="3" fill="#F59E0B"/>
          <circle cx="90" cy="11" r="3.4" fill="#FDE68A"/>
          <circle cx="150" cy="11" r="3" fill="#FB923C"/>
        </svg>`;
    }
    if (motif === "patriotic_tricolor") {
      return `
        <svg viewBox="0 0 120 18" width="108" height="16" aria-hidden="true">
          <polygon points="0,0 24,0 12,16" fill="#EA580C"/>
          <polygon points="24,0 48,0 36,16" fill="#FFFFFF"/>
          <polygon points="48,0 72,0 60,16" fill="#15803D"/>
          <polygon points="72,0 96,0 84,16" fill="#EA580C"/>
          <polygon points="96,0 120,0 108,16" fill="#15803D"/>
        </svg>`;
    }
    if (motif === "eid_crescent") {
      return `
        <svg viewBox="0 0 140 20" width="120" height="16" aria-hidden="true">
          <path d="M0 3 Q35 16 70 3 T140 3" fill="none" stroke="#D4AF37" stroke-width="1.4"/>
          <circle cx="35" cy="10" r="2.6" fill="#FDE68A"/>
          <circle cx="105" cy="10" r="2.6" fill="#34D399"/>
        </svg>`;
    }
    return `
      <svg viewBox="0 0 140 20" width="120" height="16" aria-hidden="true">
        <path d="M0 3 Q35 15 70 3 T140 3" fill="none" stroke="currentColor" stroke-width="1.4" opacity="0.7"/>
        <circle cx="35" cy="9" r="2.5" fill="currentColor"/>
        <circle cx="105" cy="9" r="2.5" fill="currentColor"/>
      </svg>`;
  }

  function buildHeroOrnamentsHtml(motif) {
    if (motif === "diwali_diyas") {
      return `
        <span class="yu-sparkle" style="top:14%;left:46%;animation-delay:0.2s"></span>
        <span class="yu-sparkle" style="top:24%;right:14%;animation-delay:1.1s"></span>
        <span class="yu-sparkle" style="top:62%;left:8%;animation-delay:2.0s"></span>
        <span class="yu-sparkle" style="top:38%;right:6%;animation-delay:0.7s"></span>
        <span class="yu-sparkle" style="bottom:26%;left:48%;animation-delay:2.7s"></span>
        <div class="yu-diya-row" aria-hidden="true">
          ${buildDiyaSvg()}
          ${buildDiyaSvg()}
          ${buildDiyaSvg()}
        </div>`;
    }
    if (motif === "eid_crescent") {
      return `
        <div class="yu-eid-lanterns" aria-hidden="true">
          <svg class="yu-lantern-sway" width="34" height="72" viewBox="0 0 34 72">
            <line x1="17" y1="0" x2="17" y2="20" stroke="#D4AF37" stroke-width="1.5"/>
            <path d="M10 20h14l4 14-11 16-11-16Z" fill="rgba(212,175,55,0.22)" stroke="#D4AF37" stroke-width="1.6"/>
            <circle cx="17" cy="34" r="4" fill="#FDE68A"/>
          </svg>
          <svg class="yu-lantern-sway" width="28" height="58" viewBox="0 0 34 72">
            <line x1="17" y1="0" x2="17" y2="16" stroke="#34D399" stroke-width="1.5"/>
            <path d="M10 16h14l4 14-11 16-11-16Z" fill="rgba(52,211,153,0.18)" stroke="#34D399" stroke-width="1.6"/>
            <circle cx="17" cy="30" r="3.5" fill="#FDE68A"/>
          </svg>
        </div>`;
    }
    if (motif === "christmas_snow") {
      return `
        <span class="yu-snow-dot" style="left:12%;animation-delay:0s"></span>
        <span class="yu-snow-dot" style="left:28%;animation-delay:2.2s"></span>
        <span class="yu-snow-dot" style="left:52%;animation-delay:4.1s"></span>
        <span class="yu-snow-dot" style="left:74%;animation-delay:1.5s"></span>
        <span class="yu-snow-dot" style="left:89%;animation-delay:3.3s"></span>`;
    }
    if (motif === "holi_gulal") {
      return `
        <div class="yu-holi-splash" style="width:180px;height:180px;top:-40px;right:12%;background:radial-gradient(circle,#ec4899,transparent 70%)"></div>
        <div class="yu-holi-splash" style="width:150px;height:150px;bottom:30px;left:4%;background:radial-gradient(circle,#0d9488,transparent 70%);animation-delay:1.8s"></div>`;
    }
    return "";
  }

  function removeFestiveDom() {
    document.getElementById("yu-festival-header-trim")?.remove();
    document.getElementById("yu-festival-banner")?.remove();
    document.getElementById("yu-festival-hero-ornaments")?.remove();
    document.getElementById("yu-festival-footer-wish")?.remove();
  }

  function applyFestivalDom(resolution) {
    const html = document.documentElement;
    const occ = resolution.activeOccurrence;
    const theme = resolution.activeTheme;

    if (!occ) {
      html.setAttribute("data-festival", "none");
      html.setAttribute("data-festival-motif", "academic_default");
      html.setAttribute("data-festival-dark", "false");
      document
        .querySelectorAll('meta[name="theme-color"], meta[name="msapplication-TileColor"]')
        .forEach((m) => m.setAttribute("content", DEFAULT_META_COLOR));
      removeFestiveDom();
      return;
    }

    const festival = occ.festival;
    html.setAttribute("data-festival", festival.id);
    html.setAttribute("data-festival-motif", theme.motif);
    html.setAttribute("data-festival-dark", theme.isDark ? "true" : "false");
    document
      .querySelectorAll('meta[name="theme-color"], meta[name="msapplication-TileColor"]')
      .forEach((m) => m.setAttribute("content", theme.bg));

    // 1. Header decorative trim + exact fixed-header height measurement
    const header = root.querySelector(".yu-shared-header");
    if (header) {
      let trim = document.getElementById("yu-festival-header-trim");
      if (!trim) {
        trim = document.createElement("div");
        trim.id = "yu-festival-header-trim";
        trim.className = "yu-festival-header-trim";
        header.appendChild(trim);
      }
      if (trim.dataset.festivalId !== festival.id || trim.dataset.date !== resolution.istNow.isoDate) {
        trim.dataset.festivalId = festival.id;
        trim.dataset.date = resolution.istNow.isoDate;
        trim.innerHTML = `
          <span class="yu-festival-trim-text">
            <span class="yu-festival-trim-dot" aria-hidden="true"></span>
            <span>${escapeHtml(theme.bannerLabel)} · ${escapeHtml(resolution.istNow.formattedDate)} IST</span>
          </span>
          <span class="yu-festival-trim-garland" aria-hidden="true">${buildTrimGarland(theme.motif)}</span>
        `;
      }
      const headerHeight = Math.ceil(header.getBoundingClientRect().height);
      if (headerHeight > 0) {
        html.style.setProperty("--yu-header-height", `${headerHeight}px`);
      }
    }

    // 2. Automatic Festival Greeting Banner inside <main>
    const main = root.querySelector("main");
    const dismissKey = `${DISMISS_STORAGE_PREFIX}${festival.id}_${resolution.istNow.isoDate}`;
    const isDismissed = window.sessionStorage?.getItem(dismissKey) === "1";

    if (main && !isDismissed) {
      let bannerWrap = document.getElementById("yu-festival-banner");
      if (!bannerWrap) {
        bannerWrap = document.createElement("div");
        bannerWrap.id = "yu-festival-banner";
        bannerWrap.className = "yu-festival-banner-wrap";
        bannerWrap.setAttribute("role", "region");
        bannerWrap.setAttribute("aria-label", "Festival Greeting");
        main.prepend(bannerWrap);
      } else if (bannerWrap.parentElement !== main) {
        main.prepend(bannerWrap);
      }

      const sig = `${festival.id}|${occ.effectiveGreetingTitle}|${occ.effectiveGreetingSubtitle}|${resolution.istNow.isoDate}|${resolution.mode}`;
      if (bannerWrap.dataset.sig !== sig) {
        bannerWrap.dataset.sig = sig;
        const modeLabel = resolution.mode === "manual"
          ? "Manual Theme Active"
          : resolution.isSimulatedDate
          ? "Calendar Date Preview (IST)"
          : occ.isExactDay
          ? "Today in India (IST)"
          : "Festive Season (IST)";

        bannerWrap.innerHTML = `
          <div class="yu-festival-banner" data-testid="festival-greeting-banner">
            <div class="yu-festival-banner-left">
              <div class="yu-festival-emblem">${getMotifEmblemSvg(theme.motif, theme.accent)}</div>
              <div>
                <div class="yu-festival-banner-kicker">
                  <span>${escapeHtml(festival.name)}</span>
                  <span>·</span>
                  <span>${escapeHtml(festival.tradition)}</span>
                  <span>·</span>
                  <span>${escapeHtml(modeLabel)}</span>
                </div>
                <p class="yu-festival-banner-title">${escapeHtml(occ.effectiveGreetingTitle)}</p>
                <p class="yu-festival-banner-sub">${escapeHtml(occ.effectiveGreetingSubtitle)}</p>
              </div>
            </div>
            <div class="yu-festival-banner-right">
              <span class="yu-festival-ist-chip">${escapeHtml(resolution.istNow.formattedDate)} · IST</span>
              <button type="button" class="yu-festival-banner-close" aria-label="Dismiss ${escapeHtml(festival.name)} greeting" title="Dismiss greeting">×</button>
            </div>
          </div>
        `;
        const closeBtn = bannerWrap.querySelector(".yu-festival-banner-close");
        if (closeBtn) {
          closeBtn.addEventListener("click", () => {
            try {
              window.sessionStorage?.setItem(dismissKey, "1");
            } catch {
              // Ignore storage restrictions
            }
            bannerWrap.remove();
          });
        }
      }
    } else if (isDismissed) {
      document.getElementById("yu-festival-banner")?.remove();
    }

    // 3. Hero Lightweight Ornaments (when on Homepage)
    const hero = root.querySelector(".yn-home .yn-hero");
    if (hero) {
      let ornaments = document.getElementById("yu-festival-hero-ornaments");
      if (!ornaments) {
        ornaments = document.createElement("div");
        ornaments.id = "yu-festival-hero-ornaments";
        ornaments.className = "yu-festival-hero-ornaments";
        ornaments.setAttribute("aria-hidden", "true");
        hero.appendChild(ornaments);
      }
      if (ornaments.dataset.motif !== theme.motif) {
        ornaments.dataset.motif = theme.motif;
        ornaments.innerHTML = buildHeroOrnamentsHtml(theme.motif);
      }
    } else {
      document.getElementById("yu-festival-hero-ornaments")?.remove();
    }

    // 4. Footer Festive Wish
    const footer = root.querySelector("footer.yu-shared-footer");
    if (footer) {
      let footerWish = document.getElementById("yu-festival-footer-wish");
      if (!footerWish) {
        footerWish = document.createElement("div");
        footerWish.id = "yu-festival-footer-wish";
        footerWish.className = "yu-festival-footer-wish";
        footer.prepend(footerWish);
      }
      if (footerWish.dataset.sig !== `${festival.id}|${occ.effectiveGreetingTitle}`) {
        footerWish.dataset.sig = `${festival.id}|${occ.effectiveGreetingTitle}`;
        footerWish.innerHTML = `
          <span>✦ ${escapeHtml(occ.effectiveGreetingTitle)} — ${escapeHtml(occ.effectiveGreetingSubtitle)}</span>
          <span>Yuitor Smart Classes · ${escapeHtml(festival.name)} (${escapeHtml(occ.year)})</span>
        `;
      }
    }
  }

  let syncPending = false;
  function syncFestivalTheme() {
    if (syncPending) return;
    syncPending = true;
    window.requestAnimationFrame(() => {
      syncPending = false;
      const engine = getEngine();
      if (!engine) return;
      const config = getEffectiveConfig();
      const resolution = engine.resolveFestivalState(config, new Date());
      controllerState.resolution = resolution;
      applyFestivalDom(resolution);
    });
  }

  async function fetchFestivalConfig() {
    if (controllerState.fetching) return;
    controllerState.fetching = true;
    try {
      const response = await fetch("/api/festival.php", {
        cache: "no-store",
        credentials: "same-origin",
        headers: { Accept: "application/json" },
      });
      if (response.ok) {
        const data = await response.json();
        if (data && data.config) {
          controllerState.serverConfig = data.config;
          syncFestivalTheme();
        }
      }
    } catch {
      // Fallback cleanly to automatic IST engine defaults
    } finally {
      controllerState.fetching = false;
      syncFestivalTheme();
    }
  }

  window.YuitorFestivalController = {
    getResolution() {
      const engine = getEngine();
      return engine ? engine.resolveFestivalState(getEffectiveConfig(), new Date()) : null;
    },
    getConfig() {
      return getEffectiveConfig();
    },
    setTransientConfig(cfg) {
      controllerState.transientConfig = cfg || null;
      syncFestivalTheme();
    },
    async reloadConfig() {
      controllerState.transientConfig = null;
      await fetchFestivalConfig();
    },
    syncNow() {
      syncFestivalTheme();
    },
  };

  const observer = new MutationObserver(() => {
    syncFestivalTheme();
  });
  observer.observe(root, { childList: true, subtree: true });

  window.addEventListener("popstate", syncFestivalTheme);
  window.addEventListener("resize", syncFestivalTheme);
  window.addEventListener("yuitor:festival-config-updated", (ev) => {
    if (ev && ev.detail) {
      controllerState.serverConfig = ev.detail;
      controllerState.transientConfig = null;
    }
    syncFestivalTheme();
  });

  // Check every 60 seconds for IST midnight festival transition
  window.setInterval(syncFestivalTheme, 60000);

  syncFestivalTheme();
  fetchFestivalConfig();
})();
