<?php
// Run every 5 mins via cPanel Cron: */5 * * * * /usr/local/bin/php -q /home/USER/public_html/erp/cron/send_queue.php
if (php_sapi_name() !== 'cli') { http_response_code(403); exit('CLI only'); }
require_once __DIR__ . '/../includes/messaging_providers.php';
$res = dispatch_queue_batch(40);
echo "Processed: {$res['processed']}, Sent: {$res['sent']}\n";
