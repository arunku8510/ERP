<?php
require_once __DIR__ . '/includes/auth.php';
send_security_headers();
start_secure_session();

$step = isset($_GET['email']) ? 'verify' : 'request';
$emailVal = trim((string)($_GET['email'] ?? ''));
$msg = '';
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? 'request';
    if ($action === 'request') {
        $emailVal = trim((string)($_POST['email'] ?? ''));
        $stmt = db()->prepare("SELECT id, full_name, email FROM users WHERE email = ? AND is_active = 1 AND deleted_at IS NULL LIMIT 1");
        $stmt->execute([$emailVal]);
        $u = $stmt->fetch();
        if ($u) {
            $code = generate_6digit_otp((int)$u['id'], 'password_reset', 15);
            $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'https';
            $host = $_SERVER['HTTP_HOST'] ?? 'yuitor.com';
            $resetUrl = $scheme . '://' . $host . erp_url('forgot-password.php?email=' . urlencode($u['email']));
            send_forgot_password_email($u['email'], $u['full_name'], $code, $resetUrl);
            audit_log('password_reset_requested', 'users', (int)$u['id'], 'Sent 6-digit reset OTP');
        }
        $msg = 'If an active account matches that email, a 6-digit reset OTP has been sent from No-reply@yuitor.com.';
        $step = 'verify';
    } elseif ($action === 'reset') {
        $emailVal = trim((string)($_POST['email'] ?? ''));
        $code = trim((string)($_POST['otp_code'] ?? ''));
        $newPass = (string)($_POST['new_password'] ?? '');
        $confirmPass = (string)($_POST['confirm_password'] ?? '');
        if (strlen($newPass) < 8 || $newPass !== $confirmPass) {
            $err = 'Password must be at least 8 characters and match confirmation.';
            $step = 'verify';
        } else {
            $stmt = db()->prepare("SELECT id, full_name FROM users WHERE email = ? AND is_active = 1 AND deleted_at IS NULL LIMIT 1");
            $stmt->execute([$emailVal]);
            $u = $stmt->fetch();
            if ($u && verify_6digit_otp((int)$u['id'], 'password_reset', $code)) {
                $hash = password_hash($newPass, PASSWORD_DEFAULT);
                db()->prepare("UPDATE users SET password_hash = ?, failed_attempts = 0, locked_until = NULL WHERE id = ?")->execute([$hash, (int)$u['id']]);
                audit_log('password_reset_completed', 'users', (int)$u['id'], 'Password updated via OTP');
                flash_set('success', 'Password reset successful! You can now sign in with your new password.');
                redirect_to('index.php');
            } else {
                $err = 'Invalid or expired 6-digit OTP code.';
                $step = 'verify';
            }
        }
    }
}

$pageTitle = 'Forgot Password';
$showPanelSidebar = false;
include __DIR__ . '/includes/site_header.php';
$brandLogo = get_setting('institute_logo', '/erp/assets/images/yuitor-smart-classes-logo.png');
?>
<div style="max-width:500px;margin:24px auto;">
  <div class="yu-card">
    <div style="display:flex;align-items:center;gap:12px;margin-bottom:10px;">
      <div style="width:46px;height:46px;border-radius:50%;background:#eef6fa;border:1.5px solid #bfe3eb;padding:3px;flex-shrink:0;overflow:hidden;">
        <img src="<?php echo e($brandLogo); ?>" alt="Yuitor Smart Classes" style="width:100%;height:100%;object-fit:contain;border-radius:50%;">
      </div>
      <div>
        <div style="font-size:11px;font-weight:700;color:#0b7b82;text-transform:uppercase;letter-spacing:.08em;display:flex;align-items:center;gap:5px;"><?php echo yu_icon('lock', 13); ?> Yuitor Smart Classes Account</div>
        <h1 style="margin:2px 0 0;font-family:'Manrope',sans-serif;font-size:22px;">Reset Your Password</h1>
      </div>
    </div>
    <p style="margin:0 0 16px;font-size:13.5px;color:#52687c;">We send a 6-digit reset code with your registered name from <code>No-reply@yuitor.com</code>.</p>
    <?php if ($msg !== ''): ?><div class="yu-alert yu-alert-success" style="display:flex;align-items:center;gap:8px;"><?php echo yu_icon('check', 16); ?> <span><?php echo e($msg); ?></span></div><?php endif; ?>
    <?php if ($err !== ''): ?><div class="yu-alert yu-alert-danger" style="display:flex;align-items:center;gap:8px;"><?php echo yu_icon('alert', 16); ?> <span><?php echo e($err); ?></span></div><?php endif; ?>

    <?php if ($step === 'request'): ?>
      <form method="post">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="action" value="request">
        <div class="yu-field" style="margin-bottom:14px;">
          <label for="fpEmail" style="display:flex;align-items:center;gap:6px;"><?php echo yu_icon('mail', 14); ?> Registered Email Address</label>
          <input id="fpEmail" type="email" name="email" required value="<?php echo e($emailVal); ?>" placeholder="Enter your email">
        </div>
        <button type="submit" class="yu-btn yu-btn-primary" style="width:100%;"><?php echo yu_icon('send', 15); ?> Send 6-Digit Reset OTP</button>
      </form>
    <?php else: ?>
      <form method="post">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="action" value="reset">
        <div class="yu-field" style="margin-bottom:12px;">
          <label>Email Address</label>
          <input type="email" name="email" required value="<?php echo e($emailVal); ?>">
        </div>
        <div class="yu-field" style="margin-bottom:12px;">
          <label>6-Digit Reset OTP</label>
          <input type="text" name="otp_code" maxlength="6" pattern="\d{6}" required placeholder="000000">
        </div>
        <div class="yu-field" style="margin-bottom:12px;">
          <label>New Password (min 8 chars)</label>
          <input type="password" name="new_password" minlength="8" required>
        </div>
        <div class="yu-field" style="margin-bottom:14px;">
          <label>Confirm New Password</label>
          <input type="password" name="confirm_password" minlength="8" required>
        </div>
        <button type="submit" class="yu-btn yu-btn-primary" style="width:100%;"><?php echo yu_icon('check', 15); ?> Update Password</button>
      </form>
    <?php endif; ?>
    <div style="margin-top:14px;text-align:center;">
      <a href="<?php echo e(erp_url('index.php')); ?>" style="font-size:13px;color:#2563eb;font-weight:600;">&larr; Back to Login</a>
    </div>
  </div>
</div>
<?php include __DIR__ . '/includes/site_footer.php'; ?>
