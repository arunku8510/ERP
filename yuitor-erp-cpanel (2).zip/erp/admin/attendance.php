<?php
require_once __DIR__ . '/../includes/auth.php';
send_security_headers();
$user = require_role('admin');
$pdo = db();

$batches = $pdo->query("SELECT ba.id, ba.name, b.code, b.id AS branch_id FROM batches ba JOIN branches b ON b.id=ba.branch_id WHERE ba.deleted_at IS NULL")->fetchAll();
$batchId = isset($_GET['batch_id']) ? (int)$_GET['batch_id'] : (!empty($batches) ? (int)$batches[0]['id'] : 0);
$attDate = $_GET['date'] ?? date('Y-m-d');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $bId = (int)$_POST['batch_id'];
    $d = $_POST['att_date'] ?? date('Y-m-d');
    $brId = (int)$pdo->query("SELECT branch_id FROM batches WHERE id = " . $bId)->fetchColumn();
    $statuses = $_POST['status'] ?? [];
    foreach ($statuses as $stId => $stVal) {
        if (!in_array($stVal, ['present','absent','late','leave'], true)) continue;
        $pdo->prepare("INSERT INTO attendance (branch_id, batch_id, student_id, att_date, status, mode, marked_by)
                       VALUES (?, ?, ?, ?, ?, 'manual', ?)
                       ON DUPLICATE KEY UPDATE status = VALUES(status), marked_by = VALUES(marked_by)")
            ->execute([$brId, $bId, (int)$stId, $d, $stVal, $user['id']]);
    }
    audit_log('attendance_marked', 'batches', $bId, "Date {$d} Count " . count($statuses));
    flash_set('success', 'Batch attendance saved for ' . $d);
    redirect_to('admin/attendance.php?batch_id=' . $bId . '&date=' . urlencode($d));
}

$students = [];
if ($batchId) {
    $st = $pdo->prepare("SELECT s.id, s.admission_no, u.full_name, a.status AS today_status, a.mode
                         FROM students s JOIN users u ON u.id=s.user_id
                         LEFT JOIN attendance a ON a.student_id=s.id AND a.att_date = ?
                         WHERE s.batch_id = ? AND s.deleted_at IS NULL AND s.status='active' ORDER BY u.full_name");
    $st->execute([$attDate, $batchId]);
    $students = $st->fetchAll();
}

$pageTitle = 'Attendance (Manual & QR Scanner)';
$showPanelSidebar = true;
include __DIR__ . '/../includes/site_header.php';
include __DIR__ . '/../includes/panel_nav.php';
?>
<div class="yu-page-head">
  <div><h1>Institute Attendance &amp; QR Check-In</h1><p>Mark manual batch registers or scan Student QR ID Cards using Token / Webcam.</p></div>
</div>

<div class="yu-card">
  <div class="yu-card-title">Quick QR Code / Token Check-In</div>
  <div style="display:flex;flex-wrap:wrap;gap:10px;align-items:center;">
    <input type="text" id="qrTokenInput" placeholder="Scan or paste Student QR Token..." style="flex:1;min-width:240px;padding:10px 12px;border:1px solid #cbd9e6;border-radius:10px;">
    <button type="button" class="yu-btn yu-btn-teal" onclick="submitQrToken()">Mark QR Present</button>
  </div>
  <div id="qrResult" style="margin-top:10px;font-size:13.5px;font-weight:700;"></div>
</div>

<div class="yu-card">
  <div class="yu-card-title">
    <span>Manual Batch Register</span>
    <form method="get" style="display:flex;gap:8px;flex-wrap:wrap;">
      <select name="batch_id" style="padding:6px 10px;border:1px solid #cbd9e6;border-radius:8px;">
        <?php foreach($batches as $b): ?><option value="<?php echo (int)$b['id']; ?>" <?php echo $batchId===(int)$b['id']?'selected':''; ?>><?php echo e($b['code'].' - '.$b['name']); ?></option><?php endforeach; ?>
      </select>
      <input type="date" name="date" value="<?php echo e($attDate); ?>" style="padding:6px 10px;border:1px solid #cbd9e6;border-radius:8px;">
      <button class="yu-btn yu-btn-outline yu-btn-sm" type="submit">Load</button>
    </form>
  </div>
  <form method="post">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="batch_id" value="<?php echo $batchId; ?>">
    <input type="hidden" name="att_date" value="<?php echo e($attDate); ?>">
    <div class="yu-table-wrap"><table class="yu-table">
      <tr><th>Adm No</th><th>Student</th><th>Mode</th><th>Attendance Status</th></tr>
      <?php foreach ($students as $st): $cur = $st['today_status'] ?: 'present'; ?>
        <tr>
          <td><?php echo e($st['admission_no']); ?></td>
          <td><strong><?php echo e($st['full_name']); ?></strong></td>
          <td><?php echo e(strtoupper($st['mode'] ?: 'manual')); ?></td>
          <td>
            <select name="status[<?php echo (int)$st['id']; ?>]" style="padding:6px 10px;border:1px solid #cbd9e6;border-radius:8px;">
              <?php foreach(['present'=>'Present','absent'=>'Absent','late'=>'Late','leave'=>'Leave'] as $k=>$v): ?>
                <option value="<?php echo $k; ?>" <?php echo $cur===$k?'selected':''; ?>><?php echo $v; ?></option>
              <?php endforeach; ?>
            </select>
          </td>
        </tr>
      <?php endforeach; ?>
    </table></div>
    <?php if (!empty($students)): ?><button class="yu-btn yu-btn-primary" style="margin-top:14px;" type="submit">Save Attendance Register</button><?php endif; ?>
  </form>
</div>
<script>
function submitQrToken(){
  var inp = document.getElementById('qrTokenInput');
  var out = document.getElementById('qrResult');
  var tok = inp.value.trim();
  if(!tok) return;
  fetch('<?php echo e(erp_url("api/qr_attendance.php")); ?>', {
    method:'POST',
    headers:{'Content-Type':'application/x-www-form-urlencoded','X-CSRF-Token':'<?php echo e(csrf_token()); ?>'},
    body:'qr_token='+encodeURIComponent(tok)
  }).then(r=>r.json()).then(d=>{
    out.style.color = d.ok ? '#15803d' : '#b91c1c';
    out.textContent = d.message || (d.ok ? 'Marked Present' : 'Failed');
    if(d.ok) inp.value = '';
  }).catch(()=>{ out.style.color='#b91c1c'; out.textContent='Network error'; });
}
</script>
<?php include __DIR__ . '/../includes/site_footer.php'; ?>
