<?php
require_once __DIR__ . '/../includes/auth.php';
send_security_headers();
$user = require_role('teacher');
$pdo = db();

$batchIds = teacher_assigned_batch_ids($user['id']);
$students = [];
if ($batchIds) {
    $in = implode(',', array_map('intval', $batchIds));
    $students = $pdo->query("SELECT s.id, s.admission_no, s.roll_no, u.full_name, u.phone, u.email, ba.name AS batch_name
                             FROM students s JOIN users u ON u.id=s.user_id JOIN batches ba ON ba.id=s.batch_id
                             WHERE s.batch_id IN ({$in}) AND s.deleted_at IS NULL AND s.status='active' ORDER BY ba.name, u.full_name")->fetchAll();
}

$pageTitle = 'My Batch Students';
$showPanelSidebar = true;
include __DIR__ . '/../includes/site_header.php';
include __DIR__ . '/../includes/panel_nav.php';
?>
<div class="yu-page-head">
  <div><h1>My Assigned Batch Students</h1><p>Privacy-protected roster (student phone &amp; email are masked for faculty).</p></div>
</div>
<div class="yu-card">
  <div class="yu-table-wrap"><table class="yu-table">
    <tr><th>Adm No</th><th>Roll</th><th>Student Name</th><th>Batch</th><th>Phone (Masked)</th><th>Email (Masked)</th></tr>
    <?php foreach ($students as $st): ?>
      <tr>
        <td><strong><?php echo e($st['admission_no']); ?></strong></td>
        <td><?php echo e($st['roll_no'] ?: '-'); ?></td>
        <td><?php echo e($st['full_name']); ?></td>
        <td><?php echo e($st['batch_name']); ?></td>
        <td><code><?php echo e(mask_phone($st['phone'])); ?></code></td>
        <td><code><?php echo e(mask_email($st['email'])); ?></code></td>
      </tr>
    <?php endforeach; ?>
  </table></div>
</div>
<?php include __DIR__ . '/../includes/site_footer.php'; ?>
