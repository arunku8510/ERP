<?php
declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';
yu_api_init();

try {
    $db = yu_db();
} catch (Throwable $error) {
    error_log('Yuitor portal database error: ' . $error->getMessage());
    yu_fail(503, 'The portal database is not ready. Please contact the website administrator.');
}

$method = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));
$action = strtolower(trim((string) ($_GET['action'] ?? '')));

if ($method === 'GET' && $action === 'csrf') {
    yu_json(200, array('csrfToken' => yu_csrf_token()));
}

if ($method === 'GET' && $action === 'me') {
    $sessionUser = yu_session_user();
    if (!$sessionUser) {
        yu_json(200, array('user' => null));
    }
    $role = (string) ($sessionUser['role'] ?? '');
    if (!in_array($role, array('admin', 'student'), true)) {
        yu_json(200, array('user' => null));
    }
    $user = yu_require_role($db, $role);
    yu_json(200, array('user' => $user, 'csrfToken' => yu_csrf_token()));
}

if ($method !== 'POST') {
    header('Allow: GET, POST');
    yu_fail(405, 'Method not allowed.');
}

yu_require_same_origin();
$input = yu_read_json();
yu_require_csrf();

if ($action === 'logout') {
    $_SESSION = array();
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', array(
            'expires' => time() - 42000,
            'path' => $params['path'],
            'domain' => $params['domain'],
            'secure' => $params['secure'],
            'httponly' => $params['httponly'],
            'samesite' => $params['samesite'] ?? 'Lax',
        ));
    }
    session_destroy();
    yu_json(200, array('loggedOut' => true));
}

if ($action !== 'login') {
    yu_fail(404, 'Unknown sign-in action.');
}

$role = strtolower(yu_text($input, 'role', 20, true));
if (!in_array($role, array('admin', 'student'), true)) {
    yu_fail(400, 'Choose either the Admin or Student portal.');
}
$email = yu_email(yu_text($input, 'email', 254, true));
$password = yu_text($input, 'password', 200, true);
if ($password === '') {
    yu_fail(400, 'Enter your password.');
}

yu_check_login_limit($db, $role, $email);
if ($role === 'admin') {
    $statement = $db->prepare('SELECT id, display_name, email, password_hash, is_active FROM admins WHERE email = ?');
} else {
    $statement = $db->prepare(
        "SELECT id, full_name AS display_name, email, password_hash, is_active, registration_status
         FROM students WHERE email = ?"
    );
}
$statement->execute(array($email));
$account = $statement->fetch();
$fallbackHash = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.';
$passwordMatches = password_verify($password, $account ? (string) $account['password_hash'] : $fallbackHash);
$active = $account
    && (int) $account['is_active'] === 1
    && ($role !== 'student' || (string) $account['registration_status'] !== 'inactive');

if (!$account || !$passwordMatches || !$active) {
    yu_record_login_failure($db, $role, $email);
    yu_fail(401, 'Email or password is incorrect, or this account is inactive.');
}

if (password_needs_rehash((string) $account['password_hash'], PASSWORD_DEFAULT)) {
    $newHash = password_hash($password, PASSWORD_DEFAULT);
    $updateHash = $db->prepare('UPDATE ' . ($role === 'admin' ? 'admins' : 'students') . ' SET password_hash = ? WHERE id = ?');
    $updateHash->execute(array($newHash, (int) $account['id']));
}

$now = gmdate('c');
$loginTable = $role === 'admin' ? 'admins' : 'students';
$lastLogin = $db->prepare('UPDATE ' . $loginTable . ' SET last_login_at = ? WHERE id = ?');
$lastLogin->execute(array($now, (int) $account['id']));
yu_clear_login_failures($db, $role, $email);

session_regenerate_id(true);
$_SESSION['yu_portal_user'] = array(
    'id' => (int) $account['id'],
    'role' => $role,
    'signed_in_at' => time(),
    'last_activity' => time(),
);
unset($_SESSION['yu_csrf_token']);

yu_json(200, array(
    'authenticated' => true,
    'role' => $role,
    'displayName' => (string) $account['display_name'],
    'csrfToken' => yu_csrf_token(),
));
