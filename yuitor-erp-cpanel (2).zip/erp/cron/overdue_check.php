<?php
// Run daily via cPanel Cron: 0 8 * * * /usr/local/bin/php -q /home/USER/public_html/erp/cron/overdue_check.php
if (php_sapi_name() !== 'cli') { http_response_code(403); exit('CLI only'); }
require_once __DIR__ . '/../includes/messaging_providers.php';

$pdo = db();
$pdo->exec("UPDATE fee_installments SET status = 'overdue' WHERE status IN ('pending','partial') AND due_date < CURDATE()");
$days = (int)get_setting('auto_due_reminder_days', '3');
$stmt = $pdo->prepare("SELECT fi.*, u.full_name, u.email, u.phone FROM fee_installments fi
                       JOIN students s ON s.id = fi.student_id JOIN users u ON u.id = s.user_id
                       WHERE fi.status IN ('pending','partial','overdue') AND fi.due_date <= DATE_ADD(CURDATE(), INTERVAL ? DAY) AND s.deleted_at IS NULL");
$stmt->execute([$days]);
$cnt = 0;
foreach ($stmt->fetchAll() as $row) {
    $dueAmt = number_format((float)$row['amount'] - (float)$row['paid_amount'], 2);
    $msg = "Dear {$row['full_name']}, your fee installment ({$row['title']}) of Rs. {$dueAmt} is due on {$row['due_date']}. Pay via UPI: Yuitor@ybl or Yuitor@icicibank.";
    if ($row['email']) {
        enqueue_message('email', $row['email'], $row['full_name'], 'Fee Payment Reminder - Yuitor Smart Classes', $msg);
        $cnt++;
    }
}
echo "Overdue check done. Queued reminders: {$cnt}\n";
