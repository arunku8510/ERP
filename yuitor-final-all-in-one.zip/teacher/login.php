<?php
require_once dirname(__DIR__) . '/erp/includes/auth.php';
send_security_headers();
start_secure_session();

$existing = current_user();
if ($existing) {
    if ($existing['role'] === 'teacher') {
        redirect_to('/erp/teacher/dashboard.php');
    }
    http_response_code(403);
    $code = 403;
    include dirname(__DIR__) . '/erp/error.php';
    exit;
}

$err = '';
$emailVal = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $emailVal = strtolower(trim((string) ($_POST['email'] ?? '')));
    $pass = (string) ($_POST['password'] ?? '');
    $ip = client_ip();
    $pdo = db();

    if (($_SESSION['teacher_login_fail'] ?? 0) >= 3) {
        $capAns = trim((string) ($_POST['captcha'] ?? ''));
        $capExp = (string) ($_SESSION['teacher_captcha_exp'] ?? '');
        if ($capExp === '' || $capAns !== $capExp) {
            $err = 'Security verification math answer is incorrect.';
        }
    }

    if ($err === '') {
        if (!check_rate_limit($pdo, 'teacher_login_ip', $ip, 10, 15, false)) {
            $err = 'Too many sign-in attempts from this IP. Please try again in 15 minutes.';
        } elseif ($emailVal === '' || $pass === '') {
            $err = 'Email and password are required.';
        } else {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? AND role = 'teacher' AND deleted_at IS NULL LIMIT 1");
            $stmt->execute([$emailVal]);
            $user = $stmt->fetch();

            if ($user && !empty($user['locked_until']) && strtotime($user['locked_until']) > time()) {
                $err = 'This faculty account is temporarily locked. Please wait 15 minutes.';
            } elseif (!$user || !password_verify($pass, $user['password_hash'])) {
                $_SESSION['teacher_login_fail'] = (int) ($_SESSION['teacher_login_fail'] ?? 0) + 1;
                check_rate_limit($pdo, 'teacher_login_ip', $ip, 10, 15, true);
                if ($user) {
                    $fails = (int) $user['failed_attempts'] + 1;
                    $lock = $fails >= 5 ? date('Y-m-d H:i:s', time() + 900) : null;
                    $pdo->prepare("UPDATE users SET failed_attempts = ?, locked_until = ? WHERE id = ?")
                        ->execute([$fails, $lock, (int) $user['id']]);
                }
                $err = 'Invalid teacher email or password.';
            } elseif ((int) $user['is_active'] !== 1) {
                $err = 'Your faculty account is currently inactive. Contact the academic office.';
            } else {
                $_SESSION['teacher_login_fail'] = 0;
                clear_rate_limit($pdo, 'teacher_login_ip', $ip);
                complete_user_login($user);
                redirect_to('/erp/teacher/dashboard.php');
            }
        }
    }
}

$needCaptcha = ($_SESSION['teacher_login_fail'] ?? 0) >= 3;
if ($needCaptcha) {
    $a = random_int(2, 12);
    $b = random_int(2, 9);
    $_SESSION['teacher_captcha_exp'] = (string) ($a + $b);
    $_SESSION['teacher_captcha_q'] = "{$a} + {$b}";
}

$pageTitle = 'Faculty Portal Sign In';
$portalMode = 'teacher';
$showPanelSidebar = false;
include dirname(__DIR__) . '/erp/includes/site_header.php';
$brandLogo = get_setting('institute_logo', '/erp/assets/images/yuitor-smart-classes-logo.png');
?>
<style>
  .yu-portal-split {
    max-width: 1020px;
    margin: 20px auto 0;
    display: grid;
    grid-template-columns: 1fr;
    gap: 20px;
    align-items: stretch;
  }
  .yu-split-form { order: 1; }
  .yu-split-info { order: 2; }
  @media (min-width: 900px) {
    .yu-portal-split { grid-template-columns: 1.1fr 0.95fr; }
    .yu-split-info { order: 1; }
    .yu-split-form { order: 2; }
  }
  .yu-portal-promo {
    margin: 0;
    height: 100%;
    background: linear-gradient(155deg, #0f172a, #123c52 65%, #0b7b82);
    color: #eef6fa;
    border-color: #124c5b;
    display: flex;
    flex-direction: column;
    justify-content: center;
  }
</style>

<div class="yu-portal-split">
  <div class="yu-split-info">
    <div class="yu-card yu-portal-promo">
      <div style="font-size:11.5px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:#78d3d3;margin-bottom:10px;display:flex;align-items:center;gap:6px;">
        <?php echo yu_icon('book', 15); ?> Faculty &amp; Academic Portal
      </div>
      <h2 style="margin:0 0 12px;font-family:'Manrope',sans-serif;font-size:26px;line-height:1.22;color:#ffffff;">
        Apne Teaching Passion Ko Smart Impact Me Badlo!
      </h2>
      <p style="margin:0 0 16px;font-size:15px;line-height:1.65;color:#dbe9f2;">
        Digital attendance, batch test marks, study materials, homework evaluation aur parent-ready academic tracking ke saath students ko mentor karein.
      </p>
      <ul style="margin:0 0 22px;padding-left:18px;font-size:14px;line-height:1.8;color:#c9e1ee;">
        <li>Assigned Batch Rosters &amp; Attendance</li>
        <li>Study Notes &amp; Assignment Grading</li>
        <li>Batch Tests &amp; Score Analytics</li>
      </ul>
      <div>
        <a href="/teacher/register.php" class="yu-btn" style="background:#ffffff;color:#0f172a;font-weight:800;">
          <?php echo yu_icon('users', 16); ?> Teacher ke roop me Apply Karo
        </a>
      </div>
    </div>
  </div>

  <div class="yu-split-form">
    <div class="yu-card" style="margin:0;height:100%;">
      <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px;">
        <div style="width:46px;height:46px;border-radius:50%;background:#eef6fa;border:1.5px solid #bfe3eb;padding:3px;flex-shrink:0;overflow:hidden;">
          <img src="<?php echo e($brandLogo); ?>" alt="Yuitor Smart Classes" style="width:100%;height:100%;object-fit:contain;border-radius:50%;">
        </div>
        <div>
          <div style="font-size:11px;font-weight:700;color:#0b7b82;text-transform:uppercase;letter-spacing:.08em;">Yuitor Smart Classes</div>
          <h1 style="margin:2px 0 0;font-family:'Manrope',sans-serif;font-size:22px;">Teacher Sign In</h1>
        </div>
      </div>

      <?php echo render_flash(); ?>
      <?php if ($err !== ''): ?><div class="yu-alert yu-alert-danger"><?php echo e($err); ?></div><?php endif; ?>

      <form method="post">
        <?php echo csrf_field(); ?>
        <div class="yu-field" style="margin-bottom:12px;">
          <label for="tchEmail">Faculty Email Address</label>
          <input id="tchEmail" type="email" name="email" required autocomplete="username" value="<?php echo e($emailVal); ?>" placeholder="faculty@yuitor.com">
        </div>
        <div class="yu-field" style="margin-bottom:12px;">
          <label for="tchPass">Password</label>
          <input id="tchPass" type="password" name="password" required autocomplete="current-password" placeholder="Enter your password">
        </div>
        <?php if ($needCaptcha): ?>
          <div class="yu-field" style="margin-bottom:12px;">
            <label for="tchCap">Security Check: What is <?php echo e($_SESSION['teacher_captcha_q']); ?>?</label>
            <input id="tchCap" type="number" name="captcha" required>
          </div>
        <?php endif; ?>

        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;font-size:13px;">
          <a href="<?php echo e(erp_url('forgot-password.php?portal=teacher')); ?>" style="color:#2563eb;font-weight:600;text-decoration:none;">Forgot Password?</a>
          <span style="color:#657b8e;font-size:12px;">Faculty Access Only</span>
        </div>

        <button type="submit" class="yu-btn yu-btn-primary" style="width:100%;padding:12px;">
          <?php echo yu_icon('shield', 16); ?> Sign In to Faculty Portal
        </button>

        <p style="margin:14px 0 0;text-align:center;font-size:13.5px;color:#52687c;">
          Want to join our faculty? <a href="/teacher/register.php" style="color:#2563eb;font-weight:700;text-decoration:none;">Apply as Teacher &rarr;</a>
        </p>
      </form>
    </div>
  </div>
</div>
<?php include dirname(__DIR__) . '/erp/includes/site_footer.php'; ?>
