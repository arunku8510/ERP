<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/fee_helpers.php';
send_security_headers();
$user = require_role('student');
$st = current_student_record($user['id']);
$pdo = db();

$acc = $pdo->query("SELECT * FROM student_fee_accounts WHERE student_id = " . (int)$st['id'] . " ORDER BY id DESC LIMIT 1")->fetch();
$upi1 = get_setting('upi_id_primary', 'demo@upi');
$upi2 = get_setting('upi_id_secondary', 'demo2@upi');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $acc) {
    verify_csrf();
    $amount = (float)$_POST['amount'];
    $upiUsed = trim($_POST['upi_id_used'] ?? $upi1);
    $utr = trim($_POST['utr_number'] ?? '');
    $proofPath = '';
    if (!empty($_FILES['proof_file']['name'])) {
        $up = safe_upload($_FILES['proof_file'], 'payment_proofs', ['image/png'=>'png','image/jpeg'=>'jpg','image/webp'=>'webp','application/pdf'=>'pdf'], 5242880);
        if (!$up['ok']) { flash_set('error', $up['error']); redirect_to('student/fees.php'); }
        $proofPath = $up['path'];
    }
    if ($utr === '') {
        flash_set('error', 'UTR / UPI Transaction ID is mandatory.');
    } else {
        $res = record_fee_payment([
            'student_id' => $st['id'],
            'branch_id' => $st['branch_id'],
            'fee_account_id' => $acc['id'],
            'amount' => $amount,
            'payment_mode' => 'upi',
            'upi_id_used' => $upiUsed,
            'utr_number' => $utr,
            'proof_path' => $proofPath,
            'status' => 'pending_verification',
            'remarks' => 'Student UPI Submission',
            'collected_by' => $user['id'],
        ]);
        flash_set($res['ok'] ? 'success' : 'error', $res['ok'] ? 'UPI proof submitted! Status: Pending Verification.' : $res['error']);
    }
    redirect_to('student/fees.php');
}

$insts = $acc ? $pdo->query("SELECT * FROM fee_installments WHERE fee_account_id = " . (int)$acc['id'] . " ORDER BY installment_no ASC")->fetchAll() : [];
$payments = $pdo->query("SELECT * FROM fee_payments WHERE student_id = " . (int)$st['id'] . " ORDER BY id DESC")->fetchAll();
$due = $acc ? max(0, (float)$acc['net_amount'] - (float)$acc['paid_amount']) : 0;

$pageTitle = 'My Fees & UPI Payment';
$showPanelSidebar = true;
$portalMode = 'student';
include __DIR__ . '/../includes/site_header.php';
include __DIR__ . '/../includes/panel_nav.php';
?>
<div class="yu-page-head"><div><h1>My Fees, UPI Payment &amp; Receipts</h1></div></div>
<div class="yu-kpi-grid">
  <div class="yu-kpi"><div class="yu-kpi-label">Net Fee</div><div class="yu-kpi-val"><?php echo format_inr($acc['net_amount'] ?? 0); ?></div></div>
  <div class="yu-kpi"><div class="yu-kpi-label">Verified Paid</div><div class="yu-kpi-val st-ok"><?php echo format_inr($acc['paid_amount'] ?? 0); ?></div></div>
  <div class="yu-kpi"><div class="yu-kpi-label">Pending Balance</div><div class="yu-kpi-val st-bad"><?php echo format_inr($due); ?></div></div>
</div>

<?php if ($acc): ?>
<div class="yu-grid-2">
  <div class="yu-card">
    <div class="yu-card-title">Pay Now via Official Yuitor UPI</div>
    <p style="font-size:13.5px;color:#475569;margin-top:0;">Scan or pay via GPay / PhonePe / Paytm to either official UPI ID, then submit your 12-digit UTR &amp; screenshot below:</p>
    <div style="display:grid;gap:8px;margin-bottom:14px;">
      <div style="padding:10px 12px;background:#edf5fa;border:1px solid #cfe0eb;border-radius:10px;">
        <strong>Primary UPI ID:</strong> <code><?php echo e($upi1); ?></code>
        <a style="float:right;font-size:12.5px;font-weight:700;color:#2563eb;" href="upi://pay?pa=<?php echo urlencode($upi1); ?>&pn=Yuitor%20Smart%20Classes&am=<?php echo $due>0?$due:1000; ?>&cu=INR">Open UPI App &rarr;</a>
      </div>
      <div style="padding:10px 12px;background:#edf5fa;border:1px solid #cfe0eb;border-radius:10px;">
        <strong>Secondary UPI ID:</strong> <code><?php echo e($upi2); ?></code>
      </div>
    </div>
    <form method="post" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
      <div class="yu-form-row">
        <div class="yu-field"><label>Amount Paid (Rs.)</label><input type="number" step="0.01" name="amount" value="<?php echo $due > 0 ? $due : ''; ?>" required></div>
        <div class="yu-field"><label>UPI ID Paid To</label><select name="upi_id_used"><option><?php echo e($upi1); ?></option><option><?php echo e($upi2); ?></option></select></div>
      </div>
      <div class="yu-form-row">
        <div class="yu-field"><label>UTR / Transaction Ref #</label><input type="text" name="utr_number" required placeholder="e.g. 612345678901"></div>
        <div class="yu-field"><label>Screenshot Proof</label><input type="file" name="proof_file" accept="image/*,.pdf" required></div>
      </div>
      <button class="yu-btn yu-btn-primary" type="submit">Submit Payment Proof</button>
    </form>
  </div>

  <div class="yu-card">
    <div class="yu-card-title">Installment Schedule</div>
    <div class="yu-table-wrap"><table class="yu-table">
      <tr><th>Title</th><th>Due Date</th><th class="num">Amount</th><th>Status</th></tr>
      <?php foreach($insts as $in): ?>
        <tr><td><?php echo e($in['title']); ?></td><td><?php echo e($in['due_date']); ?></td><td class="num"><?php echo format_inr($in['amount']); ?></td><td><span class="yu-status-text <?php echo $in['status']==='paid'?'st-ok':($in['status']==='overdue'?'st-bad':'st-warn'); ?>"><?php echo e(ucfirst($in['status'])); ?></span></td></tr>
      <?php endforeach; ?>
    </table></div>
  </div>
</div>
<?php endif; ?>

<div class="yu-card">
  <div class="yu-card-title">Payment History &amp; PDF Receipts</div>
  <div class="yu-table-wrap"><table class="yu-table">
    <tr><th>Receipt #</th><th class="num">Amount</th><th>Mode / UTR</th><th>Status</th><th>Date</th><th>Receipt</th></tr>
    <?php foreach($payments as $p): ?>
      <tr>
        <td><strong><?php echo e($p['receipt_no']); ?></strong></td>
        <td class="num"><?php echo format_inr($p['amount']); ?></td>
        <td><?php echo e(strtoupper($p['payment_mode']).($p['utr_number']?' / '.$p['utr_number']:'')); ?></td>
        <td><span class="yu-status-text <?php echo $p['status']==='verified'?'st-ok':($p['status']==='pending_verification'?'st-warn':'st-bad'); ?>"><?php echo e(ucwords(str_replace('_',' ',$p['status']))); ?></span></td>
        <td><?php echo e($p['paid_at']); ?></td>
        <td><a class="yu-btn yu-btn-outline yu-btn-sm" target="_blank" href="<?php echo e(erp_url('student/receipt_pdf.php?id='.(int)$p['id'])); ?>">Download PDF</a></td>
      </tr>
    <?php endforeach; ?>
  </table></div>
</div>
<?php include __DIR__ . '/../includes/site_footer.php'; ?>
