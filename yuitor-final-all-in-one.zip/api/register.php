<?php
declare(strict_types=1);
require_once dirname(__DIR__) . '/erp/includes/auth.php';
send_security_headers();
start_secure_session();
header('Content-Type: application/json; charset=UTF-8');

if (strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET')) !== 'POST') {
    header('Allow: POST');
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed.']);
    exit;
}

$input = json_decode((string) file_get_contents('php://input'), true);
if (!is_array($input)) {
    $input = $_POST;
}

if (trim((string) ($input['website'] ?? $input['website_url'] ?? '')) !== '') {
    echo json_encode(['registered' => true, 'message' => 'Thank you. Registration received.']);
    exit;
}

if (isset($input['csrf_token']) || isset($_SERVER['HTTP_X_CSRF_TOKEN'])) {
    $tok = (string) ($input['csrf_token'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? ''));
    if (!empty($_SESSION['_csrf_token']) && $tok !== '') {
        verify_csrf($tok);
    }
}

$studentName = trim((string) ($input['fullName'] ?? $input['student_name'] ?? ''));
$parentName  = trim((string) ($input['parentName'] ?? $input['parent_name'] ?? ''));
$email       = strtolower(trim((string) ($input['email'] ?? '')));
$phone       = preg_replace('/[^0-9+\- ]/', '', (string) ($input['phone'] ?? ''));
$classLevel  = trim((string) ($input['classLevel'] ?? $input['class_grade'] ?? ''));
$board       = trim((string) ($input['board'] ?? 'CBSE'));
$subject     = trim((string) ($input['selectedSubject'] ?? $input['course_interest'] ?? ''));
$message     = trim((string) ($input['message'] ?? ''));
$rawPass     = (string) ($input['password'] ?? '');

if (mb_strlen($studentName) < 2 || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen(preg_replace('/\D+/', '', $phone)) < 10 || $classLevel === '') {
    http_response_code(400);
    echo json_encode(['error' => 'Student name, valid email, 10-digit phone aur class/course bharna zaroori hai.']);
    exit;
}

$pdo = db();
$ip = client_ip();
if (!check_rate_limit($pdo, 'student_reg', $ip, 5, 15, true)) {
    http_response_code(429);
    echo json_encode(['error' => 'Too many registrations. Please try again in 15 minutes.']);
    exit;
}

$otpCode = sprintf('%06d', random_int(0, 999999));
$otpHash = password_hash($otpCode, PASSWORD_DEFAULT);
$passHash = strlen($rawPass) >= 8 ? password_hash($rawPass, PASSWORD_DEFAULT) : null;

$pdo->prepare(
    "INSERT INTO online_registrations
     (branch_id, student_name, parent_name, email, phone, class_grade, board, course_interest, message, password_hash, email_verified, verification_code_hash, verification_expires_at, status, ip_address)
     VALUES (1, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, DATE_ADD(NOW(), INTERVAL 30 MINUTE), 'New', ?)"
)->execute([$studentName, $parentName, $email, $phone, $classLevel, $board, $subject, $message, $passHash, $otpHash, $ip]);

$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://';
$host = !empty($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : YU_MAIL_DOMAIN;
$verifyUrl = $scheme . $host . '/student/verify-email.php?email=' . urlencode($email);
send_student_verification_email($email, $studentName, $otpCode, $verifyUrl);

$adminEmail = get_setting('admin_2fa_email', YU_DEMO_ADMIN_EMAIL);
$admBody = '<p>New online student registration received:</p><ul><li><strong>Name:</strong> ' . e($studentName) . '</li><li><strong>Email:</strong> ' . e($email) . '</li><li><strong>Phone:</strong> ' . e($phone) . '</li><li><strong>Class:</strong> ' . e($classLevel) . '</li></ul>';
send_branded_email($adminEmail, 'Admissions Team', 'New Student Registration - ' . $studentName, $admBody);

http_response_code(201);
echo json_encode([
    'registered' => true,
    'message' => 'Registration saved! Verification code sent from ' . YU_MAIL_FROM_EMAIL . ' to ' . $email . '.',
    'verify_url' => '/student/verify-email.php?email=' . urlencode($email),
]);
