<?php
require_once __DIR__ . '/../includes/auth.php';
send_security_headers();
$user = require_role('staff');
$pdo = db();
$brId = (int)$user['branch_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $tbl = in_array($_POST['target_table'], ['students','inquiries'], true) ? $_POST['target_table'] : 'students';
    $actType = in_array($_POST['action_type'], ['update','delete'], true) ? $_POST['action_type'] : 'update';
    $tid = (int)$_POST['target_id'];
    if ($tbl === 'students') assert_student_access($user, $tid);

    $payload = [];
    if ($actType === 'update' && $tbl === 'students') {
        if (!empty($_POST['new_father_name'])) $payload['father_name'] = trim($_POST['new_father_name']);
        if (!empty($_POST['new_guardian_phone'])) $payload['guardian_phone'] = trim($_POST['new_guardian_phone']);
        if (!empty($_POST['new_roll_no'])) $payload['roll_no'] = trim($_POST['new_roll_no']);
    }
    $pdo->prepare("INSERT INTO change_requests (branch_id, requested_by, target_table, target_id, action_type, summary, payload_json) VALUES (?, ?, ?, ?, ?, ?, ?)")
        ->execute([$brId, $user['id'], $tbl, $tid, $actType, trim($_POST['summary']), json_encode($payload)]);
    audit_log('change_request_submitted', 'change_requests', (int)$pdo->lastInsertId(), trim($_POST['summary']));
    flash_set('success', 'Change request submitted for Main Admin approval.');
    redirect_to('operations/change_requests.php');
}

$students = $pdo->query("SELECT s.id, s.admission_no, u.full_name FROM students s JOIN users u ON u.id=s.user_id WHERE s.branch_id = {$brId} AND s.deleted_at IS NULL")->fetchAll();
$reqs = $pdo->query("SELECT * FROM change_requests WHERE branch_id = {$brId} ORDER BY id DESC LIMIT 30")->fetchAll();

$pageTitle = 'Submit Change Requests';
$showPanelSidebar = true;
include __DIR__ . '/../includes/site_header.php';
include __DIR__ . '/../includes/panel_nav.php';
?>
<div class="yu-page-head"><div><h1>Submit Edit / Delete Request to Admin</h1><p>Operations Staff changes require Super Admin approval.</p></div></div>
<div class="yu-card">
  <div class="yu-card-title">New Change Request</div>
  <form method="post">
    <?php echo csrf_field(); ?>
    <div class="yu-form-row">
      <div class="yu-field"><label>Record Type</label><select name="target_table"><option value="students">Student Record</option><option value="inquiries">Inquiry Record</option></select></div>
      <div class="yu-field"><label>Student / Record</label><select name="target_id"><?php foreach($students as $st): ?><option value="<?php echo (int)$st['id']; ?>"><?php echo e($st['admission_no'].' - '.$st['full_name']); ?></option><?php endforeach; ?></select></div>
      <div class="yu-field"><label>Request Action</label><select name="action_type"><option value="update">Update Details</option><option value="delete">Archive / Delete</option></select></div>
    </div>
    <div class="yu-form-row">
      <div class="yu-field"><label>New Father Name (If updating)</label><input type="text" name="new_father_name"></div>
      <div class="yu-field"><label>New Guardian Phone (If updating)</label><input type="text" name="new_guardian_phone"></div>
      <div class="yu-field"><label>New Roll No (If updating)</label><input type="text" name="new_roll_no"></div>
    </div>
    <div class="yu-field" style="margin-bottom:10px;"><label>Reason / Summary</label><input type="text" name="summary" required placeholder="Why this change is needed"></div>
    <button class="yu-btn yu-btn-primary yu-btn-sm" type="submit">Submit Request to Admin</button>
  </form>
</div>
<div class="yu-card">
  <div class="yu-card-title">My Branch Requests</div>
  <div class="yu-table-wrap"><table class="yu-table">
    <tr><th>ID</th><th>Action</th><th>Summary</th><th>Status</th><th>Admin Remark</th></tr>
    <?php foreach($reqs as $r): ?>
      <tr><td>#<?php echo (int)$r['id']; ?></td><td><?php echo e(strtoupper($r['action_type'].' '.$r['target_table'])); ?></td><td><?php echo e($r['summary']); ?></td><td><span class="yu-status-text <?php echo $r['status']==='approved'?'st-ok':($r['status']==='rejected'?'st-bad':'st-warn'); ?>"><?php echo e(ucfirst($r['status'])); ?></span></td><td><?php echo e($r['admin_remark']); ?></td></tr>
    <?php endforeach; ?>
  </table></div>
</div>
<?php include __DIR__ . '/../includes/site_footer.php'; ?>
