<?php
require_once __DIR__ . '/includes/auth.php';
send_security_headers();
start_secure_session();
$u = current_user();
if ($u) {
    redirect_to(role_home($u['role']));
}
header('Location: /student/login.php');
exit;
