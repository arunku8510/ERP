<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/mail_theme.php';
send_security_headers();
start_secure_session();
$pdo = db();

$tests = $pdo->query("SELECT t.*, (SELECT COUNT(*) FROM admission_test_questions q WHERE q.test_id=t.id) AS q_cnt FROM admission_tests t WHERE t.is_active=1 ORDER BY t.id DESC")->fetchAll();
$attemptCode = $_GET['result'] ?? '';
$resultRow = null;
if ($attemptCode !== '') {
    $st = $pdo->prepare("SELECT a.*, t.title AS test_title FROM admission_test_attempts a JOIN admission_tests t ON t.id=a.test_id WHERE a.candidate_code = ? LIMIT 1");
    $st->execute([$attemptCode]);
    $resultRow = $st->fetch();
}

$activeAttempt = null;
$questions = [];
if (!empty($_SESSION['adm_attempt_id'])) {
    $st = $pdo->prepare("SELECT a.*, t.title AS test_title, t.duration_minutes FROM admission_test_attempts a JOIN admission_tests t ON t.id=a.test_id WHERE a.id = ? AND a.status='in_progress' LIMIT 1");
    $st->execute([(int)$_SESSION['adm_attempt_id']]);
    $activeAttempt = $st->fetch();
    if ($activeAttempt) {
        $qSt = $pdo->prepare("SELECT * FROM admission_test_questions WHERE test_id = ? ORDER BY id ASC");
        $qSt->execute([(int)$activeAttempt['test_id']]);
        $questions = $qSt->fetchAll();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $act = $_POST['act'] ?? '';
    if ($act === 'start') {
        $testId = (int)$_POST['test_id'];
        $tRow = $pdo->query("SELECT * FROM admission_tests WHERE id = {$testId} AND is_active=1")->fetch();
        if ($tRow) {
            $code = 'YT-' . date('y') . '-' . strtoupper(bin2hex(random_bytes(3)));
            $pdo->prepare("INSERT INTO admission_test_attempts (test_id, branch_id, candidate_code, full_name, phone, email, target_class) VALUES (?, ?, ?, ?, ?, ?, ?)")
                ->execute([$testId, $tRow['branch_id'], $code, trim($_POST['full_name']), trim($_POST['phone']), trim($_POST['email'] ?? ''), trim($_POST['target_class'] ?? '')]);
            $_SESSION['adm_attempt_id'] = (int)$pdo->lastInsertId();
        }
        redirect_to('admission-test/index.php');
    } elseif ($act === 'submit' && $activeAttempt) {
        $ans = $_POST['ans'] ?? [];
        $score = 0.0;
        $maxScore = 0.0;
        foreach ($questions as $q) {
            $maxScore += (float)$q['marks'];
            if (isset($ans[$q['id']]) && $ans[$q['id']] === $q['correct_option']) {
                $score += (float)$q['marks'];
            }
        }
        $pct = $maxScore > 0 ? round(($score / $maxScore) * 100, 2) : 0;
        $schol = $pct >= 90 ? 50 : ($pct >= 75 ? 30 : ($pct >= 60 ? 15 : 0));
        $pdo->prepare("UPDATE admission_test_attempts SET answers_json = ?, score = ?, max_score = ?, percentage = ?, scholarship_pct = ?, status='completed', submitted_at = NOW() WHERE id = ?")
            ->execute([json_encode($ans), $score, $maxScore, $pct, $schol, (int)$activeAttempt['id']]);
        if (!empty($activeAttempt['email'])) {
            $body = "<p>Congratulations on completing <strong>" . e($activeAttempt['test_title']) . "</strong>!</p><p><strong>Score:</strong> {$score} / {$maxScore} ({$pct}%)<br><strong>Scholarship Awarded:</strong> {$schol}% Tuition Fee Waiver</p>";
            send_branded_email($activeAttempt['email'], $activeAttempt['full_name'], 'Yuitor Scholarship Test Result - ' . $activeAttempt['candidate_code'], $body);
        }
        $code = $activeAttempt['candidate_code'];
        unset($_SESSION['adm_attempt_id']);
        redirect_to('admission-test/index.php?result=' . urlencode($code));
    }
}

$pageTitle = 'Online Admission & Scholarship Test';
$showPanelSidebar = false;
include __DIR__ . '/../includes/site_header.php';
?>
<div style="max-width:860px;margin:16px auto;">
  <?php if ($resultRow): ?>
    <div class="yu-card" style="text-align:center;">
      <div style="font-size:12px;font-weight:700;color:#0b7b82;text-transform:uppercase;">Test Completed</div>
      <h1 style="margin:6px 0;font-family:'Manrope',sans-serif;">Result for <?php echo e($resultRow['full_name']); ?></h1>
      <p>Candidate Code: <code><?php echo e($resultRow['candidate_code']); ?></code></p>
      <div class="yu-kpi-grid" style="margin-top:16px;">
        <div class="yu-kpi"><div class="yu-kpi-label">Score</div><div class="yu-kpi-val"><?php echo e($resultRow['score'].' / '.$resultRow['max_score']); ?></div></div>
        <div class="yu-kpi"><div class="yu-kpi-label">Percentage</div><div class="yu-kpi-val"><?php echo e($resultRow['percentage']); ?>%</div></div>
        <div class="yu-kpi"><div class="yu-kpi-label">Scholarship</div><div class="yu-kpi-val st-ok"><?php echo (int)$resultRow['scholarship_pct']; ?>% OFF</div></div>
      </div>
      <a href="<?php echo e(erp_url('admission-test/result_pdf.php?code='.urlencode($resultRow['candidate_code']))); ?>" target="_blank" class="yu-btn yu-btn-primary">Download Scholarship Certificate PDF</a>
    </div>
  <?php elseif ($activeAttempt): ?>
    <div class="yu-card">
      <div class="yu-card-title"><span><?php echo e($activeAttempt['test_title']); ?></span><span style="font-size:13px;color:#2563eb;">Candidate: <?php echo e($activeAttempt['full_name']); ?> (<?php echo e($activeAttempt['candidate_code']); ?>)</span></div>
      <form method="post">
        <?php echo csrf_field(); ?><input type="hidden" name="act" value="submit">
        <?php foreach($questions as $idx => $q): ?>
          <div style="padding:14px;border:1px solid #dbe6ef;border-radius:12px;margin-bottom:14px;">
            <div style="font-weight:700;margin-bottom:8px;">Q<?php echo $idx+1; ?>. <?php echo e($q['question_text']); ?> <span style="font-size:12px;color:#64748b;">(<?php echo (int)$q['marks']; ?> marks)</span></div>
            <?php foreach(['A'=>$q['option_a'],'B'=>$q['option_b'],'C'=>$q['option_c'],'D'=>$q['option_d']] as $optKey=>$optVal): ?>
              <label style="display:block;padding:5px 8px;cursor:pointer;"><input type="radio" name="ans[<?php echo (int)$q['id']; ?>]" value="<?php echo $optKey; ?>"> <strong><?php echo $optKey; ?>.</strong> <?php echo e($optVal); ?></label>
            <?php endforeach; ?>
          </div>
        <?php endforeach; ?>
        <button class="yu-btn yu-btn-primary" type="submit">Submit Test &amp; View Instant Score</button>
      </form>
    </div>
  <?php else: ?>
    <div class="yu-card">
      <h1 style="margin:0 0 8px;font-family:'Manrope',sans-serif;">Yuitor Online Admission &amp; Scholarship Test</h1>
      <p style="color:#52687c;">Register below to take an instant scholarship assessment and download your merit certificate PDF.</p>
      <?php if (empty($tests)): ?>
        <div class="yu-alert yu-alert-info">No active admission test published yet. Admin can create one under Admin &rarr; Admission Tests.</div>
      <?php else: ?>
        <form method="post">
          <?php echo csrf_field(); ?><input type="hidden" name="act" value="start">
          <div class="yu-form-row">
            <div class="yu-field"><label>Select Test</label><select name="test_id"><?php foreach($tests as $t): ?><option value="<?php echo (int)$t['id']; ?>"><?php echo e($t['title'].' ('.$t['q_cnt'].' Qs, '.$t['duration_minutes'].' mins)'); ?></option><?php endforeach; ?></select></div>
            <div class="yu-field"><label>Target Class / Exam</label><input type="text" name="target_class" placeholder="e.g. Class 10 / JEE / NEET" required></div>
          </div>
          <div class="yu-form-row">
            <div class="yu-field"><label>Full Name</label><input type="text" name="full_name" required></div>
            <div class="yu-field"><label>Mobile Number</label><input type="text" name="phone" required></div>
            <div class="yu-field"><label>Email Address</label><input type="email" name="email" required></div>
          </div>
          <button class="yu-btn yu-btn-primary" type="submit">Start Admission Test &rarr;</button>
        </form>
      <?php endif; ?>
    </div>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/../includes/site_footer.php'; ?>
