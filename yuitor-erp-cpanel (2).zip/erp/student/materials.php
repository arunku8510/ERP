<?php
require_once __DIR__ . '/../includes/auth.php';
send_security_headers();
$user = require_role('student');
$st = current_student_record($user['id']);
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $matId = (int)$_POST['material_id'];
    $up = safe_upload($_FILES['hw_file'], 'assignments', ['application/pdf'=>'pdf','image/png'=>'png','image/jpeg'=>'jpg'], 8388608);
    if (!$up['ok']) {
        flash_set('error', $up['error']);
    } else {
        $pdo->prepare("INSERT INTO assignment_submissions (material_id, student_id, file_path, notes) VALUES (?, ?, ?, ?)
                       ON DUPLICATE KEY UPDATE file_path = VALUES(file_path), notes = VALUES(notes), submitted_at = NOW()")
            ->execute([$matId, (int)$st['id'], $up['path'], trim($_POST['notes'] ?? '')]);
        flash_set('success', 'Homework submitted successfully.');
    }
    redirect_to('student/materials.php');
}

$mats = $pdo->prepare("SELECT m.*, sub.marks, sub.teacher_feedback, sub.file_path AS sub_file FROM study_materials m LEFT JOIN assignment_submissions sub ON sub.material_id=m.id AND sub.student_id=? WHERE m.batch_id = ? AND m.deleted_at IS NULL ORDER BY m.id DESC");
$mats->execute([(int)$st['id'], (int)$st['batch_id']]);
$list = $mats->fetchAll();

$pageTitle = 'Study Materials & Homework';
$showPanelSidebar = true;
include __DIR__ . '/../includes/site_header.php';
include __DIR__ . '/../includes/panel_nav.php';
?>
<div class="yu-page-head"><div><h1>Study Materials &amp; Homework</h1></div></div>
<div class="yu-card">
  <div class="yu-table-wrap"><table class="yu-table">
    <tr><th>Title</th><th>Type</th><th>Resource</th><th>Submit Homework / Grade</th></tr>
    <?php foreach($list as $m): ?>
      <tr>
        <td><strong><?php echo e($m['title']); ?></strong><div style="font-size:12px;color:#64748b;"><?php echo e($m['description']); ?></div></td>
        <td><?php echo e(ucfirst($m['material_type'])); ?></td>
        <td><?php if($m['file_path']): ?><a class="yu-btn yu-btn-outline yu-btn-sm" target="_blank" href="<?php echo e(erp_url($m['file_path'])); ?>">Download</a><?php elseif($m['external_url']): ?><a class="yu-btn yu-btn-outline yu-btn-sm" target="_blank" href="<?php echo e($m['external_url']); ?>">Open Link</a><?php endif; ?></td>
        <td>
          <?php if ($m['material_type'] === 'homework'): ?>
            <?php if ($m['marks'] !== null): ?>
              <div class="st-ok" style="font-weight:700;margin-bottom:4px;">Marks: <?php echo e($m['marks']); ?> (<?php echo e($m['teacher_feedback']); ?>)</div>
            <?php endif; ?>
            <form method="post" enctype="multipart/form-data" style="display:flex;gap:6px;flex-wrap:wrap;align-items:center;">
              <?php echo csrf_field(); ?><input type="hidden" name="material_id" value="<?php echo (int)$m['id']; ?>">
              <input type="file" name="hw_file" required style="font-size:12px;">
              <input type="text" name="notes" placeholder="Notes" style="padding:4px 8px;border:1px solid #cbd9e6;border-radius:6px;font-size:12px;">
              <button class="yu-btn yu-btn-primary yu-btn-sm" type="submit">Upload</button>
            </form>
          <?php else: ?>--<?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
  </table></div>
</div>
<?php include __DIR__ . '/../includes/site_footer.php'; ?>
