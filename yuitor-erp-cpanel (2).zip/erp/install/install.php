<?php
// Yuitor Coaching ERP - 6-Step cPanel Auto-Installer
error_reporting(E_ALL);
@ini_set('display_errors', '0');

$lockFile = __DIR__ . '/install.lock';
$logDir = __DIR__ . '/../logs';
if (!is_dir($logDir)) { @mkdir($logDir, 0755, true); }
$logFile = $logDir . '/install_error.log';

function inst_log($msg) {
    global $logFile;
    @file_put_contents($logFile, '[' . date('Y-m-d H:i:s') . '] ' . $msg . "\n", FILE_APPEND);
}

if (file_exists($lockFile) && empty($_GET['done'])) {
    http_response_code(403);
    echo '<!DOCTYPE html><html><head><meta charset="utf-8"><title>Installer Locked</title></head><body style="font-family:Arial,sans-serif;background:#f5f9fc;padding:40px;"><div style="max-width:560px;margin:auto;background:#fff;border:1px solid #dbe6ef;border-radius:14px;padding:28px;"><h2>Yuitor ERP is Already Installed</h2><p>For security, <code>install/install.lock</code> blocks re-running the installer. Remove that file via cPanel File Manager only if you intentionally want to re-run installation.</p><a href="/erp/index.php" style="display:inline-block;margin-top:12px;background:#2563eb;color:#fff;padding:10px 18px;border-radius:8px;text-decoration:none;font-weight:bold;">Go to ERP Login</a></div></body></html>';
    exit;
}

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

$detailedMode = !empty($_SESSION['inst_debug']) || !empty($_POST['detailed_mode']);
if (isset($_POST['detailed_mode'])) {
    $_SESSION['inst_debug'] = $_POST['detailed_mode'] === '1';
    $detailedMode = $_SESSION['inst_debug'];
}

$step = isset($_GET['step']) ? max(1, min(6, (int)$_GET['step'])) : 1;
$errorMsg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $actionStep = (int)($_POST['action_step'] ?? $step);
    if ($actionStep === 3) {
        $dbHost = trim($_POST['db_host'] ?? 'localhost');
        $dbName = trim($_POST['db_name'] ?? '');
        $dbUser = trim($_POST['db_user'] ?? '');
        $dbPass = (string)($_POST['db_pass'] ?? '');
        try {
            $pdo = new PDO("mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4", $dbUser, $dbPass, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);
            $_SESSION['inst_db'] = compact('dbHost', 'dbName', 'dbUser', 'dbPass');
            header('Location: install.php?step=4');
            exit;
        } catch (Throwable $e) {
            inst_log('Step 3 DB Connect Error: ' . $e->getMessage());
            $errorMsg = 'Database connection failed. Please check Host, Database Name, Username & Password.' . ($detailedMode ? ' Details: ' . $e->getMessage() : '');
            $step = 3;
        }
    } elseif ($actionStep === 4) {
        $adminName = trim($_POST['admin_name'] ?? 'Yuitor Admin');
        $adminEmail = trim($_POST['admin_email'] ?? 'Arunku8510@gmail.com');
        $adminPhone = trim($_POST['admin_phone'] ?? '+917827289292');
        $adminPass = (string)($_POST['admin_pass'] ?? '');
        $instName = trim($_POST['institute_name'] ?? 'Yuitor Smart Classes');
        $seedDemo = !empty($_POST['seed_demo']);
        if (!filter_var($adminEmail, FILTER_VALIDATE_EMAIL) || strlen($adminPass) < 8) {
            $errorMsg = 'Valid Admin email and at least 8-character password are required.';
            $step = 4;
        } else {
            $_SESSION['inst_admin'] = compact('adminName', 'adminEmail', 'adminPhone', 'adminPass', 'instName', 'seedDemo');
            header('Location: install.php?step=5');
            exit;
        }
    } elseif ($actionStep === 5) {
        $dbInfo = $_SESSION['inst_db'] ?? null;
        $adm = $_SESSION['inst_admin'] ?? null;
        if (!$dbInfo || !$adm) {
            header('Location: install.php?step=3');
            exit;
        }
        try {
            $pdo = new PDO("mysql:host={$dbInfo['dbHost']};dbname={$dbInfo['dbName']};charset=utf8mb4", $dbInfo['dbUser'], $dbInfo['dbPass'], [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);
            $sqlPath = __DIR__ . '/database.sql';
            $sqlRaw = file_get_contents($sqlPath);
            $lines = explode("\n", $sqlRaw);
            $cleanSql = '';
            foreach ($lines as $ln) {
                $t = trim($ln);
                if ($t === '' || strpos($t, '--') === 0) continue;
                $cleanSql .= $ln . "\n";
            }
            $statements = array_filter(array_map('trim', explode(";
", $cleanSql)));
            foreach ($statements as $stmtSql) {
                if ($stmtSql !== '') {
                    $pdo->exec($stmtSql);
                }
            }

            $appKey = bin2hex(random_bytes(32));
            $dbConfigCode = "<?php
define('DB_HOST', " . var_export($dbInfo['dbHost'], true) . ");
"
                . "define('DB_NAME', " . var_export($dbInfo['dbName'], true) . ");
"
                . "define('DB_USER', " . var_export($dbInfo['dbUser'], true) . ");
"
                . "define('DB_PASS', " . var_export($dbInfo['dbPass'], true) . ");
";
            $appConfigCode = "<?php
define('APP_KEY', " . var_export($appKey, true) . ");
"
                . "define('APP_INSTALLED_AT', " . var_export(date('c'), true) . ");
";

            file_put_contents(__DIR__ . '/../config/database.php', $dbConfigCode);
            file_put_contents(__DIR__ . '/../config/app.php', $appConfigCode);

            $adminHash = password_hash($adm['adminPass'], PASSWORD_DEFAULT);
            $chk = $pdo->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
            $chk->execute([$adm['adminEmail']]);
            if (!$chk->fetchColumn()) {
                $pdo->prepare("INSERT INTO users (branch_id, role, full_name, email, phone, password_hash, is_active, twofa_enabled) VALUES (1, 'admin', ?, ?, ?, ?, 1, 1)")
                    ->execute([$adm['adminName'], $adm['adminEmail'], $adm['adminPhone'], $adminHash]);
            }
            $pdo->prepare("INSERT INTO settings (setting_key, setting_value, is_encrypted) VALUES ('institute_name', ?, 0) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)")
                ->execute([$adm['instName']]);
            $pdo->prepare("INSERT INTO settings (setting_key, setting_value, is_encrypted) VALUES ('admin_2fa_email', ?, 0) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)")
                ->execute([$adm['adminEmail']]);

            if (!empty($adm['seedDemo'])) {
                $demoPass = password_hash('Yuitor@1234', PASSWORD_DEFAULT);
                $demoUsers = [
                    [1, 'teacher', 'Rahul Sharma (Faculty)', 'teacher@yuitor.com', '+919811100001'],
                    [1, 'staff', 'Neha Verma (Branch Desk)', 'staff@yuitor.com', '+919811100002'],
                    [1, 'student', 'Aarav Kumar', 'student@yuitor.com', '+919811100003'],
                    [1, 'parent', 'Rajesh Kumar (Parent)', 'parent@yuitor.com', '+919811100004'],
                ];
                foreach ($demoUsers as $du) {
                    $c = $pdo->prepare("SELECT id FROM users WHERE email = ?");
                    $c->execute([$du[3]]);
                    if (!$c->fetchColumn()) {
                        $pdo->prepare("INSERT INTO users (branch_id, role, full_name, email, phone, password_hash, is_active) VALUES (?, ?, ?, ?, ?, ?, 1)")
                            ->execute([$du[0], $du[1], $du[2], $du[3], $du[4], $demoPass]);
                    }
                }
                $tId = (int)$pdo->query("SELECT id FROM users WHERE email = 'teacher@yuitor.com'")->fetchColumn();
                if ($tId) {
                    $pdo->prepare("INSERT IGNORE INTO teacher_batches (teacher_user_id, batch_id, subject) VALUES (?, 1, 'Mathematics & Science')")->execute([$tId]);
                }
                $stUserId = (int)$pdo->query("SELECT id FROM users WHERE email = 'student@yuitor.com'")->fetchColumn();
                $paUserId = (int)$pdo->query("SELECT id FROM users WHERE email = 'parent@yuitor.com'")->fetchColumn();
                if ($stUserId) {
                    $chkSt = $pdo->prepare("SELECT id FROM students WHERE user_id = ?");
                    $chkSt->execute([$stUserId]);
                    if (!$chkSt->fetchColumn()) {
                        $qr = bin2hex(random_bytes(16));
                        $pdo->prepare("INSERT INTO students (user_id, branch_id, session_id, course_id, batch_id, admission_no, roll_no, father_name, guardian_phone, qr_token, admission_date, status) VALUES (?, 1, 1, 1, 1, 'YS01-ADM-001', '101', 'Rajesh Kumar', '+919811100004', ?, CURDATE(), 'active')")
                            ->execute([$stUserId, $qr]);
                    }
                    $studentRowId = (int)$pdo->query("SELECT id FROM students WHERE user_id = " . $stUserId)->fetchColumn();
                    if ($paUserId && $studentRowId) {
                        $pdo->prepare("INSERT IGNORE INTO parent_students (parent_user_id, student_id, relation) VALUES (?, ?, 'Father')")->execute([$paUserId, $studentRowId]);
                    }
                }
            }

            file_put_contents($lockFile, 'INSTALLED ' . date('c'));
            header('Location: install.php?step=6&done=1');
            exit;
        } catch (Throwable $e) {
            inst_log('Step 5 Setup Error: ' . $e->getMessage());
            $errorMsg = 'Installation failed while creating tables or config files.' . ($detailedMode ? ' Details: ' . $e->getMessage() : ' Enable Detailed Error Mode or check logs/install_error.log.');
            $step = 5;
        }
    }
}

$checks = [
    ['PHP Version (7.4 - 8.3+)', version_compare(PHP_VERSION, '7.4.0', '>='), PHP_VERSION],
    ['PDO & pdo_mysql', extension_loaded('pdo') && extension_loaded('pdo_mysql'), extension_loaded('pdo_mysql') ? 'Loaded' : 'Missing'],
    ['OpenSSL (AES-256 + SMTP TLS)', extension_loaded('openssl'), extension_loaded('openssl') ? 'Loaded' : 'Missing'],
    ['Fileinfo (Safe Upload Check)', extension_loaded('fileinfo'), extension_loaded('fileinfo') ? 'Loaded' : 'Fallback'],
    ['Mbstring (UTF-8 Support)', extension_loaded('mbstring'), extension_loaded('mbstring') ? 'Loaded' : 'Missing'],
];
$permDirs = [
    'config/' => __DIR__ . '/../config',
    'uploads/' => __DIR__ . '/../uploads',
    'backups/' => __DIR__ . '/../backups',
    'logs/' => __DIR__ . '/../logs',
    'install/' => __DIR__,
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>Yuitor Smart Classes - cPanel Installer (Step <?php echo $step; ?>/6)</title>
  <link rel="icon" type="image/png" href="/erp/assets/images/yuitor-icon-192.png">
  <link rel="shortcut icon" href="/erp/assets/images/favicon.ico">
  <style>
    body{margin:0;background:#f5f9fc;font-family:Arial,Helvetica,sans-serif;color:#0f172a;padding:24px 14px;}
    .box{max-width:740px;margin:0 auto;background:#fff;border:1px solid #dbe6ef;border-radius:16px;overflow:hidden;box-shadow:0 12px 30px rgba(15,23,42,.06);}
    .head{background:linear-gradient(120deg,#0f172a,#123c52 60%,#0b7b82);color:#fff;padding:22px 28px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;}
    .steps{display:flex;gap:6px;padding:12px 28px;background:#edf5fa;border-bottom:1px solid #dbe6ef;font-size:12px;font-weight:700;overflow-x:auto;}
    .stp{padding:5px 10px;border-radius:8px;color:#52687c;white-space:nowrap;}
    .stp.on{background:#2563eb;color:#fff;}
    .body{padding:26px 28px;}
    .row{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px;}
    @media(max-width:640px){.row{grid-template-columns:1fr;}}
    label{display:block;font-size:12.5px;font-weight:700;margin-bottom:5px;color:#344b5e;}
    input[type=text],input[type=password],input[type=email]{width:100%;box-sizing:border-box;padding:10px 12px;border:1px solid #cbd9e6;border-radius:9px;font-size:14px;}
    .btn{display:inline-block;background:#2563eb;color:#fff;border:0;border-radius:10px;padding:11px 20px;font-weight:700;font-size:14px;text-decoration:none;cursor:pointer;}
    .btn2{display:inline-block;background:#fff;color:#0f172a;border:1px solid #cbd9e6;border-radius:10px;padding:10px 16px;font-weight:700;font-size:13.5px;text-decoration:none;cursor:pointer;}
    table{width:100%;border-collapse:collapse;margin:12px 0 18px;font-size:13.5px;}
    th,td{padding:9px 10px;border-bottom:1px solid #e6eef5;text-align:left;}
    .ok{color:#15803d;font-weight:700;} .bad{color:#b91c1c;font-weight:700;}
    .err{background:#fef2f2;border:1px solid #fecaca;color:#991b1b;padding:12px 14px;border-radius:10px;margin-bottom:16px;font-size:13.5px;font-weight:600;}
  </style>
</head>
<body>
<div class="box">
  <div class="head">
    <div style="display:flex;align-items:center;gap:12px;">
      <div style="width:46px;height:46px;border-radius:50%;background:#eef6fa;border:1.5px solid #78d3d3;padding:2px;flex-shrink:0;overflow:hidden;">
        <img src="../assets/images/yuitor-smart-classes-logo.png" alt="Yuitor Smart Classes" style="width:100%;height:100%;object-fit:contain;border-radius:50%;">
      </div>
      <div>
        <div style="font-size:19px;font-weight:800;">Yuitor Smart Classes</div>
        <div style="font-size:12px;color:#78d3d3;">ERP cPanel Setup Wizard (PHP <?php echo PHP_VERSION; ?>)</div>
      </div>
    </div>
    <form method="post" style="margin:0;">
      <input type="hidden" name="detailed_mode" value="<?php echo $detailedMode ? '0' : '1'; ?>">
      <button type="submit" style="background:rgba(255,255,255,.14);color:#fff;border:1px solid rgba(255,255,255,.25);border-radius:8px;padding:6px 11px;font-size:12px;font-weight:700;cursor:pointer;">
        Detailed Error Mode: <?php echo $detailedMode ? 'ON' : 'OFF'; ?>
      </button>
    </form>
  </div>
  <div class="steps">
    <?php foreach ([1=>'1. PHP Check',2=>'2. Permissions',3=>'3. Database',4=>'4. Admin Account',5=>'5. Install DB',6=>'6. Complete'] as $n=>$lbl): ?>
      <span class="stp <?php echo $step===$n?'on':''; ?>"><?php echo $lbl; ?></span>
    <?php endforeach; ?>
  </div>
  <div class="body">
    <?php if ($errorMsg !== ''): ?><div class="err"><?php echo htmlspecialchars($errorMsg, ENT_QUOTES, 'UTF-8'); ?></div><?php endif; ?>

    <?php if ($step === 1): ?>
      <h3>Step 1: Server &amp; PHP Extension Check</h3>
      <table>
        <tr><th>Requirement</th><th>Status</th><th>Detected</th></tr>
        <?php foreach ($checks as $c): ?>
          <tr><td><?php echo $c[0]; ?></td><td class="<?php echo $c[1]?'ok':'bad'; ?>"><?php echo $c[1]?'PASS':'FAIL'; ?></td><td><?php echo $c[2]; ?></td></tr>
        <?php endforeach; ?>
      </table>
      <a href="install.php?step=2" class="btn">Next: Check Folder Permissions &rarr;</a>

    <?php elseif ($step === 2): ?>
      <h3>Step 2: Writable Folder Permissions</h3>
      <p style="font-size:13.5px;color:#475569;">Ensure these directories are writable (<code>0755</code> or <code>0775</code> in cPanel File Manager):</p>
      <table>
        <tr><th>Folder</th><th>Writable?</th></tr>
        <?php foreach ($permDirs as $lbl=>$dir): $w = is_writable($dir); ?>
          <tr><td><code><?php echo $lbl; ?></code></td><td class="<?php echo $w?'ok':'bad'; ?>"><?php echo $w?'Writable (OK)':'Not Writable (chmod 755/775)'; ?></td></tr>
        <?php endforeach; ?>
      </table>
      <a href="install.php?step=1" class="btn2">&larr; Back</a>
      <a href="install.php?step=3" class="btn">Next: MySQL Database &rarr;</a>

    <?php elseif ($step === 3): ?>
      <h3>Step 3: MySQL / MariaDB Connection</h3>
      <form method="post">
        <input type="hidden" name="action_step" value="3">
        <div class="row">
          <div><label>Database Host</label><input type="text" name="db_host" value="localhost" required></div>
          <div><label>Database Name</label><input type="text" name="db_name" placeholder="e.g. cpaneluser_yuitor_erp" required></div>
        </div>
        <div class="row">
          <div><label>Database Username</label><input type="text" name="db_user" placeholder="e.g. cpaneluser_erpuser" required></div>
          <div><label>Database Password</label><input type="password" name="db_pass" required></div>
        </div>
        <a href="install.php?step=2" class="btn2">&larr; Back</a>
        <button type="submit" class="btn">Test &amp; Save Database &rarr;</button>
      </form>

    <?php elseif ($step === 4): ?>
      <h3>Step 4: Main Admin Account &amp; Institute Profile</h3>
      <form method="post">
        <input type="hidden" name="action_step" value="4">
        <div class="row">
          <div><label>Institute Name</label><input type="text" name="institute_name" value="Yuitor Smart Classes" required></div>
          <div><label>Admin Full Name</label><input type="text" name="admin_name" value="Arun Kumar" required></div>
        </div>
        <div class="row">
          <div><label>Admin Login &amp; 2FA OTP Email</label><input type="email" name="admin_email" value="Arunku8510@gmail.com" required></div>
          <div><label>Admin Phone</label><input type="text" name="admin_phone" value="+917827289292" required></div>
        </div>
        <div class="row">
          <div><label>Admin Password (min 8 chars)</label><input type="password" name="admin_pass" minlength="8" required></div>
          <div style="display:flex;align-items:center;padding-top:22px;">
            <label style="display:flex;align-items:center;gap:8px;cursor:pointer;margin:0;">
              <input type="checkbox" name="seed_demo" value="1" checked> Seed Demo Teacher / Student / Parent / Staff accounts
            </label>
          </div>
        </div>
        <a href="install.php?step=3" class="btn2">&larr; Back</a>
        <button type="submit" class="btn">Review &amp; Install &rarr;</button>
      </form>

    <?php elseif ($step === 5): ?>
      <h3>Step 5: Create 26 Database Tables &amp; Write Secure Configs</h3>
      <p>Ready to create InnoDB tables, encrypt configuration keys (`APP_KEY`), seed branch <code>YS01</code> (`YS01-2026-0001` receipts), UPI IDs (`Yuitor@ybl`, `Yuitor@icicibank`), and your Admin account.</p>
      <form method="post">
        <input type="hidden" name="action_step" value="5">
        <a href="install.php?step=4" class="btn2">&larr; Back</a>
        <button type="submit" class="btn">Run Installation Now</button>
      </form>

    <?php elseif ($step === 6): ?>
      <h3 style="color:#15803d;">Installation Completed Successfully!</h3>
      <p><code>config/database.php</code>, <code>config/app.php</code>, and <code>install/install.lock</code> have been generated.</p>
      <p><strong>Next steps:</strong></p>
      <ul>
        <li>Sign in at <a href="/erp/index.php">/erp/index.php</a> using your Admin email.</li>
        <li>Configure SMTP password for <code>No-reply@yuitor.com</code> and Fast2SMS / WhatsApp API keys under <strong>Admin &rarr; Settings</strong>.</li>
        <li>If demo accounts were seeded, default demo password is <code>Yuitor@1234</code> (change or disable before going live).</li>
      </ul>
      <a href="/erp/index.php" class="btn">Open Yuitor ERP Login &rarr;</a>
    <?php endif; ?>
  </div>
</div>
</body>
</html>
