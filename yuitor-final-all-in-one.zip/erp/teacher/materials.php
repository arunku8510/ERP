<?php
require_once __DIR__ . '/../includes/auth.php';
send_security_headers();
$user = require_role('teacher');
$pdo = db();

$batchIds = teacher_assigned_batch_ids($user['id']);
$ids = array_values(array_map('intval', $batchIds)); $ph = $ids ? implode(',', array_fill(0, count($ids), '?')) : '';
$batches = []; if ($ids) { $qb = $pdo->prepare("SELECT id, name FROM batches WHERE id IN ({$ph}) AND deleted_at IS NULL"); $qb->execute($ids); $batches = $qb->fetchAll(); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $act = $_POST['act'] ?? '';
    if ($act === 'upload_material') {
        $bId = (int)$_POST['batch_id'];
        assert_teacher_batch_access($user['id'], $bId);
        $filePath = '';
        if (!empty($_FILES['mat_file']['name'])) {
            $up = safe_upload($_FILES['mat_file'], 'materials', ['application/pdf'=>'pdf','image/png'=>'png','image/jpeg'=>'jpg','text/plain'=>'txt'], 10485760);
            if (!$up['ok']) { flash_set('error', $up['error']); redirect_to('teacher/materials.php'); }
            $filePath = $up['path'];
        }
        $pdo->prepare("INSERT INTO study_materials (batch_id, uploaded_by, title, material_type, description, file_path, external_url, due_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?)")
            ->execute([$bId, $user['id'], trim($_POST['title']), $_POST['material_type'], trim($_POST['description']), $filePath, trim($_POST['external_url'] ?? ''), !empty($_POST['due_date'])?$_POST['due_date']:null]);
        flash_set('success', 'Study material / homework published.');
    } elseif ($act === 'grade_submission') {
        $subId = (int)$_POST['sub_id'];
        $pdo->prepare("UPDATE assignment_submissions SET marks = ?, teacher_feedback = ?, graded_by = ? WHERE id = ?")
            ->execute([(float)$_POST['marks'], trim($_POST['feedback']), $user['id'], $subId]);
        flash_set('success', 'Homework submission graded.');
    }
    redirect_to('teacher/materials.php');
}

$materials = []; $submissions = [];
if ($ids) {
    $qm = $pdo->prepare("SELECT m.*, ba.name AS batch_name FROM study_materials m JOIN batches ba ON ba.id=m.batch_id WHERE m.batch_id IN ({$ph}) AND m.deleted_at IS NULL ORDER BY m.id DESC"); $qm->execute($ids); $materials = $qm->fetchAll();
    $qs = $pdo->prepare("SELECT sub.*, m.title AS hw_title, u.full_name AS student_name FROM assignment_submissions sub JOIN study_materials m ON m.id=sub.material_id JOIN students s ON s.id=sub.student_id JOIN users u ON u.id=s.user_id WHERE m.batch_id IN ({$ph}) ORDER BY sub.id DESC"); $qs->execute($ids); $submissions = $qs->fetchAll();
}

$pageTitle = 'Materials & Homework Grading';
$showPanelSidebar = true;
$portalMode = 'teacher';
include __DIR__ . '/../includes/site_header.php';
include __DIR__ . '/../includes/panel_nav.php';
?>
<div class="yu-page-head"><div><h1>Study Materials &amp; Homework</h1><p>Upload PDFs/links and grade student homework submissions.</p></div></div>
<div class="yu-card">
  <div class="yu-card-title">Publish Notes / Homework</div>
  <form method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?><input type="hidden" name="act" value="upload_material">
    <div class="yu-form-row">
      <div class="yu-field"><label>Batch</label><select name="batch_id"><?php foreach($batches as $b): ?><option value="<?php echo (int)$b['id']; ?>"><?php echo e($b['name']); ?></option><?php endforeach; ?></select></div>
      <div class="yu-field"><label>Type</label><select name="material_type"><option value="notes">Notes / PDF</option><option value="homework">Homework Assignment</option><option value="video_link">Video Link</option><option value="syllabus">Syllabus</option></select></div>
      <div class="yu-field"><label>Title</label><input type="text" name="title" required></div>
      <div class="yu-field"><label>Due Date (Optional)</label><input type="date" name="due_date"></div>
    </div>
    <div class="yu-form-row">
      <div class="yu-field"><label>File (PDF/Image/TXT)</label><input type="file" name="mat_file"></div>
      <div class="yu-field"><label>External URL (Optional)</label><input type="url" name="external_url" placeholder="https://..."></div>
    </div>
    <div class="yu-field" style="margin-bottom:10px;"><label>Instructions</label><textarea name="description" rows="2"></textarea></div>
    <button class="yu-btn yu-btn-primary yu-btn-sm" type="submit">Publish Material</button>
  </form>
</div>

<div class="yu-grid-2">
  <div class="yu-card">
    <div class="yu-card-title">Published Materials</div>
    <div class="yu-table-wrap"><table class="yu-table">
      <tr><th>Title</th><th>Batch</th><th>Type</th><th>File</th></tr>
      <?php foreach($materials as $m): ?>
        <tr><td><strong><?php echo e($m['title']); ?></strong></td><td><?php echo e($m['batch_name']); ?></td><td><?php echo e(ucfirst($m['material_type'])); ?></td><td><?php if($m['file_path']): ?><a href="<?php echo e(erp_url($m['file_path'])); ?>" target="_blank">Download</a><?php elseif($m['external_url']): ?><a href="<?php echo e($m['external_url']); ?>" target="_blank">Open Link</a><?php else: ?>-<?php endif; ?></td></tr>
      <?php endforeach; ?>
    </table></div>
  </div>
  <div class="yu-card">
    <div class="yu-card-title">Student Homework Submissions</div>
    <div class="yu-table-wrap"><table class="yu-table">
      <tr><th>Student</th><th>Homework</th><th>File</th><th>Grade</th></tr>
      <?php foreach($submissions as $sub): ?>
        <tr>
          <td><?php echo e($sub['student_name']); ?></td><td><?php echo e($sub['hw_title']); ?></td>
          <td><?php if($sub['file_path']): ?><a href="<?php echo e(erp_url($sub['file_path'])); ?>" target="_blank">View</a><?php endif; ?></td>
          <td>
            <form method="post" style="display:flex;gap:4px;">
              <?php echo csrf_field(); ?><input type="hidden" name="act" value="grade_submission"><input type="hidden" name="sub_id" value="<?php echo (int)$sub['id']; ?>">
              <input type="number" step="0.5" name="marks" value="<?php echo e($sub['marks']); ?>" placeholder="Marks" style="width:65px;padding:4px;border:1px solid #cbd9e6;border-radius:6px;">
              <input type="text" name="feedback" value="<?php echo e($sub['teacher_feedback']); ?>" placeholder="Remark" style="width:95px;padding:4px;border:1px solid #cbd9e6;border-radius:6px;">
              <button class="yu-btn yu-btn-teal yu-btn-sm" type="submit">Save</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
    </table></div>
  </div>
</div>
<?php include __DIR__ . '/../includes/site_footer.php'; ?>
