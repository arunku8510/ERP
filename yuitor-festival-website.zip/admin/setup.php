<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/api/bootstrap.php';
yu_api_init();

if (yu_has_basic_auth_identity() && yu_is_https()) {
    session_regenerate_id(true);
    $_SESSION['yu_admin_setup_authorized_at'] = time();
} else {
    unset($_SESSION['yu_admin_setup_authorized_at']);
}

require dirname(__DIR__) . '/portal-shell.php';
