<?php
declare(strict_types=1);
http_response_code(404);
header('Content-Type: application/json; charset=UTF-8');
echo json_encode(['error' => 'Not found. Use the dedicated PHP portal routes.']);
