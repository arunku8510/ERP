# Yuitor Smart Classes — Complete All-in-One Package (Website + ERP + AI Chatbot + 108k Knowledge Base)

Is ek hi ZIP file mein A-to-Z sab kuch shamil hai:

## 1. Website Frontend (Root Folder `/`)
- `index.html`, `assets/`, `about/`, `courses/`, `scholarship/`, `fee-calculator/`, `contact/`, etc.
- Header mein **Student Login** (`/student/login.php`) aur Footer mein **Teacher Login** (`/teacher/login.php`).
- Verified Yuitor contacts (`+91-7827289292`, `+91-1232314337`, `admission@yuitor.com`, `inquiry@yuitor.com`, `No-reply@yuitor.com`).

## 2. Website Backend & ERP (`/erp/`, `/api/`, `/student/`, `/teacher/`)
- PHP 8+ / MySQL ERP System (`erp/install/database.sql` & `erp/install/install.php`).
- Dedicated Student & Teacher portals + email OTP verification + `No-reply@yuitor.com` SMTP mailer.
- Zero-"admin" hidden Console Gate (`/erp/yt-ctrl-94x2-gate`) + strict RBAC & CSRF protection.

## 3. AI Customer-Support Chatbot Backend (`/chatbot/backend/`)
- `chatbot/backend/main.py` — FastAPI server (`POST /chat`, `GET /health`, `GET /stats`, static `/widget`).
- `chatbot/backend/engine.py` — SQLite FTS5 search (`chatbot/data/kb.sqlite`), Hindi/English/Hinglish/typo tolerance, Sports GK, rate limiter, 300-char limit & sanitization.
- `chatbot/backend/security.py` — Pre-answer security firewall (`Maaf kijiye, yeh jaankari share nahi ki sakti.`).
- Run commands (inside `chatbot/`):
  ```bash
  cd chatbot
  pip install -r requirements.txt
  python run_tests.py
  uvicorn backend.main:app --host 0.0.0.0 --port 8000
  ```

## 4. AI Chatbot Frontend Widget (`/chatbot/widget/`)
- `chatbot/widget/chatbot-widget.js` — Single embeddable `<script>` floating chat widget (mobile-ready, quick-reply buttons, typing indicator, ARIA keyboard accessibility).
- `chatbot/widget/demo.html` — Live demo & sample queries page.

## 5. 108,000+ Q&A Knowledge Base (`/chatbot/data/` — 102.60 MB JSONL + CSV)
- `chatbot/data/dataset.jsonl` (58.58 MB, 108,000 unique Q&As)
- `chatbot/data/dataset.csv` (44.02 MB, 108,000 unique Q&As)
- `chatbot/data/kb.sqlite` (60.95 MB prebuilt FTS5 index)
- `chatbot/data/tests.jsonl` (793 accuracy & security tests)
- Edit `chatbot/business_config.json` & run `python chatbot/generate_dataset.py` anytime to regenerate.
