<?php
require_once __DIR__ . '/../includes/auth.php';
send_security_headers();
$user = require_role('parent');
$pdo = db();

$ids = parent_linked_student_ids($user['id']);
$children = [];
if ($ids) {
    $in = implode(',', array_map('intval', $ids));
    $ph = implode(',', array_fill(0, count($childIds), '?'));
    $chSt = $pdo->prepare("SELECT s.*, u.full_name, b.name AS branch_name, ba.name AS batch_name, c.title AS course_title,
                             (SELECT COALESCE(net_amount - paid_amount, 0) FROM student_fee_accounts sfa WHERE sfa.student_id=s.id ORDER BY sfa.id DESC LIMIT 1) AS due_amt
                             FROM students s
                             JOIN users u ON u.id=s.user_id
                             LEFT JOIN branches b ON b.id=s.branch_id
                             LEFT JOIN batches ba ON ba.id=s.batch_id
                             LEFT JOIN courses c ON c.id=ba.course_id
                             WHERE s.id IN ({$ph}) AND s.deleted_at IS NULL");
    $chSt->execute(array_values($childIds));
    $children = $chSt->fetchAll();
}

$pageTitle = 'Parent Portal Overview';
$showPanelSidebar = true;
$portalMode = 'parent';
include __DIR__ . '/../includes/site_header.php';
include __DIR__ . '/../includes/panel_nav.php';
?>
<div class="yu-page-head"><div><h1>Parent &amp; Guardian Portal</h1><p>Track linked child's attendance, fees &amp; official receipts.</p></div></div>
<div class="yu-card">
  <?php if (empty($children)): ?>
    <p style="color:#64748b;">No student linked to your Parent account yet. Contact branch desk.</p>
  <?php else: ?>
    <div class="yu-table-wrap"><table class="yu-table">
      <tr><th>Student</th><th>Adm No</th><th>Branch / Batch</th><th class="num">Fee Balance Due</th><th>Links</th></tr>
      <?php foreach($children as $ch): ?>
        <tr>
          <td><strong><?php echo e($ch['full_name']); ?></strong></td>
          <td><?php echo e($ch['admission_no']); ?></td>
          <td><?php echo e($ch['branch_name'].' / '.$ch['batch_name']); ?></td>
          <td class="num <?php echo (float)$ch['due_amt']>0?'st-bad':'st-ok'; ?>"><strong><?php echo format_inr($ch['due_amt'] ?? 0); ?></strong></td>
          <td style="white-space:nowrap;">
            <a class="yu-btn yu-btn-outline yu-btn-sm" href="<?php echo e(erp_url('parent/attendance.php?student_id='.(int)$ch['id'])); ?>"><?php echo yu_icon('attendance', 13); ?> Attendance</a>
            <a class="yu-btn yu-btn-primary yu-btn-sm" href="<?php echo e(erp_url('parent/fees.php?student_id='.(int)$ch['id'])); ?>"><?php echo yu_icon('fees', 13); ?> Fees &amp; Receipts</a>
          </td>
        </tr>
      <?php endforeach; ?>
    </table></div>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/../includes/site_footer.php'; ?>
