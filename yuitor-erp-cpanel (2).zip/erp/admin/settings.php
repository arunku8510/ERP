<?php
require_once __DIR__ . '/../includes/auth.php';
send_security_headers();
$user = require_role('admin');
$pdo = db();

if (isset($_GET['download_backup'])) {
    $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    $sqlOut = "-- Yuitor ERP SQL Backup (" . date('c') . ")\nSET FOREIGN_KEY_CHECKS=0;\n";
    foreach ($tables as $tbl) {
        $create = $pdo->query("SHOW CREATE TABLE `{$tbl}`")->fetch();
        $sqlOut .= "\nDROP TABLE IF EXISTS `{$tbl}`;\n" . $create['Create Table'] . ";\n";
        $rows = $pdo->query("SELECT * FROM `{$tbl}`")->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rows as $row) {
            $vals = array_map(function($v) use ($pdo) { return $v === null ? 'NULL' : $pdo->quote((string)$v); }, array_values($row));
            $cols = implode('`,`', array_keys($row));
            $sqlOut .= "INSERT INTO `{$tbl}` (`{$cols}`) VALUES (" . implode(',', $vals) . ");\n";
        }
    }
    $sqlOut .= "SET FOREIGN_KEY_CHECKS=1;\n";
    audit_log('sql_backup_downloaded', 'settings', null, 'Full SQL dump downloaded');
    header('Content-Type: application/sql');
    header('Content-Disposition: attachment; filename="yuitor_erp_backup_' . date('Ymd_His') . '.sql"');
    echo $sqlOut;
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $act = $_POST['act'] ?? 'save_settings';
    if ($act === 'save_settings') {
        $plainKeys = [
            'institute_name', 'institute_tagline', 'institute_phone', 'institute_email', 'institute_address',
            'receipt_prefix', 'upi_id_primary', 'upi_id_secondary', 'upi_payee_name',
            'mail_from_email', 'mail_from_name', 'smtp_host', 'smtp_port', 'smtp_secure', 'smtp_user',
            'admin_2fa_email', 'fast2sms_sender_id', 'fast2sms_route', 'fast2sms_dlt_template_id',
            'whatsapp_phone_number_id', 'auto_due_reminder_days', 'late_fee_per_day'
        ];
        foreach ($plainKeys as $k) {
            if (isset($_POST[$k])) save_setting($k, trim((string)$_POST[$k]), false);
        }
        save_setting('admin_2fa_enabled', !empty($_POST['admin_2fa_enabled']) ? '1' : '0', false);

        foreach (['smtp_pass', 'fast2sms_api_key', 'whatsapp_access_token'] as $secKey) {
            if (!empty($_POST[$secKey])) {
                save_setting($secKey, trim((string)$_POST[$secKey]), true);
            }
        }
        if (!empty($_FILES['logo_file']['name'])) {
            $up = safe_upload($_FILES['logo_file'], 'logo', ['image/png'=>'png','image/jpeg'=>'jpg','image/webp'=>'webp'], 2097152);
            if ($up['ok']) {
                save_setting('institute_logo', '/erp/' . $up['path'], false);
            } else {
                flash_set('error', $up['error']);
                redirect_to('admin/settings.php');
            }
        }
        audit_log('settings_updated', 'settings', null, 'Institute / Payment / Messaging settings saved');
        flash_set('success', 'Settings saved & encrypted successfully.');
    } elseif ($act === 'restore_sql' && !empty($_FILES['sql_file']['tmp_name'])) {
        $sql = file_get_contents($_FILES['sql_file']['tmp_name']);
        $pdo->exec("SET FOREIGN_KEY_CHECKS=0");
        foreach (array_filter(array_map('trim', explode(";\n", $sql))) as $stmt) {
            if ($stmt !== '' && strpos($stmt, '--') !== 0) {
                $pdo->exec($stmt);
            }
        }
        $pdo->exec("SET FOREIGN_KEY_CHECKS=1");
        audit_log('sql_backup_restored', 'settings', null, 'Database restored from SQL upload');
        flash_set('success', 'SQL backup restored successfully.');
    }
    redirect_to('admin/settings.php');
}

$audits = $pdo->query("SELECT a.*, u.full_name FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id ORDER BY a.id DESC LIMIT 35")->fetchAll();
$pageTitle = 'Institute Settings, SMTP, Fast2SMS, WhatsApp & Backups';
$showPanelSidebar = true;
include __DIR__ . '/../includes/site_header.php';
include __DIR__ . '/../includes/panel_nav.php';
?>
<div class="yu-page-head">
  <div><h1>System Settings &amp; Encrypted Integrations</h1><p>Configure Logo, UPI IDs, No-reply@yuitor.com SMTP, Admin 2FA OTP, Fast2SMS, WhatsApp &amp; Backups.</p></div>
  <a href="?download_backup=1" class="yu-btn yu-btn-teal yu-btn-sm">Download SQL Backup</a>
</div>

<form method="post" enctype="multipart/form-data">
  <?php echo csrf_field(); ?><input type="hidden" name="act" value="save_settings">
  <div class="yu-grid-2">
    <div class="yu-card">
      <div class="yu-card-title">Institute, Logo &amp; UPI Settings</div>
      <div class="yu-form-row">
        <div class="yu-field"><label>Institute Name</label><input type="text" name="institute_name" value="<?php echo e(get_setting('institute_name','Yuitor Smart Classes')); ?>"></div>
        <div class="yu-field"><label>Tagline</label><input type="text" name="institute_tagline" value="<?php echo e(get_setting('institute_tagline')); ?>"></div>
      </div>
      <div class="yu-form-row">
        <div class="yu-field"><label>Phone</label><input type="text" name="institute_phone" value="<?php echo e(get_setting('institute_phone')); ?>"></div>
        <div class="yu-field"><label>Public Email</label><input type="email" name="institute_email" value="<?php echo e(get_setting('institute_email')); ?>"></div>
      </div>
      <div class="yu-field" style="margin-bottom:10px;"><label>Address</label><input type="text" name="institute_address" value="<?php echo e(get_setting('institute_address')); ?>"></div>
      <div class="yu-form-row">
        <div class="yu-field"><label>Primary UPI ID</label><input type="text" name="upi_id_primary" value="<?php echo e(get_setting('upi_id_primary','Yuitor@ybl')); ?>"></div>
        <div class="yu-field"><label>Secondary UPI ID</label><input type="text" name="upi_id_secondary" value="<?php echo e(get_setting('upi_id_secondary','Yuitor@icicibank')); ?>"></div>
        <div class="yu-field"><label>Receipt Prefix</label><input type="text" name="receipt_prefix" value="<?php echo e(get_setting('receipt_prefix','YS01')); ?>"></div>
      </div>
      <div class="yu-form-row">
        <div class="yu-field"><label>Late Fee / Day (Rs.)</label><input type="number" name="late_fee_per_day" value="<?php echo e(get_setting('late_fee_per_day','20')); ?>"></div>
        <div class="yu-field"><label>Upload New Logo (PNG/JPG)</label><input type="file" name="logo_file" accept="image/*"></div>
      </div>
    </div>

    <div class="yu-card">
      <div class="yu-card-title">Email Theme (No-reply@yuitor.com) &amp; Admin 2FA OTP</div>
      <div class="yu-form-row">
        <div class="yu-field"><label>From Email</label><input type="email" name="mail_from_email" value="<?php echo e(get_setting('mail_from_email','No-reply@yuitor.com')); ?>"></div>
        <div class="yu-field"><label>From Name</label><input type="text" name="mail_from_name" value="<?php echo e(get_setting('mail_from_name','Yuitor Smart Classes')); ?>"></div>
      </div>
      <div class="yu-form-row">
        <div class="yu-field"><label>SMTP Host</label><input type="text" name="smtp_host" value="<?php echo e(get_setting('smtp_host')); ?>" placeholder="mail.yuitor.com"></div>
        <div class="yu-field"><label>SMTP Port</label><input type="text" name="smtp_port" value="<?php echo e(get_setting('smtp_port','587')); ?>"></div>
        <div class="yu-field"><label>Encryption</label><select name="smtp_secure"><option value="tls" <?php echo get_setting('smtp_secure')==='tls'?'selected':''; ?>>TLS</option><option value="ssl" <?php echo get_setting('smtp_secure')==='ssl'?'selected':''; ?>>SSL</option></select></div>
      </div>
      <div class="yu-form-row">
        <div class="yu-field"><label>SMTP Username</label><input type="text" name="smtp_user" value="<?php echo e(get_setting('smtp_user','No-reply@yuitor.com')); ?>"></div>
        <div class="yu-field"><label>SMTP Password (leave blank to keep)</label><input type="password" name="smtp_pass" placeholder="********"></div>
      </div>
      <div class="yu-form-row">
        <div class="yu-field"><label>Admin 6-Digit OTP Receiver Email</label><input type="email" name="admin_2fa_email" value="<?php echo e(get_setting('admin_2fa_email','Arunku8510@gmail.com')); ?>"></div>
        <div style="display:flex;align-items:center;padding-top:20px;">
          <label style="display:flex;gap:8px;align-items:center;font-weight:700;"><input type="checkbox" name="admin_2fa_enabled" value="1" <?php echo get_setting('admin_2fa_enabled','1')==='1'?'checked':''; ?>> Require 6-Digit OTP for Admin Login</label>
        </div>
      </div>
    </div>
  </div>

  <div class="yu-card">
    <div class="yu-card-title">Fast2SMS &amp; Official WhatsApp Business Cloud API (AES-256 Encrypted)</div>
    <div class="yu-form-row">
      <div class="yu-field"><label>Fast2SMS API Key (blank = keep saved)</label><input type="password" name="fast2sms_api_key" placeholder="Enter Fast2SMS API Key"></div>
      <div class="yu-field"><label>Fast2SMS Route</label><select name="fast2sms_route"><option value="dlt" <?php echo get_setting('fast2sms_route')==='dlt'?'selected':''; ?>>DLT Approved</option><option value="q" <?php echo get_setting('fast2sms_route')==='q'?'selected':''; ?>>Quick SMS</option></select></div>
      <div class="yu-field"><label>Sender ID</label><input type="text" name="fast2sms_sender_id" value="<?php echo e(get_setting('fast2sms_sender_id','YUITOR')); ?>"></div>
      <div class="yu-field"><label>DLT Template ID</label><input type="text" name="fast2sms_dlt_template_id" value="<?php echo e(get_setting('fast2sms_dlt_template_id')); ?>"></div>
    </div>
    <div class="yu-form-row">
      <div class="yu-field"><label>WhatsApp Phone Number ID</label><input type="text" name="whatsapp_phone_number_id" value="<?php echo e(get_setting('whatsapp_phone_number_id')); ?>"></div>
      <div class="yu-field"><label>WhatsApp Access Token (blank = keep saved)</label><input type="password" name="whatsapp_access_token" placeholder="EAAG..."></div>
      <div class="yu-field"><label>Due Reminder Days Before Due Date</label><input type="number" name="auto_due_reminder_days" value="<?php echo e(get_setting('auto_due_reminder_days','3')); ?>"></div>
    </div>
    <button class="yu-btn yu-btn-primary" type="submit">Save All Settings</button>
  </div>
</form>

<div class="yu-card">
  <div class="yu-card-title">Restore Database From SQL Backup</div>
  <form method="post" enctype="multipart/form-data" style="display:flex;flex-wrap:wrap;gap:12px;align-items:center;">
    <?php echo csrf_field(); ?><input type="hidden" name="act" value="restore_sql">
    <input type="file" name="sql_file" accept=".sql" required>
    <button class="yu-btn yu-btn-danger yu-btn-sm" type="submit">Restore SQL File</button>
  </form>
</div>

<div class="yu-card" id="audit">
  <div class="yu-card-title">Audit Trail (Latest 35 Events)</div>
  <div class="yu-table-wrap"><table class="yu-table">
    <tr><th>Timestamp</th><th>User</th><th>Action</th><th>Entity</th><th>Details</th><th>IP</th></tr>
    <?php foreach ($audits as $a): ?>
      <tr><td style="font-size:12px;"><?php echo e($a['created_at']); ?></td><td><?php echo e($a['full_name'] ?: 'System'); ?></td><td><strong><?php echo e($a['action']); ?></strong></td><td><?php echo e($a['entity_type'].' #'.$a['entity_id']); ?></td><td><?php echo e($a['details']); ?></td><td style="font-size:12px;"><?php echo e($a['ip_address']); ?></td></tr>
    <?php endforeach; ?>
  </table></div>
</div>
<?php include __DIR__ . '/../includes/site_footer.php'; ?>
