<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../lib/pdf/SimplePdf.php';

$user = require_role(['admin', 'staff', 'student', 'parent']);

$pid = (int) ($_GET['id'] ?? 0);
$stmt = db()->prepare("SELECT fp.*, s.admission_no, u.full_name, u.email, b.name AS branch_name, b.code AS branch_code, c.title AS course_title, ba.name AS batch_name
                       FROM fee_payments fp
                       JOIN students s ON s.id = fp.student_id
                       JOIN users u ON u.id = s.user_id
                       JOIN branches b ON b.id = fp.branch_id
                       JOIN courses c ON c.id = s.course_id
                       JOIN batches ba ON ba.id = s.batch_id
                       WHERE fp.id = ? LIMIT 1");
$stmt->execute([$pid]);
$p = $stmt->fetch();
if (!$p) {
    http_response_code(404);
    die('Receipt not found.');
}
assert_student_access($user, (int) $p['student_id']);

$pdf = new SimplePdf();
$pdf->setFillColor(15, 23, 42);
$pdf->rect(36, 36, 523, 72, 'F');
$pdf->text(52, 65, strtoupper(get_setting('institute_name', 'YUITOR SMART CLASSES')), 16, true, 255, 255, 255);
$pdf->text(52, 84, 'OFFICIAL FEE PAYMENT RECEIPT | ' . $p['branch_name'], 10, false, 120, 211, 211);
$pdf->text(430, 68, $p['receipt_no'], 13, true, 255, 255, 255);

$pdf->setFillColor(245, 249, 252);
$pdf->rect(36, 124, 523, 180, 'F');
$pdf->setStrokeColor(219, 230, 239);
$pdf->rect(36, 124, 523, 180, 'D');

$rows = [
    ['Receipt Number:', $p['receipt_no']],
    ['Payment Status:', strtoupper(str_replace('_', ' ', $p['status']))],
    ['Student Name:', $p['full_name']],
    ['Admission No:', $p['admission_no']],
    ['Course & Batch:', $p['course_title'] . ' / ' . $p['batch_name']],
    ['Payment Date:', $p['paid_at']],
    ['Payment Mode:', strtoupper($p['payment_mode']) . ($p['utr_number'] ? ' (UTR: ' . $p['utr_number'] . ')' : '')],
    ['Amount Paid:', 'INR Rs. ' . number_format((float) $p['amount'], 2)],
];
$y = 148;
foreach ($rows as $r) {
    $pdf->text(52, $y, $r[0], 11, true, 52, 75, 94);
    $pdf->text(195, $y, $r[1], 11, false, 15, 23, 42);
    $y += 19;
}
$pdf->text(36, 330, 'Address: ' . get_setting('institute_address', YU_DEMO_ADDRESS), 9.5, false, 100, 116, 139);
$pdf->text(36, 346, 'This is a computer-generated receipt from Yuitor Smart Classes ERP.', 9.5, false, 100, 116, 139);
$pdf->output('Receipt_' . $p['receipt_no'] . '.pdf');
