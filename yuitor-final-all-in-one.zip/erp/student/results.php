<?php
require_once __DIR__ . '/../includes/auth.php';
send_security_headers();
$user = require_role('student');
$st = current_student_record($user['id']);
$rows = db()->prepare("SELECT t.title, t.subject, t.test_date, t.max_marks, tm.marks_obtained, tm.is_absent, tm.remarks
                       FROM test_marks tm JOIN batch_tests t ON t.id = tm.test_id
                       WHERE tm.student_id = ? AND t.deleted_at IS NULL ORDER BY t.test_date DESC");
$rows->execute([(int)$st['id']]);
$results = $rows->fetchAll();

$pageTitle = 'My Test Results';
$showPanelSidebar = true;
$portalMode = 'student';
include __DIR__ . '/../includes/site_header.php';
include __DIR__ . '/../includes/panel_nav.php';
?>
<div class="yu-page-head"><div><h1>My Batch Test Results</h1></div></div>
<div class="yu-card">
  <div class="yu-table-wrap"><table class="yu-table">
    <tr><th>Date</th><th>Test</th><th>Subject</th><th class="num">Scored</th><th class="num">Max Marks</th><th>Remarks</th></tr>
    <?php foreach($results as $r): ?>
      <tr>
        <td><?php echo e($r['test_date']); ?></td>
        <td><strong><?php echo e($r['title']); ?></strong></td>
        <td><?php echo e($r['subject']); ?></td>
        <td class="num"><strong><?php echo $r['is_absent'] ? '<span class="st-bad">Absent</span>' : e($r['marks_obtained']); ?></strong></td>
        <td class="num"><?php echo e($r['max_marks']); ?></td>
        <td><?php echo e($r['remarks']); ?></td>
      </tr>
    <?php endforeach; ?>
  </table></div>
</div>
<?php include __DIR__ . '/../includes/site_footer.php'; ?>
