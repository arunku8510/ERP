<?php
header('Location: /teacher/register.php', true, 301);
exit;
