<?php
declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';
yu_api_init();

try {
    $db = yu_db();
} catch (Throwable $error) {
    error_log('Yuitor portal database error: ' . $error->getMessage());
    yu_fail(503, 'The portal database is not ready. Please contact the website administrator.');
}

$studentUser = yu_require_role($db, 'student');
$method = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));

if ($method === 'GET') {
    $statement = $db->prepare(
        'SELECT id, full_name, email, phone, class_level, selected_subject,
                course_duration_months, admission_date, fee_status, next_fee_due,
                fee_alert_note, registration_status, created_at
         FROM students WHERE id = ?'
    );
    $statement->execute(array($studentUser['id']));
    $student = $statement->fetch();
    if (!$student) {
        yu_fail(404, 'Student profile not found.');
    }
    yu_json(200, array('student' => yu_public_student($student)));
}

if ($method !== 'POST') {
    header('Allow: GET, POST');
    yu_fail(405, 'Method not allowed.');
}

yu_require_same_origin();
$input = yu_read_json();
yu_require_csrf();
$action = strtolower(trim((string) ($_GET['action'] ?? '')));

if ($action !== 'change-password') {
    yu_fail(404, 'Unknown student action.');
}

$currentPassword = yu_text($input, 'currentPassword', 200, true);
$newPassword = yu_text($input, 'newPassword', 200, true);
if (strlen($newPassword) < 12) {
    yu_fail(400, 'Choose a new password with at least 12 characters.');
}

$lookup = $db->prepare('SELECT password_hash FROM students WHERE id = ?');
$lookup->execute(array($studentUser['id']));
$hash = (string) $lookup->fetchColumn();
if ($hash === '' || !password_verify($currentPassword, $hash)) {
    yu_fail(401, 'Your current password is not correct.');
}

$update = $db->prepare('UPDATE students SET password_hash = ?, updated_at = ? WHERE id = ?');
$update->execute(array(password_hash($newPassword, PASSWORD_DEFAULT), gmdate('c'), $studentUser['id']));
session_regenerate_id(true);
unset($_SESSION['yu_csrf_token']);
yu_json(200, array('updated' => true, 'csrfToken' => yu_csrf_token()));
