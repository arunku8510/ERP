<?php
require_once __DIR__ . '/config/security.php';
require_once __DIR__ . '/includes/helpers.php';
$code = isset($_GET['code']) ? (int)$_GET['code'] : http_response_code();
if (!in_array($code, [403, 404, 500], true)) $code = 403;
$titles = [
    403 => '403 - Access Restricted',
    404 => '404 - Page Not Found',
    500 => '500 - Temporary Server Error',
];
$descs = [
    403 => 'You do not have permission to view this resource or cross-branch/cross-role record.',
    404 => 'The requested ERP page or file could not be found.',
    500 => 'Something unexpected happened. Please try again or contact the Yuitor ERP administrator.',
];
$pageTitle = $titles[$code];
$showPanelSidebar = false;
include __DIR__ . '/includes/site_header.php';
?>
<div style="max-width:560px;margin:32px auto;">
  <div class="yu-card" style="text-align:center;padding:34px 26px;">
    <div style="font-size:42px;font-weight:800;color:#2563eb;font-family:'Manrope',sans-serif;"><?php echo $code; ?></div>
    <h1 style="margin:6px 0 10px;font-size:22px;"><?php echo e($titles[$code]); ?></h1>
    <p style="color:#52687c;margin:0 0 20px;"><?php echo e($descs[$code]); ?></p>
    <a href="<?php echo e(erp_url('index.php')); ?>" class="yu-btn yu-btn-primary">Return to ERP Home</a>
  </div>
</div>
<?php include __DIR__ . '/includes/site_footer.php'; ?>
