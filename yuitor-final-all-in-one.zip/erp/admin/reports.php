<?php
require_once __DIR__ . '/../includes/auth.php';
send_security_headers();
$user = require_role('admin');
$pdo = db();

if (isset($_GET['export'])) {
    $type = $_GET['export'];
    if ($type === 'defaulters') {
        csv_download_headers('yuitor_fee_defaulters_' . date('Ymd') . '.csv');
        $out = fopen('php://output', 'w');
        fputcsv($out, ['Adm No', 'Student', 'Phone', 'Branch', 'Net Fee', 'Paid', 'Due Balance']);
        $rows = $pdo->query("SELECT s.admission_no, u.full_name, u.phone, b.name, sfa.net_amount, sfa.paid_amount, (sfa.net_amount - sfa.paid_amount) AS due
                             FROM student_fee_accounts sfa JOIN students s ON s.id=sfa.student_id JOIN users u ON u.id=s.user_id JOIN branches b ON b.id=sfa.branch_id
                             WHERE sfa.net_amount > sfa.paid_amount ORDER BY due DESC")->fetchAll();
        foreach ($rows as $r) fputcsv($out, $r);
        fclose($out);
        exit;
    } elseif ($type === 'attendance_low') {
        csv_download_headers('yuitor_low_attendance_' . date('Ymd') . '.csv');
        $out = fopen('php://output', 'w');
        fputcsv($out, ['Adm No', 'Student', 'Batch', 'Present Days', 'Total Days', 'Attendance %']);
        $rows = $pdo->query("SELECT s.admission_no, u.full_name, ba.name AS batch_name,
                             SUM(CASE WHEN a.status IN ('present','late') THEN 1 ELSE 0 END) AS p_days,
                             COUNT(a.id) AS t_days,
                             ROUND(SUM(CASE WHEN a.status IN ('present','late') THEN 1 ELSE 0 END) * 100 / GREATEST(1, COUNT(a.id)), 1) AS pct
                             FROM students s JOIN users u ON u.id=s.user_id JOIN batches ba ON ba.id=s.batch_id LEFT JOIN attendance a ON a.student_id=s.id
                             WHERE s.deleted_at IS NULL GROUP BY s.id HAVING pct < 75 OR t_days = 0")->fetchAll();
        foreach ($rows as $r) fputcsv($out, $r);
        fclose($out);
        exit;
    }
}

$branchFees = $pdo->query("SELECT b.code, b.name, COALESCE(SUM(sfa.net_amount),0) AS billed, COALESCE(SUM(sfa.paid_amount),0) AS paid
                           FROM branches b LEFT JOIN student_fee_accounts sfa ON sfa.branch_id = b.id
                           WHERE b.deleted_at IS NULL GROUP BY b.id")->fetchAll();
$inqFunnel = $pdo->query("SELECT status, COUNT(*) AS cnt FROM inquiries WHERE deleted_at IS NULL GROUP BY status")->fetchAll();

$pageTitle = 'Reports & CSV Exports';
$showPanelSidebar = true;
$pageNoIndex = true;
$portalMode = 'admin';
include __DIR__ . '/../includes/site_header.php';
include __DIR__ . '/../includes/panel_nav.php';
?>
<div class="yu-page-head">
  <div><h1>Analytics, Defaulter Reports &amp; CSV Exports</h1><p>UTF-8 Excel-ready CSV exports &amp; branch financial summaries.</p></div>
  <div style="display:flex;gap:8px;flex-wrap:wrap;">
    <a href="?export=defaulters" class="yu-btn yu-btn-primary yu-btn-sm">Export Fee Defaulters CSV</a>
    <a href="?export=attendance_low" class="yu-btn yu-btn-teal yu-btn-sm">Export Low Attendance CSV</a>
  </div>
</div>

<div class="yu-grid-2">
  <div class="yu-card">
    <div class="yu-card-title">Branch Collection vs Outstanding</div>
    <div class="yu-table-wrap"><table class="yu-table">
      <tr><th>Branch</th><th class="num">Total Billed</th><th class="num">Collected</th><th class="num">Outstanding</th></tr>
      <?php foreach ($branchFees as $bf): $outAmt = max(0, (float)$bf['billed'] - (float)$bf['paid']); ?>
        <tr>
          <td><strong><?php echo e($bf['code'].' - '.$bf['name']); ?></strong></td>
          <td class="num"><?php echo format_inr($bf['billed']); ?></td>
          <td class="num st-ok"><?php echo format_inr($bf['paid']); ?></td>
          <td class="num st-bad"><?php echo format_inr($outAmt); ?></td>
        </tr>
      <?php endforeach; ?>
    </table></div>
  </div>

  <div class="yu-card">
    <div class="yu-card-title">Walk-in Inquiry Conversion Funnel</div>
    <div class="yu-table-wrap"><table class="yu-table">
      <tr><th>Stage</th><th class="num">Count</th></tr>
      <?php foreach ($inqFunnel as $if): ?>
        <tr><td><?php echo e(ucwords(str_replace('_',' ',$if['status']))); ?></td><td class="num"><strong><?php echo (int)$if['cnt']; ?></strong></td></tr>
      <?php endforeach; ?>
    </table></div>
  </div>
</div>
<?php include __DIR__ . '/../includes/site_footer.php'; ?>
