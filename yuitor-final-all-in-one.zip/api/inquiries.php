<?php
declare(strict_types=1);
require_once dirname(__DIR__) . '/erp/includes/auth.php';
send_security_headers();
start_secure_session();
header('Content-Type: application/json; charset=UTF-8');

if (strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET')) !== 'POST') {
    header('Allow: POST');
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed.']);
    exit;
}

$input = json_decode((string) file_get_contents('php://input'), true);
if (!is_array($input)) {
    $input = $_POST;
}

if (trim((string) ($input['website'] ?? $input['website_url'] ?? '')) !== '') {
    echo json_encode(['accepted' => true, 'success' => true, 'message' => 'Thank you.']);
    exit;
}

if (isset($input['csrf_token'])) {
    verify_csrf((string) $input['csrf_token']);
}

$name    = trim((string) ($input['name'] ?? ''));
$phone   = preg_replace('/[^0-9+\- ]/', '', (string) ($input['phone'] ?? ''));
$email   = strtolower(trim((string) ($input['email'] ?? '')));
$course  = trim((string) ($input['course'] ?? 'General'));
$message = trim((string) ($input['message'] ?? ''));

if (mb_strlen($name) < 2 || strlen(preg_replace('/\D+/', '', $phone)) < 10) {
    http_response_code(400);
    echo json_encode(['error' => 'Valid naam aur 10-digit phone number daalein.']);
    exit;
}
if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['error' => 'Valid email address daalein.']);
    exit;
}

$pdo = db();
$ip = client_ip();
if (!check_rate_limit($pdo, 'contact_form', $ip, 5, 15, true)) {
    http_response_code(429);
    echo json_encode(['error' => 'Bahut zyada requests bheji gayi hain. 15 minute baad try karein.']);
    exit;
}

$pdo->prepare("INSERT INTO contact_messages (branch_id, name, email, phone, course, message, status, ip_address) VALUES (1, ?, ?, ?, ?, ?, 'Unread', ?)")
    ->execute([$name, $email, $phone, $course, $message !== '' ? $message : 'Website inquiry', $ip]);

if ($course !== '' && $course !== 'General') {
    $pdo->prepare("INSERT INTO online_registrations (branch_id, student_name, email, phone, class_grade, course_interest, message, status, ip_address) VALUES (1, ?, ?, ?, ?, ?, ?, 'New', ?)")
        ->execute([$name, $email, $phone, $course, $course, $message, $ip]);
}

$adminEmail = get_setting('admin_2fa_email', YU_DEMO_ADMIN_EMAIL);
$bodyHtml = '<p>Website Contact form par naya message aaya hai:</p><ul>
  <li><strong>Name:</strong> ' . e($name) . '</li>
  <li><strong>Phone:</strong> ' . e($phone) . '</li>
  <li><strong>Email:</strong> ' . e($email ?: 'Not provided') . '</li>
  <li><strong>Course:</strong> ' . e($course) . '</li>
  <li><strong>Message:</strong> ' . nl2br(e($message)) . '</li>
</ul>';
send_branded_email($adminEmail, 'Admin', 'New Website Contact Message - Yuitor Smart Classes', $bodyHtml);

if ($email !== '') {
    $ackHtml = '<p>Thank you for contacting <strong>Yuitor Smart Classes</strong>. We have received your message regarding <strong>' . e($course) . '</strong> and our team will reach out shortly.</p>';
    send_branded_email($email, $name, 'We Received Your Inquiry - Yuitor Smart Classes', $ackHtml);
}

http_response_code(201);
echo json_encode(['accepted' => true, 'success' => true, 'message' => 'Thank you! Aapka message ERP me receive ho gaya hai.']);
