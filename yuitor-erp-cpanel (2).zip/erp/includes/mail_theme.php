<?php
// Yuitor Smart Classes - Branded HTML Email Theme & Pure-PHP SMTP Mailer
require_once __DIR__ . '/db.php';

function mail_brand_logo_url() {
    $logo = get_setting('institute_logo', '/erp/assets/images/yuitor-smart-classes-logo.png');
    if (strpos($logo, 'http://') === 0 || strpos($logo, 'https://') === 0) {
        return $logo;
    }
    $host = !empty($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'yuitor.com';
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'https';
    return $scheme . '://' . $host . '/' . ltrim($logo, '/');
}

function build_branded_email_html($title, $recipientName, $bodyHtml, $ctaLabel = '', $ctaUrl = '', $footerNote = '') {
    $instName = get_setting('institute_name', 'Yuitor Smart Classes');
    $instTag = get_setting('institute_tagline', 'AI-Assisted · Expert-Led Learning');
    $instPhone = get_setting('institute_phone', '+91 78-2728-9292');
    $instEmail = get_setting('institute_email', 'admission@yuitor.com');
    $instAddr = get_setting('institute_address', 'Trimurti Vihar, near Venus Academy, Muradnagar - 201206');
    $logoUrl = mail_brand_logo_url();
    $greeting = $recipientName !== '' ? 'Dear <strong>' . e($recipientName) . '</strong>,' : 'Hello,';
    $ctaBlock = '';
    if ($ctaLabel !== '' && $ctaUrl !== '') {
        $ctaBlock = '<div style="margin:26px 0 8px;">
            <a href="' . e($ctaUrl) . '" style="display:inline-block;background:#2563eb;color:#ffffff;text-decoration:none;font-weight:700;font-size:14px;padding:12px 26px;border-radius:10px;">' . e($ctaLabel) . '</a>
        </div>';
    }
    $noteBlock = $footerNote !== '' ? '<p style="margin:18px 0 0;font-size:12px;color:#64748b;">' . e($footerNote) . '</p>' : '';

    return '<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"></head>
<body style="margin:0;padding:0;background:#f5f9fc;font-family:Arial,Helvetica,sans-serif;color:#0f172a;">
  <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background:#f5f9fc;padding:28px 12px;">
    <tr>
      <td align="center">
        <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="max-width:600px;width:100%;background:#ffffff;border:1px solid #dbe6ef;border-radius:16px;overflow:hidden;">
          <tr>
            <td style="background:linear-gradient(120deg,#0f172a,#123c52 60%,#0b7b82);padding:22px 28px;">
              <table role="presentation" width="100%" cellspacing="0" cellpadding="0">
                <tr>
                  <td width="56" valign="middle">
                    <div style="width:46px;height:46px;background:#f5f5f7;border-radius:12px;padding:5px;text-align:center;">
                      <img src="' . e($logoUrl) . '" alt="' . e($instName) . '" width="36" height="36" style="display:block;width:36px;height:36px;object-fit:contain;margin:0 auto;">
                    </div>
                  </td>
                  <td valign="middle" style="padding-left:12px;">
                    <div style="font-size:19px;font-weight:800;color:#ffffff;line-height:1.2;">' . e($instName) . '</div>
                    <div style="font-size:11px;font-weight:700;color:#78d3d3;letter-spacing:1.2px;text-transform:uppercase;margin-top:3px;">' . e($instTag) . '</div>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          <tr>
            <td style="padding:28px 28px 24px;">
              <h2 style="margin:0 0 14px;font-size:20px;color:#0f172a;font-weight:800;">' . e($title) . '</h2>
              <p style="margin:0 0 14px;font-size:15px;line-height:1.65;color:#334155;">' . $greeting . '</p>
              <div style="font-size:15px;line-height:1.65;color:#334155;">' . $bodyHtml . '</div>
              ' . $ctaBlock . '
              ' . $noteBlock . '
            </td>
          </tr>
          <tr>
            <td style="background:#f1f6fb;border-top:1px solid #dbe6ef;padding:18px 28px;font-size:12px;line-height:1.6;color:#475569;">
              <strong>' . e($instName) . '</strong><br>
              ' . e($instAddr) . '<br>
              Phone: ' . e($instPhone) . ' &nbsp;|&nbsp; Email: ' . e($instEmail) . '<br>
              <span style="color:#64748b;">This is an automated message from No-reply@yuitor.com. Please do not reply directly to this email.</span>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>';
}

function smtp_read_line($fp) {
    $data = '';
    while ($str = fgets($fp, 515)) {
        $data .= $str;
        if (isset($str[3]) && $str[3] === ' ') break;
    }
    return $data;
}

function smtp_cmd($fp, $cmd, $expectedCodePrefix = '2') {
    if ($cmd !== '') {
        fwrite($fp, $cmd . "
");
    }
    $resp = smtp_read_line($fp);
    if (substr(trim($resp), 0, 1) !== $expectedCodePrefix && substr(trim($resp), 0, 3) !== $expectedCodePrefix) {
        return [false, $resp];
    }
    return [true, $resp];
}

function send_branded_email($toEmail, $toName, $subject, $bodyHtml, $ctaLabel = '', $ctaUrl = '', $footerNote = '') {
    $toEmail = trim((string)$toEmail);
    if (!filter_var($toEmail, FILTER_VALIDATE_EMAIL)) {
        return ['ok' => false, 'error' => 'Invalid recipient email address.'];
    }
    $fromEmail = get_setting('mail_from_email', 'No-reply@yuitor.com');
    $fromName = get_setting('mail_from_name', 'Yuitor Smart Classes');
    $html = build_branded_email_html($subject, $toName, $bodyHtml, $ctaLabel, $ctaUrl, $footerNote);

    $smtpHost = get_setting('smtp_host', '');
    $smtpPort = (int)get_setting('smtp_port', '587');
    $smtpUser = get_setting('smtp_user', '');
    $smtpPass = get_setting('smtp_pass', '');
    $smtpSecure = strtolower(get_setting('smtp_secure', 'tls'));

    if ($smtpHost !== '' && $smtpUser !== '' && $smtpPass !== '') {
        try {
            $remote = ($smtpSecure === 'ssl' ? 'ssl://' : '') . $smtpHost;
            $fp = @fsockopen($remote, $smtpPort, $errno, $errstr, 12);
            if ($fp) {
                stream_set_timeout($fp, 12);
                smtp_read_line($fp);
                smtp_cmd($fp, 'EHLO ' . ($_SERVER['HTTP_HOST'] ?? 'yuitor.com'), '2');
                if ($smtpSecure === 'tls') {
                    list($okTls,) = smtp_cmd($fp, 'STARTTLS', '2');
                    if ($okTls) {
                        stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT);
                        smtp_cmd($fp, 'EHLO ' . ($_SERVER['HTTP_HOST'] ?? 'yuitor.com'), '2');
                    }
                }
                smtp_cmd($fp, 'AUTH LOGIN', '3');
                smtp_cmd($fp, base64_encode($smtpUser), '3');
                list($okAuth, $authResp) = smtp_cmd($fp, base64_encode($smtpPass), '2');
                if (!$okAuth) {
                    fclose($fp);
                    return ['ok' => false, 'error' => 'SMTP Auth failed: ' . trim($authResp)];
                }
                smtp_cmd($fp, 'MAIL FROM:<' . $fromEmail . '>', '2');
                smtp_cmd($fp, 'RCPT TO:<' . $toEmail . '>', '2');
                smtp_cmd($fp, 'DATA', '3');
                $headers = "Date: " . date('r') . "
"
                    . "From: " . $fromName . " <" . $fromEmail . ">
"
                    . "To: " . ($toName ? $toName . ' ' : '') . "<" . $toEmail . ">
"
                    . "Reply-To: " . $fromEmail . "
"
                    . "Subject: =?UTF-8?B?" . base64_encode($subject) . "?=
"
                    . "MIME-Version: 1.0
"
                    . "Content-Type: text/html; charset=UTF-8
"
                    . "Content-Transfer-Encoding: base64

";
                $payload = $headers . chunk_split(base64_encode($html)) . "
.";
                list($okData, $dataResp) = smtp_cmd($fp, $payload, '2');
                smtp_cmd($fp, 'QUIT', '2');
                fclose($fp);
                if ($okData) {
                    return ['ok' => true, 'error' => ''];
                }
                return ['ok' => false, 'error' => 'SMTP Send failed: ' . trim($dataResp)];
            }
        } catch (Throwable $e) {
            // Fall through to PHP mail()
        }
    }

    $headers = "MIME-Version: 1.0
"
        . "Content-Type: text/html; charset=UTF-8
"
        . "From: " . $fromName . " <" . $fromEmail . ">
"
        . "Reply-To: " . $fromEmail . "
"
        . "X-Mailer: YuitorERP-PHP/" . PHP_VERSION . "
";

    $sent = @mail($toEmail, '=?UTF-8?B?' . base64_encode($subject) . '?=', $html, $headers, '-f' . $fromEmail);
    if (!$sent) {
        $sent = @mail($toEmail, '=?UTF-8?B?' . base64_encode($subject) . '?=', $html, $headers);
    }
    return ['ok' => (bool)$sent, 'error' => $sent ? '' : 'PHP mail() returned false. Configure SMTP in Admin -> Settings.'];
}

function send_otp_email($toEmail, $toName, $otpCode) {
    $body = '<p>Use the 6-digit verification code below to complete your Admin sign-in on <strong>Yuitor Smart Classes ERP</strong>:</p>
    <div style="margin:20px 0;padding:18px;background:#edf5fa;border:1px solid #cfe0eb;border-radius:12px;text-align:center;">
      <div style="font-size:12px;color:#557184;text-transform:uppercase;letter-spacing:1.5px;font-weight:700;">6-Digit Security OTP</div>
      <div style="font-size:32px;font-weight:800;letter-spacing:8px;color:#0f172a;margin-top:6px;">' . e($otpCode) . '</div>
    </div>
    <p>This OTP is valid for <strong>10 minutes</strong>. Never share this code with anyone.</p>';
    return send_branded_email($toEmail, $toName, 'Your 6-Digit Admin Login OTP - Yuitor ERP', $body, '', '', 'Requested from IP: ' . client_ip());
}

function send_forgot_password_email($toEmail, $toName, $otpCode, $resetUrl) {
    $body = '<p>We received a request to reset your Yuitor ERP password. Enter the 6-digit verification code below on the reset page:</p>
    <div style="margin:18px 0;padding:16px;background:#edf5fa;border:1px solid #cfe0eb;border-radius:12px;text-align:center;">
      <div style="font-size:12px;color:#557184;text-transform:uppercase;letter-spacing:1.2px;font-weight:700;">Password Reset Code</div>
      <div style="font-size:28px;font-weight:800;letter-spacing:6px;color:#2563eb;margin-top:6px;">' . e($otpCode) . '</div>
    </div>
    <p>This code expires in <strong>15 minutes</strong>. If you did not request a password reset, you can safely ignore this email.</p>';
    return send_branded_email($toEmail, $toName, 'Reset Your Password - Yuitor Smart Classes ERP', $body, 'Open Password Reset Page', $resetUrl);
}

function send_welcome_email($toEmail, $toName, $roleLabel, $loginUrl, $tempPassword = '') {
    $passNote = $tempPassword !== ''
        ? '<p style="background:#f8fafc;border:1px solid #dbe6ef;border-radius:10px;padding:12px 14px;"><strong>Login Email:</strong> ' . e($toEmail) . '<br><strong>Temporary Password:</strong> ' . e($tempPassword) . '</p>'
        : '<p>Your account is ready under role <strong>' . e(ucfirst($roleLabel)) . '</strong>.</p>';
    $body = '<p>Welcome to <strong>Yuitor Smart Classes ERP</strong>! Your <strong>' . e(ucfirst($roleLabel)) . '</strong> portal account has been created.</p>' . $passNote . '<p>For account safety, please change your password after signing in.</p>';
    return send_branded_email($toEmail, $toName, 'Welcome to Yuitor Smart Classes ERP', $body, 'Sign In to Portal', $loginUrl);
}

function send_fee_email($toEmail, $toName, $title, $summaryHtml, $ctaUrl = '') {
    return send_branded_email($toEmail, $toName, $title, $summaryHtml, $ctaUrl ? 'View Fee & Receipt' : '', $ctaUrl);
}
