<?php
require_once __DIR__ . '/../includes/auth.php';
send_security_headers();
$user = require_role('admin');

$pdo = db();
$totalStudents = (int)$pdo->query("SELECT COUNT(*) FROM students WHERE deleted_at IS NULL AND status='active'")->fetchColumn();
$totalBranches = (int)$pdo->query("SELECT COUNT(*) FROM branches WHERE deleted_at IS NULL AND is_active=1")->fetchColumn();
$totalCollected = (float)$pdo->query("SELECT COALESCE(SUM(amount),0) FROM fee_payments WHERE status='verified'")->fetchColumn();
$pendingUpi = (int)$pdo->query("SELECT COUNT(*) FROM fee_payments WHERE status='pending_verification'")->fetchColumn();
$pendingCR = (int)$pdo->query("SELECT COUNT(*) FROM change_requests WHERE status='pending'")->fetchColumn();
$todayPresent = (int)$pdo->query("SELECT COUNT(*) FROM attendance WHERE att_date = CURDATE() AND status IN ('present','late')")->fetchColumn();

$q = trim((string)($_GET['q'] ?? ''));
$searchHits = [];
if ($q !== '') {
    $like = '%' . $q . '%';
    $st = $pdo->prepare("SELECT 'Student' AS kind, s.admission_no AS code, u.full_name AS title, b.name AS meta, CONCAT('students.php?q=', ?) AS link
                         FROM students s JOIN users u ON u.id = s.user_id JOIN branches b ON b.id = s.branch_id
                         WHERE s.deleted_at IS NULL AND (u.full_name LIKE ? OR s.admission_no LIKE ? OR u.email LIKE ?) LIMIT 8");
    $st->execute([$q, $like, $like, $like]);
    $searchHits = $st->fetchAll();

    $fp = $pdo->prepare("SELECT 'Receipt' AS kind, fp.receipt_no AS code, CONCAT('Rs. ', fp.amount) AS title, fp.status AS meta, CONCAT('fees.php?q=', fp.receipt_no) AS link
                         FROM fee_payments fp WHERE fp.receipt_no LIKE ? OR fp.utr_number LIKE ? LIMIT 5");
    $fp->execute([$like, $like]);
    $searchHits = array_merge($searchHits, $fp->fetchAll());
}

// 7-day collection vs attendance chart data
$days = [];
for ($i = 6; $i >= 0; $i--) {
    $d = date('Y-m-d', strtotime("-{$i} days"));
    $amtSt = $pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM fee_payments WHERE status='verified' AND DATE(paid_at) = ?"); $amtSt->execute([$d]); $amt = (float)$amtSt->fetchColumn();
    $attSt = $pdo->prepare("SELECT COUNT(*) FROM attendance WHERE att_date = ? AND status IN ('present','late')"); $attSt->execute([$d]); $att = (int)$attSt->fetchColumn();
    $days[] = ['label' => date('d M', strtotime($d)), 'amt' => $amt, 'att' => $att];
}
$maxAmt = max(1000, max(array_column($days, 'amt')));

$branches = $pdo->query("SELECT b.code, b.name, b.city,
                         (SELECT COUNT(*) FROM students s WHERE s.branch_id = b.id AND s.deleted_at IS NULL AND s.status='active') AS stu_cnt,
                         (SELECT COALESCE(SUM(fp.amount),0) FROM fee_payments fp WHERE fp.branch_id = b.id AND fp.status='verified') AS fee_sum
                         FROM branches b WHERE b.deleted_at IS NULL ORDER BY b.id ASC")->fetchAll();

$audits = $pdo->query("SELECT a.*, u.full_name FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id ORDER BY a.id DESC LIMIT 8")->fetchAll();

$pageTitle = 'Admin Dashboard';
$showPanelSidebar = true;
$pageNoIndex = true;
$portalMode = 'admin';
include __DIR__ . '/../includes/site_header.php';
include __DIR__ . '/../includes/panel_nav.php';
?>
<div class="yu-page-head">
  <div>
    <h1>Super Admin Control Center</h1>
    <p>Multi-branch overview, fee approvals, attendance analytics &amp; system alerts.</p>
  </div>
  <form method="get" style="display:flex;gap:8px;align-items:center;">
    <input type="search" name="q" value="<?php echo e($q); ?>" placeholder="Search student, admission #, receipt..." style="padding:8px 12px;border:1px solid #cbd9e6;border-radius:10px;min-width:230px;">
    <button class="yu-btn yu-btn-primary yu-btn-sm" type="submit"><?php echo yu_icon('search', 14); ?> Search</button>
  </form>
</div>

<?php if ($pendingUpi > 0 || $pendingCR > 0): ?>
  <div class="yu-alert yu-alert-warning" style="display:flex;flex-wrap:wrap;gap:14px;justify-content:space-between;align-items:center;">
    <span style="display:inline-flex;align-items:center;gap:8px;"><?php echo yu_icon('alert', 16); ?> <span>Attention Required: <strong><?php echo $pendingUpi; ?></strong> UPI payment(s) awaiting verification &bull; <strong><?php echo $pendingCR; ?></strong> Staff change request(s) pending review.</span></span>
    <span style="display:flex;gap:8px;">
      <a href="<?php echo e(erp_url('admin/fees.php?tab=pending')); ?>" class="yu-btn yu-btn-outline yu-btn-sm"><?php echo yu_icon('fees', 13); ?> Verify UPI</a>
      <a href="<?php echo e(erp_url('admin/change_requests.php')); ?>" class="yu-btn yu-btn-outline yu-btn-sm"><?php echo yu_icon('requests', 13); ?> Review Requests</a>
    </span>
  </div>
<?php endif; ?>

<?php if ($q !== ''): ?>
  <div class="yu-card">
    <div class="yu-card-title">Search Results for "<?php echo e($q); ?>"</div>
    <?php if (empty($searchHits)): ?>
      <p style="margin:0;color:#64748b;">No matching student or receipt found.</p>
    <?php else: ?>
      <div class="yu-table-wrap"><table class="yu-table">
        <tr><th>Type</th><th>Ref Code</th><th>Name / Amount</th><th>Details</th><th>Action</th></tr>
        <?php foreach ($searchHits as $h): ?>
          <tr>
            <td><strong><?php echo e($h['kind']); ?></strong></td>
            <td><?php echo e($h['code']); ?></td>
            <td><?php echo e($h['title']); ?></td>
            <td><?php echo e($h['meta']); ?></td>
            <td><a class="yu-btn yu-btn-outline yu-btn-sm" href="<?php echo e(erp_url('admin/' . $h['link'])); ?>">Open</a></td>
          </tr>
        <?php endforeach; ?>
      </table></div>
    <?php endif; ?>
  </div>
<?php endif; ?>

<div class="yu-kpi-grid">
  <div class="yu-kpi">
    <div class="yu-kpi-head"><div class="yu-kpi-label">Active Students</div><span class="yu-kpi-ico"><?php echo yu_icon('students', 17); ?></span></div>
    <div class="yu-kpi-val"><?php echo number_format($totalStudents); ?></div>
    <div class="yu-kpi-sub">Across <?php echo $totalBranches; ?> active branch(es)</div>
  </div>
  <div class="yu-kpi">
    <div class="yu-kpi-head"><div class="yu-kpi-label">Verified Fee Collected</div><span class="yu-kpi-ico teal"><?php echo yu_icon('fees', 17); ?></span></div>
    <div class="yu-kpi-val"><?php echo format_inr($totalCollected); ?></div>
    <div class="yu-kpi-sub">Official ledger total</div>
  </div>
  <div class="yu-kpi">
    <div class="yu-kpi-head"><div class="yu-kpi-label">Today's Attendance</div><span class="yu-kpi-ico"><?php echo yu_icon('attendance', 17); ?></span></div>
    <div class="yu-kpi-val"><?php echo number_format($todayPresent); ?></div>
    <div class="yu-kpi-sub"><?php echo date('d M Y'); ?></div>
  </div>
  <div class="yu-kpi">
    <div class="yu-kpi-head"><div class="yu-kpi-label">Pending Approvals</div><span class="yu-kpi-ico teal"><?php echo yu_icon('requests', 17); ?></span></div>
    <div class="yu-kpi-val"><?php echo $pendingUpi + $pendingCR; ?></div>
    <div class="yu-kpi-sub"><?php echo $pendingUpi; ?> UPI &bull; <?php echo $pendingCR; ?> Requests</div>
  </div>
</div>

<div class="yu-grid-2">
  <div class="yu-card">
    <div class="yu-card-title">7-Day Fee Collection Trend (INR)</div>
    <svg viewBox="0 0 420 155" style="width:100%;height:auto;display:block;">
      <?php foreach ($days as $idx => $dy):
          $barH = max(4, (int)round(($dy['amt'] / $maxAmt) * 95));
          $x = 18 + ($idx * 58);
          $y = 115 - $barH;
      ?>
        <rect x="<?php echo $x; ?>" y="<?php echo $y; ?>" width="34" height="<?php echo $barH; ?>" rx="6" fill="#2563eb"></rect>
        <text x="<?php echo $x + 17; ?>" y="134" font-size="10" text-anchor="middle" fill="#475569"><?php echo e($dy['label']); ?></text>
        <text x="<?php echo $x + 17; ?>" y="<?php echo $y - 5; ?>" font-size="9" text-anchor="middle" fill="#0f172a"><?php echo $dy['amt'] > 0 ? round($dy['amt']) : '0'; ?></text>
      <?php endforeach; ?>
    </svg>
  </div>

  <div class="yu-card">
    <div class="yu-card-title">Branch Performance Overview</div>
    <div class="yu-table-wrap"><table class="yu-table">
      <tr><th>Code</th><th>Branch</th><th class="num">Students</th><th class="num">Verified Fees</th></tr>
      <?php foreach ($branches as $br): ?>
        <tr>
          <td><strong><?php echo e($br['code']); ?></strong></td>
          <td><?php echo e($br['name']); ?> <span style="color:#64748b;font-size:12px;">(<?php echo e($br['city']); ?>)</span></td>
          <td class="num"><?php echo (int)$br['stu_cnt']; ?></td>
          <td class="num"><?php echo format_inr($br['fee_sum']); ?></td>
        </tr>
      <?php endforeach; ?>
    </table></div>
  </div>
</div>

<div class="yu-card">
  <div class="yu-card-title">
    <span>Recent Security &amp; Activity Audit Log</span>
    <a href="<?php echo e(erp_url('admin/settings.php#audit')); ?>" class="yu-btn yu-btn-outline yu-btn-sm">Full Log</a>
  </div>
  <div class="yu-table-wrap"><table class="yu-table">
    <tr><th>Time</th><th>User</th><th>Action</th><th>Details</th><th>IP</th></tr>
    <?php foreach ($audits as $au): ?>
      <tr>
        <td style="white-space:nowrap;font-size:12px;"><?php echo e($au['created_at']); ?></td>
        <td><?php echo e($au['full_name'] ?: 'System'); ?></td>
        <td><strong><?php echo e($au['action']); ?></strong></td>
        <td><?php echo e($au['details']); ?></td>
        <td style="font-size:12px;"><?php echo e($au['ip_address']); ?></td>
      </tr>
    <?php endforeach; ?>
  </table></div>
</div>
<?php include __DIR__ . '/../includes/site_footer.php'; ?>
