<?php
require_once __DIR__ . '/../includes/auth.php';
send_security_headers();
start_secure_session();

$existing = current_user();
if ($existing) {
    if ($existing['role'] === 'parent') {
        redirect_to('/erp/parent/dashboard.php');
    }
    http_response_code(403);
    $code = 403;
    include __DIR__ . '/../error.php';
    exit;
}

$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $email = strtolower(trim((string) ($_POST['email'] ?? '')));
    $pass = (string) ($_POST['password'] ?? '');
    $ip = client_ip();
    $pdo = db();

    if (!check_rate_limit($pdo, 'parent_login_ip', $ip, 10, 15, false)) {
        $err = 'Too many attempts. Please wait 15 minutes.';
    } elseif ($email === '' || $pass === '') {
        $err = 'Email and password are required.';
    } else {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? AND role = 'parent' AND deleted_at IS NULL LIMIT 1");
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        if (!$user || !password_verify($pass, $user['password_hash'])) {
            check_rate_limit($pdo, 'parent_login_ip', $ip, 10, 15, true);
            $err = 'Invalid parent credentials.';
        } elseif ((int) $user['is_active'] !== 1) {
            $err = 'Parent account is disabled.';
        } else {
            clear_rate_limit($pdo, 'parent_login_ip', $ip);
            complete_user_login($user);
            redirect_to('/erp/parent/dashboard.php');
        }
    }
}

$pageTitle = 'Parent Portal Sign In';
$portalMode = 'parent';
$showPanelSidebar = false;
include __DIR__ . '/../includes/site_header.php';
?>
<div style="max-width:440px;margin:24px auto;">
  <div class="yu-card">
    <div style="font-size:11.5px;font-weight:700;color:#0b7b82;text-transform:uppercase;letter-spacing:.08em;">Yuitor Smart Classes · Guardian Access</div>
    <h1 style="margin:4px 0 14px;font-family:'Manrope',sans-serif;font-size:22px;">Parent Sign In</h1>
    <?php echo render_flash(); ?>
    <?php if ($err !== ''): ?><div class="yu-alert yu-alert-danger"><?php echo e($err); ?></div><?php endif; ?>
    <form method="post">
      <?php echo csrf_field(); ?>
      <div class="yu-field" style="margin-bottom:12px;"><label>Guardian Email</label><input type="email" name="email" required autocomplete="username"></div>
      <div class="yu-field" style="margin-bottom:12px;"><label>Password</label><input type="password" name="password" required autocomplete="current-password"></div>
      <div style="margin-bottom:14px;font-size:13px;"><a href="<?php echo e(erp_url('forgot-password.php?portal=parent')); ?>" style="color:#2563eb;font-weight:600;text-decoration:none;">Forgot Password?</a></div>
      <button type="submit" class="yu-btn yu-btn-primary" style="width:100%;padding:12px;">Sign In</button>
    </form>
  </div>
</div>
<?php include __DIR__ . '/../includes/site_footer.php'; ?>
