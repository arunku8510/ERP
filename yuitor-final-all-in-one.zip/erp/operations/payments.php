<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/fee_helpers.php';
send_security_headers();
$user = require_role('staff');
$pdo = db();
$brId = (int)$user['branch_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $act = $_POST['act'] ?? '';
    if ($act === 'collect_cash') {
        $stId = (int)$_POST['student_id'];
        assert_student_access($user, $stId);
        $accSt = $pdo->prepare("SELECT * FROM student_fee_accounts WHERE student_id = ? ORDER BY id DESC LIMIT 1"); $accSt->execute([$stId]); $acc = $accSt->fetch();
        if (!$acc) {
            flash_set('error', 'Student fee account not allocated yet.');
        } else {
            $res = record_fee_payment([
                'student_id' => $stId,
                'branch_id' => $brId,
                'fee_account_id' => $acc['id'],
                'amount' => (float)$_POST['amount'],
                'payment_mode' => $_POST['payment_mode'] ?? 'cash',
                'utr_number' => trim($_POST['utr_number'] ?? ''),
                'status' => 'verified',
                'remarks' => trim($_POST['remarks'] ?? 'Branch Desk Entry'),
                'collected_by' => $user['id'],
            ]);
            flash_set($res['ok'] ? 'success' : 'error', $res['ok'] ? 'Receipt issued: ' . $res['receipt_no'] : $res['error']);
        }
    } elseif ($act === 'verify_upi') {
        $pid = (int)$_POST['payment_id'];
        $pRowSt = $pdo->prepare("SELECT * FROM fee_payments WHERE id = ? AND branch_id = ? AND status = 'pending_verification'"); $pRowSt->execute([$pid, $brId]); $pRow = $pRowSt->fetch();
        if ($pRow) {
            $dec = $_POST['decision'] === 'verified' ? 'verified' : 'rejected';
            $pdo->prepare("UPDATE fee_payments SET status = ?, verified_by = ?, verified_at = NOW() WHERE id = ?")->execute([$dec, $user['id'], $pid]);
            if ($dec === 'verified') {
                recalculate_fee_account($pRow['fee_account_id']);
                notify_payment_confirmed($pid);
            }
            flash_set('success', 'Branch UPI payment ' . $dec);
        }
    }
    redirect_to('operations/payments.php');
}

$stQ = $pdo->prepare("SELECT s.id, s.admission_no, u.full_name FROM students s JOIN users u ON u.id=s.user_id WHERE s.branch_id = ? AND s.deleted_at IS NULL"); $stQ->execute([$brId]); $students = $stQ->fetchAll();
$pQ = $pdo->prepare("SELECT fp.*, u.full_name, s.admission_no FROM fee_payments fp JOIN students s ON s.id=fp.student_id JOIN users u ON u.id=s.user_id WHERE fp.branch_id = ? AND fp.status='pending_verification'"); $pQ->execute([$brId]); $pending = $pQ->fetchAll();
$rQ = $pdo->prepare("SELECT fp.*, u.full_name FROM fee_payments fp JOIN students s ON s.id=fp.student_id JOIN users u ON u.id=s.user_id WHERE fp.branch_id = ? ORDER BY fp.id DESC LIMIT 25"); $rQ->execute([$brId]); $recent = $rQ->fetchAll();

$pageTitle = 'Branch Payments & UPI Verify';
$showPanelSidebar = true;
$portalMode = 'admin';
$pageNoIndex = true;
include __DIR__ . '/../includes/site_header.php';
include __DIR__ . '/../includes/panel_nav.php';
?>
<div class="yu-page-head"><div><h1>Branch Fee Desk &amp; UPI Verification</h1></div></div>

<?php if ($pending): ?>
<div class="yu-card" style="border-color:#f59e0b;">
  <div class="yu-card-title">Pending Branch UPI Proofs</div>
  <div class="yu-table-wrap"><table class="yu-table">
    <tr><th>Student</th><th class="num">Amount</th><th>UTR</th><th>Proof</th><th>Action</th></tr>
    <?php foreach($pending as $pp): ?>
      <tr>
        <td><?php echo e($pp['full_name'].' ('.$pp['admission_no'].')'); ?></td>
        <td class="num"><?php echo format_inr($pp['amount']); ?></td>
        <td><code><?php echo e($pp['utr_number']); ?></code></td>
        <td><?php if($pp['proof_path']): ?><a target="_blank" href="<?php echo e(erp_url($pp['proof_path'])); ?>">View</a><?php endif; ?></td>
        <td><form method="post" style="display:flex;gap:6px;"><?php echo csrf_field(); ?><input type="hidden" name="act" value="verify_upi"><input type="hidden" name="payment_id" value="<?php echo (int)$pp['id']; ?>"><button class="yu-btn yu-btn-primary yu-btn-sm" name="decision" value="verified" type="submit">Verify</button><button class="yu-btn yu-btn-danger yu-btn-sm" name="decision" value="rejected" type="submit">Reject</button></form></td>
      </tr>
    <?php endforeach; ?>
  </table></div>
</div>
<?php endif; ?>

<div class="yu-card">
  <div class="yu-card-title">Record Cash / Desk Payment</div>
  <form method="post">
    <?php echo csrf_field(); ?><input type="hidden" name="act" value="collect_cash">
    <div class="yu-form-row">
      <div class="yu-field"><label>Student</label><select name="student_id"><?php foreach($students as $st): ?><option value="<?php echo (int)$st['id']; ?>"><?php echo e($st['admission_no'].' - '.$st['full_name']); ?></option><?php endforeach; ?></select></div>
      <div class="yu-field"><label>Amount (Rs.)</label><input type="number" step="0.01" name="amount" required></div>
      <div class="yu-field"><label>Mode</label><select name="payment_mode"><option value="cash">Cash</option><option value="upi">UPI</option></select></div>
      <div class="yu-field"><label>UTR (If UPI)</label><input type="text" name="utr_number"></div>
    </div>
    <button class="yu-btn yu-btn-primary yu-btn-sm" type="submit">Collect &amp; Generate Receipt</button>
  </form>
</div>

<div class="yu-card">
  <div class="yu-card-title">Recent Branch Receipts</div>
  <div class="yu-table-wrap"><table class="yu-table">
    <tr><th>Receipt #</th><th>Student</th><th class="num">Amount</th><th>Status</th><th>PDF</th></tr>
    <?php foreach($recent as $r): ?>
      <tr><td><strong><?php echo e($r['receipt_no']); ?></strong></td><td><?php echo e($r['full_name']); ?></td><td class="num"><?php echo format_inr($r['amount']); ?></td><td><?php echo e(ucwords(str_replace('_',' ',$r['status']))); ?></td><td><a class="yu-btn yu-btn-outline yu-btn-sm" target="_blank" href="<?php echo e(erp_url('student/receipt_pdf.php?id='.(int)$r['id'])); ?>">PDF</a></td></tr>
    <?php endforeach; ?>
  </table></div>
</div>
<?php include __DIR__ . '/../includes/site_footer.php'; ?>
