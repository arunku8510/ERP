<?php
require_once dirname(__DIR__) . '/erp/includes/auth.php';
send_security_headers();
start_secure_session();
$u = current_user();
if ($u && $u['role'] === 'student') {
    redirect_to('/erp/student/dashboard.php');
}
header('Location: /student/login.php');
exit;
