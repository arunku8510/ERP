<?php
require_once __DIR__ . '/icons.php';
$u = current_user();
if (!$u) return;
$role = $u['role'];
$menu = [];

if ($role === 'admin') {
    $menu = [
        ['Dashboard', 'admin/dashboard.php', 'dashboard'],
        ['Online Registrations', 'admin/online_registrations.php', 'admission'],
        ['Teacher Applications', 'admin/teacher_applications.php', 'users'],
        ['Contact Messages', 'admin/contact_messages.php', 'messaging'],
        ['Branches & Batches', 'admin/branches.php', 'branches'],
        ['Users & Faculty', 'admin/users.php', 'users'],
        ['Students', 'admin/students.php', 'students'],
        ['Attendance', 'admin/attendance.php', 'attendance'],
        ['Fees & Receipts', 'admin/fees.php', 'fees'],
        ['Change Requests', 'admin/change_requests.php', 'requests'],
        ['Messaging & Queue', 'admin/messaging.php', 'messaging'],
        ['Admission Tests', 'admin/admission_tests.php', 'tests'],
        ['Reports & Exports', 'admin/reports.php', 'reports'],
        ['Settings & Backups', 'admin/settings.php', 'settings'],
    ];
} elseif ($role === 'teacher') {
    $menu = [
        ['Dashboard', 'teacher/dashboard.php', 'dashboard'],
        ['My Batch Students', 'teacher/students.php', 'students'],
        ['Mark Attendance', 'teacher/attendance.php', 'attendance'],
        ['Materials & Homework', 'teacher/materials.php', 'materials'],
        ['Batch Tests & Marks', 'teacher/tests.php', 'tests'],
        ['Batch Notices', 'teacher/notices.php', 'notices'],
    ];
} elseif ($role === 'student') {
    $menu = [
        ['My Dashboard', 'student/dashboard.php', 'dashboard'],
        ['Attendance', 'student/attendance.php', 'attendance'],
        ['Materials & Homework', 'student/materials.php', 'materials'],
        ['Test Results', 'student/results.php', 'results'],
        ['Fees & Pay UPI', 'student/fees.php', 'fees'],
        ['My QR ID Card', 'student/id_card.php', 'id-card'],
    ];
} elseif ($role === 'parent') {
    $menu = [
        ['Child Overview', 'parent/dashboard.php', 'dashboard'],
        ['Attendance Record', 'parent/attendance.php', 'attendance'],
        ['Fees & Receipts', 'parent/fees.php', 'fees'],
    ];
} elseif ($role === 'staff') {
    $menu = [
        ['Branch Dashboard', 'operations/dashboard.php', 'dashboard'],
        ['Online Registrations', 'admin/online_registrations.php', 'admission'],
        ['Contact Messages', 'admin/contact_messages.php', 'messaging'],
        ['Inquiries & Admissions', 'operations/admissions.php', 'admission'],
        ['Branch Attendance', 'operations/attendance.php', 'attendance'],
        ['Payments & UPI Verify', 'operations/payments.php', 'fees'],
        ['Change Requests', 'operations/change_requests.php', 'requests'],
    ];
}
?>
<aside class="yu-sidebar" aria-label="Portal Navigation">
  <div class="yu-sidebar-user">
    <div class="yu-sidebar-role" style="display:flex;align-items:center;gap:6px;">
      <?php echo yu_icon('shield', 14); ?>
      <span><?php echo e($role === 'staff' ? 'Operations Staff' : ucfirst($role) . ' Panel'); ?></span>
    </div>
    <div class="yu-sidebar-name"><?php echo e($u['full_name']); ?></div>
    <div style="font-size:12px;color:#52687c;word-break:break-all;"><?php echo e($u['email']); ?></div>
  </div>
  <nav class="yu-side-nav">
    <?php foreach ($menu as $item):
        $active = is_active_nav($item[1]) ? 'active' : '';
    ?>
      <a class="yu-side-link <?php echo $active; ?>" href="<?php echo e(erp_url($item[1])); ?>">
        <span class="yu-side-link-main">
          <span class="yu-side-link-ico"><?php echo yu_icon($item[2], 15); ?></span>
          <span><?php echo e($item[0]); ?></span>
        </span>
        <?php echo yu_icon('chevron-right', 14); ?>
      </a>
    <?php endforeach; ?>
    <a class="yu-side-link" href="<?php echo e(erp_url('logout.php')); ?>" style="color:#b91c1c;margin-top:8px;border-top:1px solid #e6eef5;padding-top:12px;">
      <span class="yu-side-link-main">
        <span class="yu-side-link-ico" style="background:#fef2f2;color:#b91c1c;"><?php echo yu_icon('logout', 15); ?></span>
        <span>Sign Out</span>
      </span>
    </a>
  </nav>
</aside>
<div class="yu-main-content">
<?php echo render_flash(); ?>
