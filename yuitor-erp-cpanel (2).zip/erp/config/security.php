<?php
// Yuitor Coaching ERP - Security & Encryption Helpers
if (!defined('YUITOR_ERP')) {
    define('YUITOR_ERP', true);
}

function app_secret_key() {
    if (defined('APP_KEY') && strlen(APP_KEY) >= 16) {
        return APP_KEY;
    }
    return 'yuitor_fallback_change_this_key_2026!';
}

function encrypt_secret($plain) {
    $plain = (string)$plain;
    if ($plain === '') return '';
    if (!function_exists('openssl_encrypt')) {
        return 'b64:' . base64_encode($plain);
    }
    $key = hash('sha256', app_secret_key(), true);
    $iv = openssl_random_pseudo_bytes(16);
    $cipher = openssl_encrypt($plain, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
    return base64_encode($iv . $cipher);
}

function decrypt_secret($encoded) {
    $encoded = (string)$encoded;
    if ($encoded === '') return '';
    if (strpos($encoded, 'b64:') === 0) {
        return (string)base64_decode(substr($encoded, 4));
    }
    if (!function_exists('openssl_decrypt')) {
        return '';
    }
    $raw = base64_decode($encoded, true);
    if ($raw === false || strlen($raw) < 17) return '';
    $iv = substr($raw, 0, 16);
    $cipher = substr($raw, 16);
    $key = hash('sha256', app_secret_key(), true);
    $out = openssl_decrypt($cipher, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
    return $out === false ? '' : $out;
}

function send_security_headers() {
    if (headers_sent()) return;
    header('X-Frame-Options: SAMEORIGIN');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('X-XSS-Protection: 1; mode=block');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
}

function start_secure_session() {
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }
    $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https')
        || (isset($_SERVER['SERVER_PORT']) && (int)$_SERVER['SERVER_PORT'] === 443);

    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.cookie_httponly', '1');

    if (PHP_VERSION_ID >= 70300) {
        session_set_cookie_params([
            'lifetime' => 0,
            'path' => '/erp/',
            'domain' => '',
            'secure' => $isHttps,
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
    } else {
        session_set_cookie_params(0, '/erp/; samesite=Lax', '', $isHttps, true);
    }

    session_name('YUITORERPSESS');
    session_start();

    $ua = isset($_SERVER['HTTP_USER_AGENT']) ? substr($_SERVER['HTTP_USER_AGENT'], 0, 180) : '';
    if (!isset($_SESSION['_ua'])) {
        $_SESSION['_ua'] = hash('sha256', $ua);
    } elseif (!hash_equals($_SESSION['_ua'], hash('sha256', $ua))) {
        $_SESSION = [];
        session_destroy();
        session_start();
        $_SESSION['_ua'] = hash('sha256', $ua);
    }

    $now = time();
    if (isset($_SESSION['_last_activity']) && ($now - (int)$_SESSION['_last_activity']) > 1800) {
        $wasLogged = !empty($_SESSION['user_id']);
        $_SESSION = [];
        session_destroy();
        session_start();
        if ($wasLogged) {
            $_SESSION['flash'] = ['type' => 'warning', 'msg' => 'Session expired after 30 minutes of inactivity. Please sign in again.'];
        }
    }
    $_SESSION['_last_activity'] = $now;
}

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function csrf_token() {
    start_secure_session();
    if (empty($_SESSION['_csrf_token'])) {
        $_SESSION['_csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['_csrf_token'];
}

function csrf_field() {
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}

function verify_csrf() {
    start_secure_session();
    $token = isset($_POST['csrf_token']) ? (string)$_POST['csrf_token'] : (isset($_SERVER['HTTP_X_CSRF_TOKEN']) ? (string)$_SERVER['HTTP_X_CSRF_TOKEN'] : '');
    if (empty($_SESSION['_csrf_token']) || $token === '' || !hash_equals($_SESSION['_csrf_token'], $token)) {
        http_response_code(403);
        die('Invalid or expired security token (CSRF). Please go back, refresh the page, and try again.');
    }
}

function client_ip() {
    $keys = ['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'];
    foreach ($keys as $k) {
        if (!empty($_SERVER[$k])) {
            $parts = explode(',', $_SERVER[$k]);
            return substr(trim($parts[0]), 0, 60);
        }
    }
    return '0.0.0.0';
}
