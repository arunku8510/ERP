<?php
// Run daily 2 AM via cPanel Cron: 0 2 * * * /usr/local/bin/php -q /home/USER/public_html/erp/cron/db_backup.php
if (php_sapi_name() !== 'cli') { http_response_code(403); exit('CLI only'); }
require_once __DIR__ . '/../includes/db.php';

$pdo = db();
$tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
$out = "-- Automated Yuitor ERP Backup (" . date('c') . ")\nSET FOREIGN_KEY_CHECKS=0;\n";
foreach ($tables as $t) {
    $create = $pdo->query("SHOW CREATE TABLE `{$t}`")->fetch();
    $out .= "\nDROP TABLE IF EXISTS `{$t}`;\n" . $create['Create Table'] . ";\n";
    foreach ($pdo->query("SELECT * FROM `{$t}`")->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $vals = array_map(function($v) use ($pdo) { return $v === null ? 'NULL' : $pdo->quote((string)$v); }, array_values($row));
        $out .= "INSERT INTO `{$t}` (`" . implode('`,`', array_keys($row)) . "`) VALUES (" . implode(',', $vals) . ");\n";
    }
}
$out .= "SET FOREIGN_KEY_CHECKS=1;\n";
$dir = __DIR__ . '/../backups';
if (!is_dir($dir)) mkdir($dir, 0755, true);
$fname = $dir . '/backup_' . date('Ymd_His') . '.sql';
file_put_contents($fname, $out);

// Keep latest 14 backups
$files = glob($dir . '/backup_*.sql');
if ($files && count($files) > 14) {
    sort($files);
    foreach (array_slice($files, 0, count($files) - 14) as $old) @unlink($old);
}
echo "Saved backup: {$fname}\n";
