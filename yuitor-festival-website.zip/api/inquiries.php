<?php
declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';
yu_api_init();

if (strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET')) !== 'POST') {
    header('Allow: POST');
    yu_fail(405, 'Method not allowed.');
}

yu_require_same_origin();
$input = yu_read_json(16000);
$now = time();
if (isset($_SESSION['yuitor_last_inquiry']) && ($now - (int) $_SESSION['yuitor_last_inquiry']) < 15) {
    yu_fail(429, 'Please wait a few seconds before sending another enquiry.');
}

$name = yu_text($input, 'name', 120, true);
$phone = yu_text($input, 'phone', 24, true);
$email = yu_email(yu_text($input, 'email', 254), false);
$course = yu_text($input, 'course', 120, true);
$message = yu_text($input, 'message', 2000);

if (strlen($name) < 2) {
    yu_fail(400, 'Please enter your name.');
}
if (!yu_valid_phone($phone)) {
    yu_fail(400, 'Please enter a valid phone number.');
}

try {
    $db = yu_db();
    $insert = $db->prepare(
        "INSERT INTO inquiries (name, phone, email, course, message, status, received_at)
         VALUES (?, ?, ?, ?, ?, 'new', ?)"
    );
    $insert->execute(array($name, $phone, $email, $course, $message, gmdate('c')));
} catch (Throwable $error) {
    error_log('Yuitor inquiry storage error: ' . $error->getMessage());
    yu_fail(503, 'Your enquiry could not be saved right now. Please try again later.');
}

$_SESSION['yuitor_last_inquiry'] = $now;

// Keep the existing optional email notification, but never make storage depend on mail().
$recipient = 'admission@yuitor.com';
$subject = 'New website inquiry - Yuitor';
$body = "A new inquiry was submitted on the Yuitor website.\n\n"
    . "Student: {$name}\nPhone: {$phone}\nEmail: " . ($email !== '' ? $email : 'Not provided') . "\n"
    . "Course / class: {$course}\nMessage: " . ($message !== '' ? $message : 'Not provided') . "\n"
    . "Received (UTC): " . gmdate('c') . "\n";
@mail($recipient, $subject, $body, "From: admission@yuitor.com\r\nContent-Type: text/plain; charset=UTF-8");

yu_json(201, array(
    'accepted' => true,
    'success' => true,
    'message' => 'Thank you. Your enquiry has been received.',
));
