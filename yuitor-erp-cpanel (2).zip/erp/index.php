<?php
require_once __DIR__ . '/includes/auth.php';
send_security_headers();
start_secure_session();

$existing = current_user();
if ($existing) {
    redirect_to(role_home($existing['role']));
}

$error = '';
if (!isset($_SESSION['login_fail_count'])) $_SESSION['login_fail_count'] = 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $email = trim((string)($_POST['email'] ?? ''));
    $pass = (string)($_POST['password'] ?? '');

    if ($_SESSION['login_fail_count'] >= 3) {
        $capAns = (int)($_POST['captcha_ans'] ?? -999);
        $expected = (int)($_SESSION['captcha_expected'] ?? -111);
        if ($capAns !== $expected) {
            $error = 'Incorrect security math answer. Please try again.';
        }
    }

    if ($error === '') {
        $stmt = db()->prepare("SELECT * FROM users WHERE email = ? AND deleted_at IS NULL LIMIT 1");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && !empty($user['locked_until']) && strtotime($user['locked_until']) > time()) {
            $error = 'Account temporarily locked due to multiple failed attempts. Try again after 15 minutes.';
        } elseif (!$user || !password_verify($pass, $user['password_hash'])) {
            $_SESSION['login_fail_count']++;
            if ($user) {
                $fails = (int)$user['failed_attempts'] + 1;
                $lockSql = $fails >= 5 ? ", locked_until = DATE_ADD(NOW(), INTERVAL 15 MINUTE)" : "";
                db()->prepare("UPDATE users SET failed_attempts = ? {$lockSql} WHERE id = ?")->execute([$fails, (int)$user['id']]);
            }
            audit_log('login_failed', 'users', $user ? (int)$user['id'] : null, 'Email: ' . $email);
            $error = 'Invalid email address or password.';
        } elseif ((int)$user['is_active'] !== 1) {
            $error = 'Your account is currently disabled. Contact the institute administrator.';
        } else {
            $_SESSION['login_fail_count'] = 0;
            $twoFaOn = get_setting('admin_2fa_enabled', '1') === '1';
            if ($user['role'] === 'admin' && ((int)$user['twofa_enabled'] === 1 || $twoFaOn)) {
                $otp = generate_6digit_otp((int)$user['id'], 'admin_2fa', 10);
                $otpDest = get_setting('admin_2fa_email', $user['email']);
                if (!filter_var($otpDest, FILTER_VALIDATE_EMAIL)) {
                    $otpDest = $user['email'];
                }
                $_SESSION['pending_2fa_uid'] = (int)$user['id'];
                $_SESSION['pending_2fa_email'] = $otpDest;
                $mailRes = send_otp_email($otpDest, $user['full_name'], $otp);
                if (!$mailRes['ok']) {
                    $_SESSION['otp_mail_warn'] = 'Email delivery warning: ' . $mailRes['error'];
                }
                redirect_to('verify-otp.php');
            }
            complete_user_login($user);
            redirect_to(role_home($user['role']));
        }
    }
}

$needCaptcha = ($_SESSION['login_fail_count'] ?? 0) >= 3;
if ($needCaptcha) {
    $a = random_int(2, 12);
    $b = random_int(2, 9);
    $_SESSION['captcha_expected'] = $a + $b;
    $_SESSION['captcha_q'] = $a . ' + ' . $b;
}

$pageTitle = 'Yuitor Smart Classes — ERP Sign In';
$showPanelSidebar = false;
include __DIR__ . '/includes/site_header.php';
$brandLogo = get_setting('institute_logo', '/erp/assets/images/yuitor-smart-classes-logo.png');
$brandName = get_setting('institute_name', 'Yuitor Smart Classes');
?>
<div style="max-width:1000px;margin:18px auto 0;">
  <div class="yu-grid-2" style="align-items:stretch;">
    <div class="yu-card" style="margin:0;">
      <div style="display:flex;align-items:center;gap:12px;margin-bottom:14px;">
        <div style="width:52px;height:52px;border-radius:50%;background:#eef6fa;border:1.5px solid #bfe3eb;padding:3px;flex-shrink:0;overflow:hidden;">
          <img src="<?php echo e($brandLogo); ?>" alt="<?php echo e($brandName); ?>" style="width:100%;height:100%;object-fit:contain;border-radius:50%;">
        </div>
        <div>
          <div style="font-size:11.5px;font-weight:700;color:#0b7b82;text-transform:uppercase;letter-spacing:.08em;display:flex;align-items:center;gap:5px;"><?php echo yu_icon('shield', 13); ?> <?php echo e($brandName); ?></div>
          <h1 style="margin:2px 0 0;font-family:'Manrope',sans-serif;font-size:24px;font-weight:800;color:#0f172a;">Sign In to Your Portal</h1>
        </div>
      </div>
      <p style="margin:0 0 18px;font-size:13.5px;color:#52687c;">Role-protected access for Admin, Faculty, Students, Parents &amp; Branch Operations.</p>

      <?php echo render_flash(); ?>
      <?php if ($error !== ''): ?>
        <div class="yu-alert yu-alert-danger" style="display:flex;align-items:center;gap:8px;"><?php echo yu_icon('alert', 16); ?> <span><?php echo e($error); ?></span></div>
      <?php endif; ?>

      <form method="post" autocomplete="on">
        <?php echo csrf_field(); ?>
        <div class="yu-field" style="margin-bottom:14px;">
          <label for="loginEmail" style="display:flex;align-items:center;gap:6px;"><?php echo yu_icon('mail', 14); ?> Email Address</label>
          <input id="loginEmail" type="email" name="email" required placeholder="e.g. Arunku8510@gmail.com">
        </div>
        <div class="yu-field" style="margin-bottom:14px;">
          <label for="loginPass" style="display:flex;align-items:center;gap:6px;"><?php echo yu_icon('lock', 14); ?> Password</label>
          <input id="loginPass" type="password" name="password" required placeholder="Enter password">
        </div>
        <?php if ($needCaptcha): ?>
          <div class="yu-field" style="margin-bottom:14px;background:#fffbeb;border:1px solid #fde68a;padding:12px;border-radius:10px;">
            <label for="captchaAns" style="display:flex;align-items:center;gap:6px;"><?php echo yu_icon('shield', 14); ?> Security Check: What is <?php echo e($_SESSION['captcha_q']); ?>?</label>
            <input id="captchaAns" type="number" name="captcha_ans" required placeholder="Enter numeric answer">
          </div>
        <?php endif; ?>
        <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:16px;">
          <a href="<?php echo e(erp_url('forgot-password.php')); ?>" style="display:inline-flex;align-items:center;gap:5px;font-size:13px;font-weight:600;color:#2563eb;text-decoration:none;"><?php echo yu_icon('lock', 13); ?> Forgot Password?</a>
          <a href="<?php echo e(erp_url('admission-test/index.php')); ?>" style="display:inline-flex;align-items:center;gap:5px;font-size:13px;font-weight:600;color:#0b7b82;text-decoration:none;"><?php echo yu_icon('award', 13); ?> Public Admission Test &rarr;</a>
        </div>
        <button type="submit" class="yu-btn yu-btn-primary" style="width:100%;padding:12px;"><?php echo yu_icon('shield', 16); ?> Sign In Securely</button>
      </form>
    </div>

    <div class="yu-card" style="margin:0;background:linear-gradient(155deg,#0f172a,#123c52 65%,#0b7b82);color:#eef6fa;border-color:#124c5b;">
      <h2 style="margin:0 0 10px;font-family:'Manrope',sans-serif;font-size:21px;color:#fff;display:flex;align-items:center;gap:9px;"><?php echo yu_icon('sparkles', 20); ?> <?php echo e($brandName); ?> ERP</h2>
      <p style="margin:0 0 16px;font-size:13.5px;color:#cde0ea;">Built for multi-branch academic operations, strict role separation, UPI fee verification, and automated alerts.</p>
      <div style="display:grid;gap:10px;font-size:13.5px;">
        <div style="display:flex;align-items:flex-start;gap:10px;padding:10px 12px;border-radius:10px;background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.12);">
          <span style="color:#78d3d3;margin-top:2px;"><?php echo yu_icon('dashboard', 17); ?></span>
          <div><strong style="color:#78d3d3;">Main Admin:</strong> Branches, sessions, staff change approvals, fee ledger, Fast2SMS/WhatsApp/Email &amp; SQL backups.</div>
        </div>
        <div style="display:flex;align-items:flex-start;gap:10px;padding:10px 12px;border-radius:10px;background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.12);">
          <span style="color:#78d3d3;margin-top:2px;"><?php echo yu_icon('book', 17); ?></span>
          <div><strong style="color:#78d3d3;">Teachers:</strong> Assigned-batch attendance, homework grading &amp; marks upload (zero fee access, masked contacts).</div>
        </div>
        <div style="display:flex;align-items:flex-start;gap:10px;padding:10px 12px;border-radius:10px;background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.12);">
          <span style="color:#78d3d3;margin-top:2px;"><?php echo yu_icon('graduation', 17); ?></span>
          <div><strong style="color:#78d3d3;">Students &amp; Parents:</strong> Attendance, materials, results, QR ID card, UPI fee payment &amp; PDF receipts.</div>
        </div>
        <div style="display:flex;align-items:flex-start;gap:10px;padding:10px 12px;border-radius:10px;background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.12);">
          <span style="color:#78d3d3;margin-top:2px;"><?php echo yu_icon('branches', 17); ?></span>
          <div><strong style="color:#78d3d3;">Branch Operations:</strong> Walk-in inquiries, admissions, cash/UPI desk &amp; Admin-approved edit requests.</div>
        </div>
      </div>
      <div style="margin-top:16px;padding-top:12px;border-top:1px solid rgba(255,255,255,0.14);font-size:12px;color:#b8cdd8;display:flex;align-items:center;gap:6px;flex-wrap:wrap;">
        <?php echo yu_icon('otp', 14); ?>
        <span>Admin 2FA via <code>No-reply@yuitor.com</code> &bull; UPI: <code>Yuitor@ybl</code> / <code>Yuitor@icicibank</code></span>
      </div>
    </div>
  </div>
</div>
<?php include __DIR__ . '/includes/site_footer.php'; ?>
