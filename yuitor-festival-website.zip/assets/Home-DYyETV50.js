import { r as React, j as jsxRuntime, L as Link } from "./index-BXOcHfSn.js";

const h = jsxRuntime.jsx;
const hs = jsxRuntime.jsxs;
const image = (name) => `/assets/images/${name}`;

function Mark({ children }) {
  return h("span", { className: "yn-mark", "aria-hidden": "true", children });
}

function Eyebrow({ number, children }) {
  return hs("div", {
    className: "yn-eyebrow",
    children: [
      number && h("span", { className: "yn-eyebrow-number", children: number }),
      h("span", { className: "yn-eyebrow-line", "aria-hidden": "true" }),
      h("span", { children })
    ]
  });
}

const prices = [
  { title: "Classes 6–8", detail: "School learning", price: "₹900–₹1,300", unit: "per month", icon: "01" },
  { title: "Classes 9–10", detail: "Board preparation", price: "₹1,200–₹1,500", unit: "per month", icon: "02" },
  { title: "Classes 11–12", detail: "Subject-focused classes", price: "₹1,500–₹1,800", unit: "per subject", icon: "03" },
  { title: "Competitive & CUET", detail: "Entrance preparation", price: "₹2,400+", unit: "combo estimate", icon: "04" }
];

const comparison = [
  { feature: "Guidance", self: "Plan lessons and pace yourself", other: "Depends on the centre", yuitor: "Expert-led, in-person classes" },
  { feature: "Practice", self: "Find and track practice on your own", other: "Practice format varies", yuitor: "AI-assisted practice and revision" },
  { feature: "Questions", self: "Revisit material or search for answers", other: "Ask during or after class", yuitor: "Ask your teacher directly" },
  { feature: "Learning place", self: "Study from home", other: "Centre-dependent", yuitor: "Yuitor learning centre in Muradnagar" }
];

const teachers = [
  { name: "Dr. Ramesh Sharma", role: "Physics & JEE Expert", experience: "12 years", portrait: "faculty-ramesh-illustrative.webp", initials: "RS" },
  { name: "Ms. Priya Agarwal", role: "Biology & NEET Expert", experience: "10 years", portrait: "faculty-priya-illustrative.webp", initials: "PA" },
  { name: "Mr. Vikas Gupta", role: "Mathematics & JEE", experience: "8 years", portrait: "faculty-vikas-illustrative.webp", initials: "VG" },
  { name: "Ms. Sunita Yadav", role: "Chemistry Specialist", experience: "9 years", portrait: "faculty-sunita-illustrative.webp", initials: "SY" }
];

const reasons = [
  { number: "01", title: "Teachers lead the learning", copy: "Clear explanations and direct support from subject teachers keep learning human and focused." },
  { number: "02", title: "Practice that adapts", copy: "AI-assisted practice helps students revisit topics and build a steadier revision routine." },
  { number: "03", title: "See ideas come together", copy: "Interactive lessons make it easier to explore concepts, work through examples and ask questions." },
  { number: "04", title: "A centre close to home", copy: "Learn in person at Yuitor Smart Classes in Muradnagar, with school and entrance pathways in one place." }
];

function Home() {
  const [activeFaq, setActiveFaq] = React.useState(-1);
  const faq = [
    { q: "Which classes and programmes can I join?", a: "Yuitor offers learning support for Classes 6–12, school boards, JEE, NEET and CUET. Contact the team to discuss your class, subjects and current batches." },
    { q: "How much do classes cost?", a: "The ranges on this page are estimates from the existing fee guide. Fees can depend on the class, subject and programme, so confirm the current amount with the Yuitor team." },
    { q: "What does AI-assisted learning mean?", a: "Teachers remain at the centre of learning. AI-assisted practice can help students work through revision and focus on topics that need more attention." },
    { q: "Can I visit before enrolling?", a: "Yes. Contact Yuitor to plan a visit to the Muradnagar learning centre or ask about arranging a free demo." },
    { q: "How can I ask a question or share feedback?", a: "Call or message the team. Students and parents are welcome to ask questions, share their experience and discuss what support would be useful." }
  ];

  return hs("div", {
    className: "yuitor-home yn-home",
    children: [
      hs("section", { className: "yn-hero", children: [
        h("div", { className: "yn-hero-glow", "aria-hidden": "true" }),
        hs("div", { className: "yn-wrap yn-hero-grid", children: [
          hs("div", { className: "yn-hero-copy", children: [
            h("div", { className: "yn-location-pill", children: [h(Mark, { children: "✳" }), " Muradnagar · Expert-led learning"] }),
            hs("h1", { children: ["Learn with ", h("em", { children: "confidence." }), h("br", {}), "Move forward with purpose."] }),
            h("p", { className: "yn-hero-lede", children: "School support, board preparation and entrance coaching—shaped around clear teaching, focused practice and a place to ask questions." }),
            hs("div", { className: "yn-hero-actions", children: [
              h(Link, { href: "/contact", className: "yn-button yn-button-primary", children: ["Book a free demo", h("span", { "aria-hidden": "true", children: "↗" })] }),
              h(Link, { href: "/fee-calculator", className: "yn-button yn-button-outline", children: "Explore fee estimates" })
            ] }),
            hs("div", { className: "yn-hero-note", children: [
              h("span", { className: "yn-note-dot", "aria-hidden": "true" }),
              h("span", { children: "For Classes 6–12 · JEE · NEET · CUET" })
            ] })
          ] }),
          hs("div", { className: "yn-hero-visual", children: [
            h("img", { src: image("teacher-small-group.webp"), alt: "A teacher guiding students during a small-group lesson", fetchPriority: "high" }),
            h("div", { className: "yn-photo-stamp", children: [h("span", { children: "LEARN" }), h("strong", { children: "together." })] }),
            hs("div", { className: "yn-hero-card", children: [
              h("span", { className: "yn-card-icon", children: "✦" }),
              hs("div", { children: [h("strong", { children: "Expert teachers" }), h("span", { children: "AI-assisted practice" })] })
            ] }),
            h("span", { className: "yn-image-caption", children: "A classroom built for questions, practice and progress." })
          ] })
        ] }),
        hs("div", { className: "yn-hero-bottom yn-wrap", children: [
          h("span", { children: "SCHOOL · BOARDS · ENTRANCE PREPARATION" }),
          h("a", { href: "#pricing", children: ["Find the right starting point ", h("span", { "aria-hidden": "true", children: "↓" })] })
        ] })
      ] }),

      hs("section", { className: "yn-section yn-pricing", id: "pricing", children: [
        hs("div", { className: "yn-wrap", children: [
          hs("div", { className: "yn-section-heading yn-heading-split", children: [
            hs("div", { children: [h(Eyebrow, { number: "01", children: "Clear, upfront estimates" }), hs("h2", { children: ["Know the range. ", h("em", { children: "Then choose." })] })] }),
            h("p", { children: "Start with an estimate, then talk with our team about the exact class, subject and programme fee." })
          ] }),
          h("div", { className: "yn-price-grid", children: prices.map((plan) =>
            hs("article", { className: "yn-price-card", key: plan.title, children: [
              hs("div", { className: "yn-price-top", children: [h("span", { className: "yn-price-number", children: plan.icon }), h("span", { className: "yn-price-arrow", "aria-hidden": "true", children: "↗" })] }),
              h("h3", { children: plan.title }),
              h("p", { className: "yn-price-detail", children: plan.detail }),
              h("div", { className: "yn-price-value", children: [h("strong", { children: plan.price }), h("span", { children: plan.unit })] }),
              h(Link, { href: "/fee-calculator", className: "yn-price-link", children: ["Check your course fees", h("span", { "aria-hidden": "true", children: "→" })] })
            ] })
          ) }),
          h("p", { className: "yn-disclaimer", children: "These are estimates from the existing fee guide, not a final quote. Confirm current fees and course details with Yuitor before enrolling." })
        ] })
      ] }),

      hs("section", { className: "yn-section yn-comparison", id: "comparison", children: [
        hs("div", { className: "yn-wrap", children: [
          hs("div", { className: "yn-section-heading", children: [
            h(Eyebrow, { number: "02", children: "Choose what fits" }),
            hs("h2", { children: ["A closer look at ", h("em", { children: "how you learn." })] }),
            h("p", { children: "Different approaches work for different students. Here’s what learning with Yuitor includes." })
          ] }),
          h("div", { className: "yn-table-wrap", children:
            hs("table", { className: "yn-compare-table", children: [
              hs("thead", { children: h("tr", { children: [
                h("th", { children: "What matters" }),
                h("th", { children: "Self-study" }),
                h("th", { children: "Many tuition setups" }),
                h("th", { className: "yn-table-highlight", children: "At Yuitor" })
              ] }) }),
              h("tbody", { children: comparison.map((row) =>
                hs("tr", { key: row.feature, children: [
                  h("th", { scope: "row", children: row.feature }),
                  h("td", { children: row.self }),
                  h("td", { children: row.other }),
                  h("td", { className: "yn-table-highlight", children: [h("span", { className: "yn-check", "aria-hidden": "true", children: "✓" }), row.yuitor] })
                ] })
              ) })
            ] })
          }),
          h("p", { className: "yn-compare-note", children: "Other tuition experiences vary by provider. Ask us about the teaching format and support available for your course." })
        ] })
      ] }),

      hs("section", { className: "yn-section yn-reviews", id: "student-reviews", children: [
        hs("div", { className: "yn-wrap yn-review-layout", children: [
          hs("div", { className: "yn-review-main", children: [
            h(Eyebrow, { number: "03", children: "Student reviews" }),
            hs("h2", { children: ["Real learning. ", h("em", { children: "Real voices." })] }),
            h("p", { children: "We want students and families to speak for themselves. If you’ve learned with Yuitor, tell us what helped—and what we can do better." }),
            h("a", { className: "yn-button yn-button-light", href: "https://wa.me/917827289292?text=Hello%2C%20I%27d%20like%20to%20share%20feedback%20about%20Yuitor", target: "_blank", rel: "noopener noreferrer", children: ["Share your experience", h("span", { "aria-hidden": "true", children: "↗" })] })
          ] }),
          hs("aside", { className: "yn-review-note", children: [
            h("span", { className: "yn-quote-mark", "aria-hidden": "true", children: "“" }),
            h("strong", { children: "Honest feedback belongs to the people who experienced it." }),
            h("p", { children: "We don’t publish made-up testimonials. Ask our team to speak with current families, or share your own review with permission." }),
            h("span", { className: "yn-review-signoff", children: "YUITOR · MURADNAGAR" })
          ] })
        ] })
      ] }),

      hs("section", { className: "yn-section yn-teachers", id: "teachers", children: [
        hs("div", { className: "yn-wrap", children: [
          hs("div", { className: "yn-section-heading yn-heading-split", children: [
            hs("div", { children: [h(Eyebrow, { number: "04", children: "Meet the teaching team" }), hs("h2", { children: ["Expert teachers. ", h("em", { children: "Personal support." })] })] }),
            h("p", { children: "Subject expertise and experience to help students work through concepts, questions and next steps." })
          ] }),
          h("div", { className: "yn-teacher-grid", children: teachers.map((teacher) =>
            hs("article", { className: "yn-teacher-card", key: teacher.name, children: [
              hs("div", { className: "yn-teacher-photo", children: [
                h("img", { src: image(teacher.portrait), alt: `${teacher.name}, illustrative portrait`, loading: "lazy" })
              ] }),
              h("div", { className: "yn-teacher-info", children: [
                h("h3", { children: teacher.name }),
                h("p", { className: "yn-teacher-role", children: teacher.role }),
                h("span", { className: "yn-experience", children: [h("span", { "aria-hidden": "true", children: "✦" }), `${teacher.experience} teaching experience`] })
              ] })
            ] })
          ) }),
          h("p", { className: "yn-teacher-disclaimer", children: "Meet the teachers guiding students through school subjects and entrance preparation." })
        ] })
      ] }),

      hs("section", { className: "yn-section yn-why", id: "why-yuitor", children: [
        hs("div", { className: "yn-wrap yn-why-layout", children: [
          hs("div", { className: "yn-why-intro", children: [
            h(Eyebrow, { number: "05", children: "Why join Yuitor" }),
            hs("h2", { children: ["A learning plan that ", h("em", { children: "starts with people." })] }),
            h("p", { children: "Good learning needs more than a lesson. It needs a teacher who can explain, practice that makes sense and room to ask again." }),
            h(Link, { href: "/about", className: "yn-text-link", children: ["Explore our approach", h("span", { "aria-hidden": "true", children: "↗" })] })
          ] }),
          h("div", { className: "yn-reason-grid", children: reasons.map((reason) =>
            hs("article", { className: "yn-reason-card", key: reason.number, children: [
              h("span", { className: "yn-reason-number", children: reason.number }),
              h("h3", { children: reason.title }),
              h("p", { children: reason.copy })
            ] })
          ) })
        ] })
      ] }),

      hs("section", { className: "yn-section yn-faq", id: "questions", children: [
        hs("div", { className: "yn-wrap yn-faq-layout", children: [
          hs("div", { className: "yn-faq-intro", children: [
            h(Eyebrow, { number: "06", children: "Good to know" }),
            hs("h2", { children: ["Questions, ", h("em", { children: "answered." })] }),
            h("p", { children: "Still deciding? Start with the basics, then talk with our team about your student’s needs." }),
            h(Link, { href: "/contact", className: "yn-text-link", children: ["Ask a question", h("span", { "aria-hidden": "true", children: "↗" })] })
          ] }),
          h("div", { className: "yn-faq-list", children: faq.map((item, index) =>
            hs("article", { className: `yn-faq-item${activeFaq === index ? " is-open" : ""}`, key: item.q, children: [
              h("button", { type: "button", "aria-expanded": activeFaq === index, "aria-controls": `yn-answer-${index}`, onClick: () => setActiveFaq(activeFaq === index ? -1 : index), children: [
                h("span", { className: "yn-faq-index", children: `0${index + 1}` }),
                h("strong", { children: item.q }),
                h("span", { className: "yn-faq-toggle", "aria-hidden": "true", children: activeFaq === index ? "−" : "+" })
              ] }),
              h("div", { className: "yn-faq-answer", id: `yn-answer-${index}`, hidden: activeFaq !== index, children: h("p", { children: item.a }) })
            ] })
          ) })
        ] })
      ] }),

      hs("section", { className: "yn-cta", id: "start", children: [
        h("div", { className: "yn-cta-pattern", "aria-hidden": "true" }),
        hs("div", { className: "yn-wrap yn-cta-layout", children: [
          hs("div", { className: "yn-cta-copy", children: [
            h(Eyebrow, { number: "07", children: "Your next step starts here" }),
            hs("h2", { children: ["A good place to learn. ", h("em", { children: "A confident next step." })] }),
            h("p", { children: "Visit the Muradnagar centre, meet the team and find out which class or programme fits your goals." }),
            hs("div", { className: "yn-hero-actions", children: [
              h(Link, { href: "/contact", className: "yn-button yn-button-accent", children: ["Plan a visit", h("span", { "aria-hidden": "true", children: "↗" })] }),
              h("a", { href: "tel:+917827289292", className: "yn-cta-phone", children: "+91 78-2728-9292" })
            ] })
          ] }),
          hs("div", { className: "yn-cta-side", children: [
            h("span", { className: "yn-cta-side-label", children: "YUITOR SMART CLASSES" }),
            h("strong", { children: "Learn here. Grow from here." }),
            h("span", { children: "Trimurti Vihar, near Venus Academy" }),
            h("span", { children: "Muradnagar · Uttar Pradesh" }),
            h(Link, { href: "/contact", className: "yn-cta-map", children: ["Contact the centre", h("span", { "aria-hidden": "true", children: "↗" })] })
          ] })
        ] })
      ] })
    ]
  });
}

export default Home;
