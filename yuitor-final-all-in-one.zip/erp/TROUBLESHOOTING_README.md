# Yuitor Smart Classes ERP - cPanel Deployment & Troubleshooting Guide

## Quick cPanel Installation Steps
1. Upload `yuitor-erp-cpanel.zip` inside `public_html/` (so extracting creates `public_html/erp/`).
2. Extract the zip file via cPanel File Manager.
3. In cPanel -> **MySQL Databases**:
   - Create a database (e.g. `yuitor_erp`).
   - Create a database user with a strong password.
   - Assign **ALL PRIVILEGES** to that user on the database.
4. Visit `https://yuitor.com/erp/install/install.php` in your browser.
5. Complete the 6-step setup wizard:
   - Step 1: Server & PHP extension checks
   - Step 2: Folder permissions check (`config/`, `uploads/`, `backups/`, `logs/`)
   - Step 3: MySQL database credentials
   - Step 4: Admin account (`admission@yuitor.com` supported) + Institute defaults
   - Step 5: Auto-create tables + seed branch `YS01` & session `2026-27`
   - Step 6: Lock installer (`install/install.lock` created automatically)
6. **Delete or restrict** `/erp/install/` after setup if desired (`install.lock` already blocks re-runs).

## Recommended cPanel Cron Jobs
- Every 5 minutes (Message Queue):
  `*/5 * * * * /usr/local/bin/php -q /home/YOUR_USER/public_html/erp/cron/send_queue.php >/dev/null 2>&1`
- Daily 8:00 AM (Overdue Fee Reminders):
  `0 8 * * * /usr/local/bin/php -q /home/YOUR_USER/public_html/erp/cron/overdue_check.php >/dev/null 2>&1`
- Daily 2:00 AM (SQL Auto-Backup):
  `0 2 * * * /usr/local/bin/php -q /home/YOUR_USER/public_html/erp/cron/db_backup.php >/dev/null 2>&1`

## Common Errors & Fixes
- **500 Internal Server Error**: Check `erp/logs/install_error.log` or `erp/logs/app_error.log`. Ensure PHP version in cPanel MultiPHP Manager is `7.4` to `8.3` with `pdo_mysql`, `openssl`, `mbstring`, `fileinfo` enabled.
- **Database Access Denied**: Verify DB prefix (`cpaneluser_dbname`) and `ALL PRIVILEGES`.
- **OTP / Emails Going to Spam**: Configure authenticated SMTP settings inside **Admin -> Settings -> Email & SMTP** using `No-reply@yuitor.com`.
- **Installer Locked**: Remove `erp/install/install.lock` only if intentionally re-installing on a clean DB.
