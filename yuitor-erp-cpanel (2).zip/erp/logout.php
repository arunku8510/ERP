<?php
require_once __DIR__ . '/includes/auth.php';
start_secure_session();
if (!empty($_SESSION['user_id'])) {
    audit_log('logout', 'users', (int)$_SESSION['user_id'], 'Signed out');
}
$_SESSION = [];
if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
}
session_destroy();
header('Location: /erp/index.php');
exit;
