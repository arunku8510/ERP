<?php
declare(strict_types=1);
require_once dirname(__DIR__) . '/erp/config/security.php';
send_security_headers();
start_secure_session();
header('Content-Type: application/json; charset=UTF-8');
echo json_encode([
    'csrf_token' => csrf_token(),
    'demo_phone' => YU_DEMO_PHONE,
    'demo_email' => YU_DEMO_EMAIL,
    'demo_address' => YU_DEMO_ADDRESS,
]);
