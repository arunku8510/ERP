<?php
require_once __DIR__ . '/../includes/auth.php';
send_security_headers();
$user = require_role('admin');
$pdo = db();

$allowed = ['New', 'Shortlisted', 'Interviewed', 'Hired', 'Rejected'];

if (isset($_GET['download_resume'])) {
    $appId = (int) $_GET['download_resume'];
    $st = $pdo->prepare("SELECT resume_path FROM teacher_applications WHERE id = ? LIMIT 1");
    $st->execute([$appId]);
    $rel = (string) $st->fetchColumn();
    $file = basename($rel);
    $full = __DIR__ . '/../uploads/resumes/' . $file;
    if ($file === '' || !is_file($full)) {
        http_response_code(404);
        die('Resume not found.');
    }
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="Teacher_Resume_' . $appId . '.pdf"');
    header('X-Content-Type-Options: nosniff');
    readfile($full);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $appId = (int) ($_POST['app_id'] ?? 0);
    $status = trim((string) ($_POST['status'] ?? ''));
    if ($appId > 0 && in_array($status, $allowed, true)) {
        $pdo->prepare("UPDATE teacher_applications SET status = ? WHERE id = ?")->execute([$status, $appId]);
        flash_set('success', 'Teacher application status updated.');
    }
    redirect_to('admin/teacher_applications.php');
}

$rows = $pdo->query("SELECT * FROM teacher_applications ORDER BY id DESC LIMIT 100")->fetchAll();
$pageTitle = 'Teacher Applications';
$showPanelSidebar = true;
$pageNoIndex = true;
$portalMode = 'admin';
include __DIR__ . '/../includes/site_header.php';
include __DIR__ . '/../includes/panel_nav.php';
?>
<div class="yu-page-head"><div><h1>Teacher Applications</h1><p>Website se aane wale faculty applications.</p></div></div>
<div class="yu-card">
  <div class="yu-table-wrap"><table class="yu-table">
    <tr><th>Applicant</th><th>Subject &amp; Exp</th><th>Qualification</th><th>Contact</th><th>Resume</th><th>Status</th></tr>
    <?php foreach ($rows as $r): ?>
      <tr>
        <td><strong><?php echo e($r['full_name']); ?></strong></td>
        <td><?php echo e($r['subject_specialty']); ?> (<?php echo (int) $r['experience_years']; ?> yrs)</td>
        <td><?php echo e($r['qualification']); ?></td>
        <td><?php echo e($r['phone']); ?><br><span style="font-size:12px;color:#64748b;"><?php echo e($r['email']); ?></span></td>
        <td><?php echo !empty($r['resume_path']) ? '<a class="yu-btn yu-btn-outline yu-btn-sm" href="?download_resume=' . (int) $r['id'] . '">Download PDF</a>' : '-'; ?></td>
        <td>
          <form method="post" style="display:flex;gap:6px;">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="app_id" value="<?php echo (int) $r['id']; ?>">
            <select name="status" style="padding:6px;border:1px solid #cbd9e6;border-radius:8px;">
              <?php foreach ($allowed as $st): ?>
                <option value="<?php echo e($st); ?>" <?php echo $r['status'] === $st ? 'selected' : ''; ?>><?php echo e($st); ?></option>
              <?php endforeach; ?>
            </select>
            <button type="submit" class="yu-btn yu-btn-primary yu-btn-sm">Save</button>
          </form>
        </td>
      </tr>
    <?php endforeach; ?>
    <?php if (empty($rows)): ?>
      <tr><td colspan="6" style="text-align:center;color:#64748b;padding:24px;">No teacher applications yet.</td></tr>
    <?php endif; ?>
  </table></div>
</div>
<?php include __DIR__ . '/../includes/site_footer.php'; ?>
