<?php
// Yuitor Smart Classes - Shared Website Header (Merged from https://yuitor.com) + Scoped ERP Shell CSS
require_once __DIR__ . '/icons.php';
if (!isset($pageTitle)) $pageTitle = 'Yuitor Smart Classes';
$instName = function_exists('get_setting') ? get_setting('institute_name', 'Yuitor Smart Classes') : 'Yuitor Smart Classes';
$instLogo = function_exists('get_setting') ? get_setting('institute_logo', '/erp/assets/images/yuitor-smart-classes-logo.png') : '/erp/assets/images/yuitor-smart-classes-logo.png';
$currentUser = function_exists('current_user') ? current_user() : null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo e($pageTitle); ?> | <?php echo e($instName); ?></title>
  <meta name="description" content="<?php echo e($instName); ?> — Coaching Management System for Branches, Attendance, Fees, Online Tests &amp; Parent Portals.">
  <meta property="og:title" content="<?php echo e($pageTitle); ?> | <?php echo e($instName); ?>">
  <meta property="og:image" content="/erp/assets/images/opengraph-yuitor.jpg">
  <link rel="icon" type="image/png" sizes="192x192" href="/erp/assets/images/yuitor-icon-192.png">
  <link rel="icon" type="image/svg+xml" href="/erp/assets/images/favicon.svg">
  <link rel="shortcut icon" href="/erp/assets/images/favicon.ico">
  <link rel="apple-touch-icon" href="/erp/assets/images/yuitor-icon-192.png">
  <link rel="manifest" href="/erp/manifest.json">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,400..700;1,9..40,400..700&family=Manrope:wght@600;700;800&display=swap" rel="stylesheet">
  <style>
    :root {
      --brand-blue: #2563eb;
      --brand-blue-deep: #1d4ed8;
      --brand-teal: #12a1a1;
      --brand-deep-teal: #0b7b82;
      --brand-navy: #0f172a;
      --brand-paper: #f5f9fc;
      --brand-white: #ffffff;
      --brand-copy: #344b5e;
      --brand-muted: #657b8e;
      --brand-line: #dbe6ef;
    }
    *, *::before, *::after { box-sizing: border-box; }
    html { scroll-behavior: smooth; }
    body {
      margin: 0;
      font-family: "DM Sans", "Manrope", Arial, sans-serif;
      background: var(--brand-paper);
      color: var(--brand-navy);
      font-size: 15px;
      line-height: 1.6;
      -webkit-font-smoothing: antialiased;
    }
    a { color: inherit; }
    img { max-width: 100%; }

    /* ===== Shared Header (Exact yuitor.com visual design) ===== */
    .yu-shared-header {
      position: sticky;
      top: 0;
      left: 0;
      right: 0;
      z-index: 50;
      font-family: "DM Sans", "Manrope", Arial, sans-serif;
    }
    .yu-topbar {
      display: none;
      background: linear-gradient(100deg, var(--brand-navy), #123c52 55%, var(--brand-deep-teal));
      border-bottom: 1px solid rgba(255,255,255,0.14);
    }
    .yu-container {
      width: 100%;
      max-width: 1320px;
      margin: 0 auto;
      padding: 0 16px;
    }
    @media (min-width: 1024px) {
      .yu-container { padding: 0 24px; }
      .yu-topbar { display: block; }
    }
    .yu-topbar-inner {
      height: 40px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      font-size: 12.5px;
      color: #f4f9fc;
    }
    .yu-topbar-group {
      display: flex;
      align-items: center;
      gap: 20px;
    }
    .yu-topbar-group a, .yu-topbar-group span {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      color: #f4f9fc;
      text-decoration: none;
      white-space: nowrap;
      transition: color .18s ease;
    }
    .yu-topbar-group a:hover { color: #8fe0df; }
    .yu-topbar-group svg { width: 13px; height: 13px; color: #69c9cc; flex-shrink: 0; }
    .yu-topbar-highlight { color: #78d3d3 !important; font-weight: 600; }

    .yu-navbar-wrap {
      background: rgba(255, 255, 255, 0.98);
      backdrop-filter: blur(14px);
      -webkit-backdrop-filter: blur(14px);
      border-bottom: 1px solid var(--brand-line);
      box-shadow: 0 9px 28px rgba(15, 23, 42, 0.08);
    }
    .yu-navbar-inner {
      height: 68px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
    }
    .yu-brand-link {
      display: flex;
      align-items: center;
      gap: 12px;
      text-decoration: none;
      flex-shrink: 0;
    }
    .yu-brand-logo-box {
      width: 46px;
      height: 46px;
      border-radius: 50%;
      background: #eef6fa;
      border: 1.5px solid #bfe3eb;
      padding: 3px;
      box-shadow: 0 3px 10px rgba(11,123,130,0.14);
      display: flex;
      align-items: center;
      justify-content: center;
      overflow: hidden;
    }
    .yu-brand-logo-box img { width: 100%; height: 100%; object-fit: contain; display: block; border-radius: 50%; }
    .yu-brand-text { display: flex; flex-direction: column; line-height: 1.05; }
    .yu-brand-name {
      font-family: "Manrope", "DM Sans", sans-serif;
      font-size: clamp(17px, 1.7vw, 22px);
      font-weight: 800;
      letter-spacing: -0.025em;
      color: var(--brand-navy);
      white-space: nowrap;
    }
    .yu-brand-sub {
      font-size: 9px;
      font-weight: 700;
      letter-spacing: 0.13em;
      text-transform: uppercase;
      color: #557184;
      margin-top: 2px;
      white-space: nowrap;
    }

    .yu-nav-links {
      display: none;
      align-items: center;
      gap: 2px;
      font-size: 14px;
      font-weight: 600;
    }
    .yu-nav-links > a, .yu-nav-dropdown-btn {
      padding: 8px 12px;
      border-radius: 8px;
      text-decoration: none;
      color: var(--brand-navy);
      background: transparent;
      border: 0;
      font: inherit;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 5px;
      white-space: nowrap;
      transition: color .18s ease, background-color .18s ease;
    }
    .yu-nav-links > a:hover, .yu-nav-dropdown-btn:hover {
      color: var(--brand-blue);
      background: rgba(37, 99, 235, 0.06);
    }
    .yu-nav-links > a.yu-nav-active {
      color: var(--brand-blue-deep);
      background: #eaf3fb;
      border: 1px solid #c5d9ec;
    }
    .yu-injected-fee-link {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-height: 38px;
      padding: 8px 13px;
      border: 1px solid #d7e3ef;
      border-radius: 10px;
      background: #eef4fb;
      color: #173f70 !important;
      font-size: 13.5px;
      font-weight: 700;
      text-decoration: none;
      white-space: nowrap;
      transition: all .18s ease;
    }
    .yu-injected-fee-link:hover {
      background: var(--brand-blue);
      border-color: var(--brand-blue);
      color: #ffffff !important;
    }
    .yu-nav-dropdown-wrap { position: relative; }
    .yu-courses-mega {
      display: none;
      position: absolute;
      top: calc(100% + 8px);
      left: 50%;
      transform: translateX(-50%);
      width: 680px;
      background: #ffffff;
      border: 1px solid var(--brand-line);
      border-radius: 16px;
      box-shadow: 0 22px 48px rgba(15, 23, 42, 0.16);
      padding: 24px;
      z-index: 60;
    }
    .yu-nav-dropdown-wrap.is-open .yu-courses-mega { display: block; }
    .yu-courses-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 22px; }
    .yu-mega-title {
      font-size: 10.5px;
      font-weight: 800;
      text-transform: uppercase;
      letter-spacing: 0.12em;
      color: var(--brand-blue-deep);
      margin: 0 0 10px;
    }
    .yu-mega-classes { display: grid; grid-template-columns: 1fr 1fr; gap: 4px; }
    .yu-mega-link {
      display: block;
      padding: 6px 10px;
      font-size: 13.5px;
      color: var(--brand-copy);
      text-decoration: none;
      border-radius: 8px;
    }
    .yu-mega-link:hover { background: #eef6fa; color: var(--brand-blue); }

    .yu-header-actions {
      display: none;
      align-items: center;
      gap: 8px;
      flex-shrink: 0;
    }
    .yu-btn-ghost {
      font-size: 13.5px;
      font-weight: 600;
      color: var(--brand-navy);
      padding: 8px 11px;
      border-radius: 8px;
      text-decoration: none;
      white-space: nowrap;
    }
    .yu-btn-ghost:hover { color: var(--brand-blue); background: rgba(37,99,235,0.06); }
    .yu-btn-enquire {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      background: linear-gradient(135deg, var(--brand-blue), var(--brand-blue-deep));
      color: #ffffff;
      padding: 9px 16px;
      border-radius: 11px;
      font-size: 13.5px;
      font-weight: 700;
      text-decoration: none;
      white-space: nowrap;
      box-shadow: 0 7px 18px rgba(37, 99, 235, 0.22);
    }
    .yu-btn-enquire:hover { opacity: 0.94; }
    .yu-btn-call {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      border: 1.5px solid #b9d9e5;
      background: #ffffff;
      color: var(--brand-deep-teal);
      padding: 8px 14px;
      border-radius: 11px;
      font-size: 13.5px;
      font-weight: 700;
      text-decoration: none;
      white-space: nowrap;
    }
    .yu-btn-call:hover { background: var(--brand-deep-teal); color: #ffffff; border-color: var(--brand-deep-teal); }

    .yu-mobile-actions { display: flex; align-items: center; gap: 8px; margin-left: auto; }
    .yu-hamburger {
      padding: 8px;
      border-radius: 9px;
      border: 1px solid #c9dce8;
      background: #ffffff;
      color: var(--brand-blue-deep);
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      justify-content: center;
    }
    @media (min-width: 1120px) {
      .yu-nav-links { display: flex; }
      .yu-header-actions { display: flex; }
      .yu-mobile-actions { display: none; }
    }

    /* Mobile Drawer */
    .yu-mobile-menu {
      display: none;
      position: fixed;
      inset: 0;
      z-index: 90;
      background: #ffffff;
      overflow-y: auto;
    }
    .yu-mobile-menu.is-open { display: block; }
    .yu-mobile-hero {
      background: linear-gradient(135deg, var(--brand-navy), var(--brand-deep-teal));
      color: #ffffff;
      padding: 18px 20px;
    }

    /* ===== Shared Footer (Exact yuitor.com navy + teal anchor) ===== */
    footer.yu-shared-footer {
      margin-top: 36px;
      border-top: 1px solid #124c5b;
      background: linear-gradient(145deg, var(--brand-navy), #102b3d 62%, #0c454b);
      color: #edf6fa;
      font-family: "DM Sans", "Manrope", Arial, sans-serif;
      font-size: 14px;
      line-height: 1.65;
    }
    .yu-footer-strip {
      border-bottom: 1px solid rgba(255,255,255,0.14);
      background: linear-gradient(95deg, #104e5d, #123c52 56%, var(--brand-navy));
      padding: 18px 0;
    }
    .yu-strip-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 16px;
    }
    @media (min-width: 768px) {
      .yu-strip-grid { grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 24px; }
    }
    .yu-strip-item {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 4px 8px;
    }
    .yu-strip-icon {
      width: 40px;
      height: 40px;
      border-radius: 12px;
      background: rgba(255,255,255,0.1);
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
      color: #78d3d3;
    }
    .yu-footer-main { padding: 44px 0 28px; }
    .yu-footer-cols {
      display: grid;
      grid-template-columns: 1fr;
      gap: 32px;
      margin-bottom: 32px;
    }
    @media (min-width: 768px) {
      .yu-footer-cols { grid-template-columns: repeat(2, 1fr); }
    }
    @media (min-width: 1024px) {
      .yu-footer-cols { grid-template-columns: 4fr 2fr 3fr 3fr; gap: 36px; }
    }
    .yu-footer-heading {
      display: flex;
      align-items: center;
      gap: 8px;
      margin: 0 0 16px;
      font-family: "Manrope", sans-serif;
      font-size: 15px;
      font-weight: 700;
      color: #ffffff;
    }
    .yu-footer-heading span.bar {
      width: 4px;
      height: 16px;
      border-radius: 99px;
      background: #78d3d3;
      display: inline-block;
    }
    .yu-footer-list { list-style: none; padding: 0; margin: 0; }
    .yu-footer-list li { margin-bottom: 9px; }
    .yu-footer-list a {
      color: #d4e2e9;
      text-decoration: none;
      font-size: 14px;
      transition: color .15s ease;
    }
    .yu-footer-list a:hover { color: #8fe0df; }
    .yu-footer-bottom {
      border-top: 1px solid rgba(255,255,255,0.16);
      padding-top: 18px;
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      font-size: 13px;
      color: #b8cdd8;
    }

    /* ===== Scoped ERP Panel Styles (.yuitor-erp-shell) ===== */
    .yuitor-erp-shell {
      min-height: calc(100vh - 280px);
      padding: 24px 16px 36px;
    }
    .yuitor-erp-layout {
      max-width: 1320px;
      margin: 0 auto;
      display: grid;
      grid-template-columns: 1fr;
      gap: 22px;
      align-items: start;
    }
    @media (min-width: 1024px) {
      .yuitor-erp-shell { padding: 26px 24px 44px; }
      .yuitor-erp-layout.has-sidebar { grid-template-columns: 260px minmax(0, 1fr); }
    }
    .yu-sidebar {
      background: #ffffff;
      border: 1px solid var(--brand-line);
      border-radius: 16px;
      padding: 16px;
      box-shadow: 0 8px 24px rgba(15, 23, 42, 0.05);
    }
    .yu-sidebar-user {
      padding: 12px 14px;
      border-radius: 12px;
      background: #edf5fa;
      border: 1px solid #d4e3ee;
      margin-bottom: 14px;
    }
    .yu-sidebar-role {
      font-size: 11px;
      font-weight: 800;
      text-transform: uppercase;
      letter-spacing: 0.08em;
      color: var(--brand-deep-teal);
    }
    .yu-sidebar-name {
      font-family: "Manrope", sans-serif;
      font-size: 15px;
      font-weight: 700;
      color: var(--brand-navy);
      margin: 2px 0;
    }
    .yu-side-nav { display: flex; flex-direction: column; gap: 4px; }
    .yu-side-link {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 10px;
      padding: 9px 12px;
      border-radius: 10px;
      text-decoration: none;
      font-size: 13.5px;
      font-weight: 600;
      color: var(--brand-copy);
      transition: all .15s ease;
    }
    .yu-side-link-main {
      display: inline-flex;
      align-items: center;
      gap: 10px;
      min-width: 0;
    }
    .yu-side-link-ico {
      width: 28px;
      height: 28px;
      border-radius: 8px;
      background: #f1f6fa;
      color: var(--brand-deep-teal);
      display: inline-flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
    }
    .yu-side-link:hover { background: #eef6fa; color: var(--brand-blue-deep); }
    .yu-side-link:hover .yu-side-link-ico { background: #dcebfa; color: var(--brand-blue-deep); }
    .yu-side-link.active {
      background: linear-gradient(135deg, var(--brand-blue), var(--brand-blue-deep));
      color: #ffffff;
    }
    .yu-side-link.active .yu-side-link-ico {
      background: rgba(255,255,255,0.18);
      color: #ffffff;
    }
    .yu-main-content { min-width: 0; }
    .yu-page-head {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      margin-bottom: 18px;
    }
    .yu-page-head h1 {
      margin: 0;
      font-family: "Manrope", sans-serif;
      font-size: clamp(22px, 2.2vw, 28px);
      font-weight: 800;
      color: var(--brand-navy);
      letter-spacing: -0.02em;
    }
    .yu-page-head p { margin: 2px 0 0; font-size: 13.5px; color: var(--brand-muted); }

    .yu-card {
      background: #ffffff;
      border: 1px solid var(--brand-line);
      border-radius: 16px;
      padding: 20px;
      box-shadow: 0 6px 20px rgba(15, 23, 42, 0.04);
      margin-bottom: 20px;
    }
    .yu-card-title {
      margin: 0 0 14px;
      font-family: "Manrope", sans-serif;
      font-size: 16.5px;
      font-weight: 700;
      color: var(--brand-navy);
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 10px;
    }
    .yu-kpi-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(195px, 1fr));
      gap: 14px;
      margin-bottom: 20px;
    }
    .yu-kpi {
      background: linear-gradient(145deg, #ffffff, #f5f9fc);
      border: 1px solid var(--brand-line);
      border-radius: 14px;
      padding: 16px 18px;
    }
    .yu-kpi-head {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
    }
    .yu-kpi-ico {
      width: 34px;
      height: 34px;
      border-radius: 10px;
      background: #eaf3fb;
      color: var(--brand-blue-deep);
      display: inline-flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
    }
    .yu-kpi-ico.teal {
      background: #e6f6f6;
      color: var(--brand-deep-teal);
    }
    .yu-kpi-label { font-size: 12.5px; font-weight: 600; color: var(--brand-muted); }
    .yu-kpi-val {
      font-family: "Manrope", sans-serif;
      font-size: 24px;
      font-weight: 800;
      color: var(--brand-navy);
      margin-top: 4px;
      font-variant-numeric: tabular-nums;
    }
    .yu-kpi-sub { font-size: 12px; color: var(--brand-deep-teal); margin-top: 2px; }

    .yu-grid-2 { display: grid; grid-template-columns: 1fr; gap: 18px; }
    .yu-grid-3 { display: grid; grid-template-columns: 1fr; gap: 14px; }
    @media (min-width: 768px) {
      .yu-grid-2 { grid-template-columns: repeat(2, minmax(0, 1fr)); }
      .yu-grid-3 { grid-template-columns: repeat(3, minmax(0, 1fr)); }
    }

    .yu-form-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(210px, 1fr)); gap: 14px; margin-bottom: 14px; }
    .yu-field label {
      display: block;
      font-size: 12.5px;
      font-weight: 700;
      color: var(--brand-copy);
      margin-bottom: 5px;
    }
    .yu-field input, .yu-field select, .yu-field textarea {
      width: 100%;
      padding: 9px 12px;
      border: 1px solid #cbd9e6;
      border-radius: 10px;
      background: #ffffff;
      color: var(--brand-navy);
      font: inherit;
      font-size: 14px;
    }
    .yu-field input:focus, .yu-field select:focus, .yu-field textarea:focus {
      outline: 2px solid rgba(37, 99, 235, 0.25);
      border-color: var(--brand-blue);
    }

    .yu-btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      padding: 9px 16px;
      border-radius: 10px;
      border: 1px solid transparent;
      font: inherit;
      font-size: 13.5px;
      font-weight: 700;
      cursor: pointer;
      text-decoration: none;
      white-space: nowrap;
      transition: all .16s ease;
    }
    .yu-btn-primary {
      background: linear-gradient(135deg, var(--brand-blue), var(--brand-blue-deep));
      color: #ffffff;
    }
    .yu-btn-primary:hover { opacity: 0.94; }
    .yu-btn-teal { background: var(--brand-deep-teal); color: #ffffff; }
    .yu-btn-outline { background: #ffffff; border-color: #cbd9e6; color: var(--brand-navy); }
    .yu-btn-outline:hover { background: #eef6fa; border-color: var(--brand-blue); color: var(--brand-blue-deep); }
    .yu-btn-danger { background: #dc2626; color: #ffffff; }
    .yu-btn-sm { padding: 6px 11px; font-size: 12.5px; border-radius: 8px; }

    .yu-table-wrap { width: 100%; overflow-x: auto; border: 1px solid var(--brand-line); border-radius: 12px; }
    table.yu-table { width: 100%; border-collapse: collapse; font-size: 13.5px; background: #ffffff; }
    table.yu-table th {
      background: #e8f1f8;
      color: var(--brand-navy);
      text-align: left;
      padding: 10px 12px;
      font-weight: 700;
      border-bottom: 1px solid var(--brand-line);
      white-space: nowrap;
    }
    table.yu-table td {
      padding: 10px 12px;
      border-bottom: 1px solid #ebf1f6;
      color: var(--brand-copy);
      vertical-align: middle;
    }
    table.yu-table tbody tr:hover { background: #f5f9fc; }
    .num { text-align: right; font-variant-numeric: tabular-nums; }

    .yu-alert {
      padding: 12px 16px;
      border-radius: 12px;
      margin-bottom: 16px;
      font-size: 13.5px;
      font-weight: 600;
      border: 1px solid;
    }
    .yu-alert-success { background: #ecfdf5; border-color: #a7f3d0; color: #065f46; }
    .yu-alert-danger { background: #fef2f2; border-color: #fecaca; color: #991b1b; }
    .yu-alert-warning { background: #fffbeb; border-color: #fde68a; color: #92400e; }
    .yu-alert-info { background: #eff6ff; border-color: #bfdbfe; color: #1e40af; }

    .yu-status-text { font-weight: 700; font-size: 12.5px; }
    .st-ok { color: #15803d; }
    .st-warn { color: #b45309; }
    .st-bad { color: #b91c1c; }
    .st-muted { color: #64748b; }
  </style>
</head>
<body>
<header class="yu-shared-header">
  <div class="yu-topbar">
    <div class="yu-container yu-topbar-inner">
      <div class="yu-topbar-group">
        <a href="tel:+917827289292">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
          +91 78-2728-9292
        </a>
        <a href="mailto:admission@yuitor.com">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7"/><rect x="2" y="4" width="20" height="16" rx="2"/></svg>
          admission@yuitor.com
        </a>
        <span style="opacity:.82">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>
          Mon–Sat: 8 AM – 8 PM
        </span>
      </div>
      <div class="yu-topbar-group">
        <span class="yu-topbar-highlight"><?php echo yu_icon('sparkles', 13); ?> Expert-Led · AI-Assisted Learning</span>
        <a href="https://wa.me/917827289292" target="_blank" rel="noopener noreferrer"><?php echo yu_icon('messaging', 13); ?> WhatsApp Us</a>
        <a href="https://yuitor.com/fee-calculator"><?php echo yu_icon('calculator', 13); ?> Fee Calculator</a>
        <a href="https://yuitor.com/scholarship"><?php echo yu_icon('award', 13); ?> Scholarship</a>
      </div>
    </div>
  </div>

  <div class="yu-navbar-wrap">
    <div class="yu-container yu-navbar-inner">
      <a href="https://yuitor.com/" class="yu-brand-link" aria-label="Yuitor Smart Classes home" data-testid="link-logo">
        <div class="yu-brand-logo-box">
          <img src="<?php echo e($instLogo); ?>" alt="<?php echo e($instName); ?>">
        </div>
        <div class="yu-brand-text">
          <span class="yu-brand-name"><?php echo e($instName); ?></span>
          <span class="yu-brand-sub">AI-ASSISTED · EXPERT-LED</span>
        </div>
      </a>

      <nav class="yu-nav-links" aria-label="Primary site navigation">
        <a href="https://yuitor.com/">Home</a>
        <a href="https://yuitor.com/about">About</a>
        <div class="yu-nav-dropdown-wrap" id="yuCoursesMenu">
          <button type="button" class="yu-nav-dropdown-btn" id="yuCoursesBtn" aria-expanded="false">
            Courses
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m6 9 6 6 6-6"/></svg>
          </button>
          <div class="yu-courses-mega">
            <div class="yu-courses-grid">
              <div>
                <p class="yu-mega-title" style="display:flex;align-items:center;gap:6px;"><?php echo yu_icon('book', 13); ?> Classes</p>
                <div class="yu-mega-classes">
                  <?php for ($cls = 5; $cls <= 12; $cls++): ?>
                    <a class="yu-mega-link" href="https://yuitor.com/class/<?php echo $cls; ?>">Class <?php echo $cls; ?></a>
                  <?php endfor; ?>
                </div>
              </div>
              <div>
                <p class="yu-mega-title" style="display:flex;align-items:center;gap:6px;"><?php echo yu_icon('trophy', 13); ?> Boards &amp; Exams</p>
                <a class="yu-mega-link" href="https://yuitor.com/board/cbse">CBSE Coaching</a>
                <a class="yu-mega-link" href="https://yuitor.com/board/up-board">UP Board Coaching</a>
                <a class="yu-mega-link" href="https://yuitor.com/board/icse">ICSE Coaching</a>
                <a class="yu-mega-link" href="https://yuitor.com/exam/neet">NEET Coaching</a>
                <a class="yu-mega-link" href="https://yuitor.com/exam/jee">JEE Coaching</a>
                <a class="yu-mega-link" href="https://yuitor.com/exam/cuet">CUET Coaching</a>
              </div>
              <div>
                <p class="yu-mega-title" style="display:flex;align-items:center;gap:6px;"><?php echo yu_icon('graduation', 13); ?> Skill Courses</p>
                <a class="yu-mega-link" href="https://yuitor.com/course/computer">Computer Classes</a>
                <a class="yu-mega-link" href="https://yuitor.com/course/spoken-english">Spoken English</a>
                <a class="yu-mega-link" href="https://yuitor.com/course/coding">Coding Classes</a>
                <div style="margin-top:12px;padding:12px;border-radius:12px;background:#eef6fa;border:1px solid #cfe0eb;">
                  <div style="font-size:12px;font-weight:700;color:#0f172a;display:flex;align-items:center;gap:6px;"><?php echo yu_icon('award', 14); ?> Online Admission Test</div>
                  <a href="<?php echo e(erp_url('admission-test/index.php')); ?>" style="display:block;margin-top:6px;text-align:center;padding:6px 10px;background:#2563eb;color:#fff;border-radius:8px;font-size:12px;font-weight:700;text-decoration:none;">Take Test Now</a>
                </div>
              </div>
            </div>
          </div>
        </div>
        <a href="https://yuitor.com/results">Results</a>
        <a href="https://yuitor.com/blog">Blog</a>
        <a href="https://yuitor.com/contact">Contact</a>
        <a href="https://yuitor.com/fee-calculator" class="yu-injected-fee-link" style="gap:6px;"><?php echo yu_icon('calculator', 14); ?> Fees &amp; Admission</a>
        <a href="<?php echo e(erp_url('index.php')); ?>" class="yu-nav-active" style="gap:6px;"><?php echo yu_icon('shield', 14); ?> ERP Portal</a>
      </nav>

      <div class="yu-header-actions">
        <?php if ($currentUser): ?>
          <a href="<?php echo e(erp_url(role_home($currentUser['role']))); ?>" class="yu-btn-ghost" style="display:inline-flex;align-items:center;gap:6px;"><?php echo yu_icon('dashboard', 14); ?> Dashboard</a>
          <a href="<?php echo e(erp_url('logout.php')); ?>" class="yu-btn-call"><?php echo yu_icon('logout', 14); ?> Logout</a>
        <?php else: ?>
          <a href="https://yuitor.com/contact" class="yu-btn-ghost">Admissions</a>
          <a href="https://yuitor.com/contact" class="yu-btn-enquire" data-testid="link-enquire"><?php echo yu_icon('send', 14); ?> Enquire Now</a>
          <a href="tel:+917827289292" class="yu-btn-call" data-testid="link-call-now"><?php echo yu_icon('phone', 14); ?> Call</a>
        <?php endif; ?>
      </div>

      <div class="yu-mobile-actions">
        <a href="<?php echo e(erp_url('admission-test/index.php')); ?>" class="yu-injected-fee-link" style="min-height:34px;padding:6px 10px;font-size:12.5px;gap:5px;"><?php echo yu_icon('award', 13); ?> Test</a>
        <button type="button" class="yu-hamburger" id="yuMobileOpenBtn" aria-label="Open menu">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 5h16"/><path d="M4 12h16"/><path d="M4 19h16"/></svg>
        </button>
      </div>
    </div>
  </div>
</header>

<div class="yu-mobile-menu" id="yuMobileDrawer" aria-hidden="true">
  <div class="yu-mobile-hero">
    <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;">
      <div style="display:flex;align-items:center;gap:12px;">
        <div class="yu-brand-logo-box"><img src="<?php echo e($instLogo); ?>" alt=""></div>
        <div>
          <div style="font-size:18px;font-weight:800;"><?php echo e($instName); ?></div>
          <div style="font-size:10px;letter-spacing:.12em;opacity:.85;">AI-ASSISTED · EXPERT-LED</div>
        </div>
      </div>
      <button type="button" id="yuMobileCloseBtn" style="background:rgba(255,255,255,0.14);border:0;color:#fff;border-radius:8px;padding:8px 12px;font-weight:700;cursor:pointer;">Close</button>
    </div>
    <div style="display:flex;gap:8px;margin-top:12px;font-size:12.5px;">
      <a href="tel:+917827289292" style="flex:1;display:inline-flex;align-items:center;justify-content:center;gap:6px;background:rgba(255,255,255,0.12);padding:8px;border-radius:8px;text-decoration:none;"><?php echo yu_icon('phone', 14); ?> +91 78-2728-9292</a>
      <span style="flex:1;display:inline-flex;align-items:center;justify-content:center;gap:6px;background:rgba(255,255,255,0.08);padding:8px;border-radius:8px;"><?php echo yu_icon('clock', 14); ?> 8 AM – 8 PM</span>
    </div>
  </div>
  <div style="padding:16px;display:flex;flex-direction:column;gap:6px;">
    <a href="<?php echo e(erp_url('index.php')); ?>" style="display:flex;align-items:center;gap:10px;padding:12px 14px;border-radius:10px;background:#edf5fa;font-weight:700;text-decoration:none;color:#1d4ed8;"><?php echo yu_icon('shield', 17); ?> ERP Portal Home</a>
    <a href="<?php echo e(erp_url('admission-test/index.php')); ?>" style="display:flex;align-items:center;gap:10px;padding:12px 14px;border-radius:10px;background:#f5f9fc;font-weight:600;text-decoration:none;"><?php echo yu_icon('award', 17); ?> Online Admission Test</a>
    <a href="https://yuitor.com/" style="display:flex;align-items:center;gap:10px;padding:12px 14px;border-radius:10px;text-decoration:none;"><?php echo yu_icon('graduation', 17); ?> Main Website</a>
    <a href="https://yuitor.com/about" style="display:flex;align-items:center;gap:10px;padding:12px 14px;border-radius:10px;text-decoration:none;"><?php echo yu_icon('book', 17); ?> About Us</a>
    <a href="https://yuitor.com/results" style="display:flex;align-items:center;gap:10px;padding:12px 14px;border-radius:10px;text-decoration:none;"><?php echo yu_icon('trophy', 17); ?> Results &amp; Toppers</a>
    <a href="https://yuitor.com/fee-calculator" style="display:flex;align-items:center;gap:10px;padding:12px 14px;border-radius:10px;text-decoration:none;"><?php echo yu_icon('calculator', 17); ?> Fee Calculator</a>
    <a href="https://yuitor.com/contact" style="display:flex;align-items:center;gap:10px;padding:12px 14px;border-radius:10px;text-decoration:none;"><?php echo yu_icon('phone', 17); ?> Contact Us</a>
    <?php if ($currentUser): ?>
      <a href="<?php echo e(erp_url('logout.php')); ?>" style="margin-top:8px;display:flex;align-items:center;gap:10px;padding:12px 14px;border-radius:10px;background:#fef2f2;color:#b91c1c;font-weight:700;text-decoration:none;"><?php echo yu_icon('logout', 17); ?> Sign Out (<?php echo e($currentUser['full_name']); ?>)</a>
    <?php endif; ?>
  </div>
</div>

<main class="yuitor-erp-shell">
  <div class="yuitor-erp-layout <?php echo !empty($showPanelSidebar) ? 'has-sidebar' : ''; ?>">
