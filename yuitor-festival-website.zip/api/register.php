<?php
declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';
yu_api_init();

if (strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET')) !== 'POST') {
    header('Allow: POST');
    yu_fail(405, 'Method not allowed.');
}

yu_require_same_origin();
$input = yu_read_json();
yu_require_csrf();

// A quiet honeypot catches basic bots without affecting real visitors.
if (trim((string) ($input['website'] ?? '')) !== '') {
    yu_json(201, array('registered' => true, 'message' => 'Registration received.'));
}

$now = time();
if (isset($_SESSION['yu_last_registration']) && ($now - (int) $_SESSION['yu_last_registration']) < 30) {
    yu_fail(429, 'Please wait a moment before submitting another registration.');
}

try {
    $db = yu_db();
} catch (Throwable $error) {
    error_log('Yuitor portal database error: ' . $error->getMessage());
    yu_fail(503, 'The registration could not be saved. Please try again later.');
}

$fullName = yu_text($input, 'fullName', 120, true);
$email = yu_email(yu_text($input, 'email', 254, true));
$phone = yu_text($input, 'phone', 24, true);
$classLevel = yu_text($input, 'classLevel', 60, true);
$subject = yu_text($input, 'selectedSubject', 120, true);
$durationValue = filter_var($input['courseDurationMonths'] ?? null, FILTER_VALIDATE_INT);
$password = yu_text($input, 'password', 200, true);

if (strlen($fullName) < 2) {
    yu_fail(400, 'Please enter the student’s full name.');
}
if (!yu_valid_phone($phone)) {
    yu_fail(400, 'Please enter a valid phone number.');
}
if ($durationValue === false || $durationValue < 1 || $durationValue > 60) {
    yu_fail(400, 'Course duration must be between 1 and 60 months.');
}
if (strlen($password) < 12) {
    yu_fail(400, 'Choose a password with at least 12 characters.');
}

try {
    $insert = $db->prepare(
        "INSERT INTO students
         (full_name, email, phone, password_hash, class_level, selected_subject,
          course_duration_months, admission_date, fee_status, next_fee_due,
          fee_alert_note, registration_status, is_active, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, NULL, 'pending', NULL, '', 'pending', 1, ?, ?)"
    );
    $createdAt = gmdate('c');
    $insert->execute(array(
        $fullName,
        $email,
        $phone,
        password_hash($password, PASSWORD_DEFAULT),
        $classLevel,
        $subject,
        $durationValue,
        $createdAt,
        $createdAt,
    ));
} catch (PDOException $error) {
    if (stripos($error->getMessage(), 'unique') !== false) {
        yu_fail(409, 'An account already exists for this email. Try signing in instead.');
    }
    error_log('Yuitor student registration error: ' . $error->getMessage());
    yu_fail(500, 'The registration could not be saved. Please try again later.');
}

$_SESSION['yu_last_registration'] = $now;
yu_json(201, array(
    'registered' => true,
    'message' => 'Registration received. You can now sign in to the Student portal.',
));
