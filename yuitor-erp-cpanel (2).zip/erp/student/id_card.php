<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/icons.php';
send_security_headers();
$user = require_login();

if ($user['role'] === 'student') {
    $st = current_student_record($user['id']);
} else {
    $stId = (int)($_GET['student_id'] ?? 0);
    assert_student_access($user, $stId);
    $q = db()->prepare("SELECT s.*, u.full_name, u.email, b.name AS branch_name, c.title AS course_title, ba.name AS batch_name
                        FROM students s JOIN users u ON u.id=s.user_id JOIN branches b ON b.id=s.branch_id JOIN courses c ON c.id=s.course_id JOIN batches ba ON ba.id=s.batch_id WHERE s.id = ?");
    $q->execute([$stId]);
    $st = $q->fetch();
}
if (!$st) die('Student not found.');
$qrUrl = 'https://api.qrserver.com/v1/create-qr-code/?size=160x160&data=' . urlencode($st['qr_token']);
$instName = get_setting('institute_name', 'Yuitor Smart Classes');
$instLogo = get_setting('institute_logo', '/erp/assets/images/yuitor-smart-classes-logo.png');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Student ID Card - <?php echo e($st['admission_no']); ?> | <?php echo e($instName); ?></title>
  <link rel="icon" href="/erp/assets/images/yuitor-icon-192.png">
</head>
<body style="font-family:'DM Sans',Arial,sans-serif;background:#f5f9fc;padding:30px;display:flex;justify-content:center;align-items:center;min-height:100vh;margin:0;">
  <div style="width:370px;background:#fff;border:2px solid #0f172a;border-radius:18px;overflow:hidden;box-shadow:0 16px 36px rgba(15,23,42,.12);position:relative;">
    <div style="background:linear-gradient(125deg,#0f172a,#123c52,#0b7b82);color:#fff;padding:16px 18px;display:flex;align-items:center;gap:12px;">
      <div style="width:46px;height:46px;border-radius:50%;background:#eef6fa;border:1.5px solid #78d3d3;padding:2px;flex-shrink:0;overflow:hidden;">
        <img src="<?php echo e($instLogo); ?>" alt="<?php echo e($instName); ?>" style="width:100%;height:100%;object-fit:contain;border-radius:50%;">
      </div>
      <div>
        <div style="font-size:17px;font-weight:800;line-height:1.15;"><?php echo e($instName); ?></div>
        <div style="font-size:10px;color:#78d3d3;letter-spacing:1.2px;font-weight:700;margin-top:3px;">STUDENT QR IDENTITY CARD</div>
      </div>
    </div>
    <div style="padding:20px;text-align:center;position:relative;">
      <img src="/erp/assets/images/yuitor-watermark.png" alt="" style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:190px;opacity:0.06;pointer-events:none;">
      <h2 style="margin:0 0 4px;font-size:20px;color:#0f172a;position:relative;"><?php echo e($st['full_name'] ?? $user['full_name']); ?></h2>
      <div style="font-size:13px;font-weight:700;color:#2563eb;margin-bottom:14px;display:inline-flex;align-items:center;gap:5px;position:relative;"><?php echo yu_icon('id-card', 14); ?> <?php echo e($st['admission_no']); ?></div>
      <div style="position:relative;">
        <img src="<?php echo e($qrUrl); ?>" alt="QR Attendance Token" style="width:152px;height:152px;border:1px solid #dbe6ef;border-radius:12px;padding:6px;background:#fff;">
      </div>
      <div style="margin-top:8px;font-size:11px;color:#64748b;word-break:break-all;">Token: <?php echo e($st['qr_token']); ?></div>
      <div style="margin-top:14px;text-align:left;font-size:13px;background:#f5f9fc;padding:12px 14px;border-radius:12px;border:1px solid #dbe6ef;display:grid;gap:6px;position:relative;">
        <div style="display:flex;align-items:center;gap:7px;color:#0f172a;"><?php echo yu_icon('branches', 14); ?> <strong>Branch:</strong> <?php echo e($st['branch_name']); ?></div>
        <div style="display:flex;align-items:center;gap:7px;color:#0f172a;"><?php echo yu_icon('book', 14); ?> <strong>Course:</strong> <?php echo e($st['course_title']); ?></div>
        <div style="display:flex;align-items:center;gap:7px;color:#0f172a;"><?php echo yu_icon('clock', 14); ?> <strong>Batch:</strong> <?php echo e($st['batch_name']); ?></div>
      </div>
      <button onclick="window.print()" style="margin-top:16px;padding:10px 18px;background:#2563eb;color:#fff;border:0;border-radius:10px;font-weight:700;cursor:pointer;display:inline-flex;align-items:center;gap:7px;position:relative;"><?php echo yu_icon('printer', 15); ?> Print ID Card</button>
    </div>
  </div>
</body>
</html>
