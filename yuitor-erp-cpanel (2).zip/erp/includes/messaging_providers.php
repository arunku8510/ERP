<?php
// Yuitor Coaching ERP - Fast2SMS, Official WhatsApp Cloud API, Branded Email & Queue Engine
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/mail_theme.php';

function is_unsubscribed($channel, $contact) {
    $stmt = db()->prepare("SELECT id FROM message_unsubscribes WHERE channel = ? AND contact = ? LIMIT 1");
    $stmt->execute([$channel, trim((string)$contact)]);
    return (bool)$stmt->fetchColumn();
}

function enqueue_message($channel, $recipient, $recipientName, $subject, $body, $templateId = '', $scheduledAt = null, $createdBy = null) {
    $recipient = trim((string)$recipient);
    if ($recipient === '') return false;
    if (is_unsubscribed($channel, $recipient)) {
        db()->prepare("INSERT INTO message_queue (channel, recipient, recipient_name, subject, body, template_id, status, error_message, created_by) VALUES (?, ?, ?, ?, ?, ?, 'skipped', 'Recipient unsubscribed', ?)")
            ->execute([$channel, $recipient, $recipientName, $subject, $body, $templateId, $createdBy]);
        return false;
    }
    $sched = $scheduledAt ?: date('Y-m-d H:i:s');
    db()->prepare("INSERT INTO message_queue (channel, recipient, recipient_name, subject, body, template_id, status, scheduled_at, created_by) VALUES (?, ?, ?, ?, ?, ?, 'pending', ?, ?)")
        ->execute([$channel, $recipient, $recipientName, $subject, $body, $templateId, $sched, $createdBy]);
    return (int)db()->lastInsertId();
}

function send_fast2sms($phone, $message, $templateId = '') {
    $apiKey = get_setting('fast2sms_api_key', '');
    if ($apiKey === '') {
        return ['ok' => false, 'error' => 'Fast2SMS API key not configured in Admin -> Settings.'];
    }
    $digits = preg_replace('/\D+/', '', (string)$phone);
    if (strlen($digits) > 10) $digits = substr($digits, -10);
    if (strlen($digits) !== 10) {
        return ['ok' => false, 'error' => 'Invalid 10-digit Indian mobile number for Fast2SMS.'];
    }
    $route = get_setting('fast2sms_route', 'dlt');
    $sender = get_setting('fast2sms_sender_id', 'YUITOR');
    $dltId = $templateId !== '' ? $templateId : get_setting('fast2sms_dlt_template_id', '');

    $payload = [
        'route' => ($route === 'dlt' && $dltId !== '') ? 'dlt' : 'q',
        'numbers' => $digits,
        'language' => 'english',
    ];
    if ($payload['route'] === 'dlt') {
        $payload['sender_id'] = $sender;
        $payload['message'] = $dltId;
        $payload['variables_values'] = $message;
    } else {
        $payload['message'] = $message;
    }

    if (!function_exists('curl_init')) {
        return ['ok' => false, 'error' => 'cURL extension is not enabled in PHP.'];
    }
    $ch = curl_init('https://www.fast2sms.com/dev/bulkV2');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($payload),
        CURLOPT_HTTPHEADER => [
            'authorization: ' . $apiKey,
            'Content-Type: application/json',
        ],
        CURLOPT_TIMEOUT => 15,
    ]);
    $resp = curl_exec($ch);
    $err = curl_error($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($err) return ['ok' => false, 'error' => 'cURL error: ' . $err];
    $json = json_decode((string)$resp, true);
    if ($code >= 200 && $code < 300 && !empty($json['return'])) {
        return ['ok' => true, 'error' => ''];
    }
    return ['ok' => false, 'error' => 'Fast2SMS Error: ' . ($json['message'] ?? $resp)];
}

function send_whatsapp_cloud($phone, $message, $templateName = '') {
    $token = get_setting('whatsapp_access_token', '');
    $phoneId = get_setting('whatsapp_phone_number_id', '');
    if ($token === '' || $phoneId === '') {
        return ['ok' => false, 'error' => 'WhatsApp Cloud API Token or Phone Number ID not configured.'];
    }
    $digits = preg_replace('/\D+/', '', (string)$phone);
    if (strlen($digits) === 10) $digits = '91' . $digits;
    if (strlen($digits) < 11) {
        return ['ok' => false, 'error' => 'Invalid WhatsApp phone number.'];
    }
    $body = [
        'messaging_product' => 'whatsapp',
        'to' => $digits,
    ];
    if ($templateName !== '') {
        $body['type'] = 'template';
        $body['template'] = [
            'name' => $templateName,
            'language' => ['code' => 'en'],
        ];
    } else {
        $body['type'] = 'text';
        $body['text'] = ['body' => $message];
    }
    $ch = curl_init("https://graph.facebook.com/v19.0/{$phoneId}/messages");
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($body),
        CURLOPT_HTTPHEADER => [
            'Authorization: Bearer ' . $token,
            'Content-Type: application/json',
        ],
        CURLOPT_TIMEOUT => 15,
    ]);
    $resp = curl_exec($ch);
    $err = curl_error($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($err) return ['ok' => false, 'error' => 'cURL error: ' . $err];
    if ($code >= 200 && $code < 300) return ['ok' => true, 'error' => ''];
    return ['ok' => false, 'error' => 'WhatsApp API Error: ' . $resp];
}

function dispatch_queue_batch($limit = 25) {
    $stmt = db()->prepare("SELECT * FROM message_queue WHERE status = 'pending' AND scheduled_at <= NOW() AND attempts < 3 ORDER BY id ASC LIMIT ?");
    $stmt->bindValue(1, (int)$limit, PDO::PARAM_INT);
    $stmt->execute();
    $rows = $stmt->fetchAll();
    $sentCount = 0;
    foreach ($rows as $row) {
        if (is_unsubscribed($row['channel'], $row['recipient'])) {
            db()->prepare("UPDATE message_queue SET status = 'skipped', error_message = 'Unsubscribed' WHERE id = ?")->execute([(int)$row['id']]);
            continue;
        }
        $res = ['ok' => false, 'error' => 'Unknown channel'];
        if ($row['channel'] === 'email') {
            $unsubLink = 'https://yuitor.com/erp/unsubscribe.php?ch=email&c=' . urlencode($row['recipient']);
            $bodyHtml = nl2br(e($row['body'])) . '<p style="margin-top:16px;font-size:12px;color:#64748b;"><a href="' . e($unsubLink) . '">Unsubscribe from notification alerts</a></p>';
            $res = send_branded_email($row['recipient'], $row['recipient_name'], $row['subject'] ?: 'Notification from Yuitor Smart Classes', $bodyHtml);
        } elseif ($row['channel'] === 'sms') {
            $res = send_fast2sms($row['recipient'], $row['body'], $row['template_id']);
        } elseif ($row['channel'] === 'whatsapp') {
            $res = send_whatsapp_cloud($row['recipient'], $row['body'], $row['template_id']);
        }
        if ($res['ok']) {
            db()->prepare("UPDATE message_queue SET status = 'sent', attempts = attempts + 1, sent_at = NOW(), error_message = '' WHERE id = ?")
                ->execute([(int)$row['id']]);
            $sentCount++;
        } else {
            $attempts = (int)$row['attempts'] + 1;
            $newSt = $attempts >= 3 ? 'failed' : 'pending';
            db()->prepare("UPDATE message_queue SET status = ?, attempts = ?, error_message = ? WHERE id = ?")
                ->execute([$newSt, $attempts, substr((string)$res['error'], 0, 250), (int)$row['id']]);
        }
    }
    return ['processed' => count($rows), 'sent' => $sentCount];
}
