<?php
require_once dirname(__DIR__) . '/erp/includes/auth.php';
send_security_headers();
start_secure_session();

$existing = current_user();
if ($existing && $existing['role'] === 'student') {
    redirect_to('/erp/student/dashboard.php');
}

$err = '';
$ok = '';
$old = [
    'student_name'    => '',
    'parent_name'     => '',
    'email'           => '',
    'phone'           => '',
    'class_grade'     => '',
    'board'           => 'CBSE',
    'course_interest' => '',
    'message'         => '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    foreach ($old as $k => $_) {
        $old[$k] = trim((string) ($_POST[$k] ?? ''));
    }

    if (!empty($_POST['website_url'])) {
        $ok = 'Registration submitted. Please check your email for verification.';
    } elseif (!verify_public_captcha($_POST['captcha'] ?? null)) {
        $err = 'Security math answer is incorrect. Please try again.';
    } else {
        $studentName = $old['student_name'];
        $parentName = $old['parent_name'];
        $email = strtolower($old['email']);
        $phone = preg_replace('/[^0-9+\- ]/', '', $old['phone']);
        $classGrade = $old['class_grade'];
        $board = $old['board'] ?: 'CBSE';
        $courseInterest = $old['course_interest'];
        $message = $old['message'];
        $pass = (string) ($_POST['password'] ?? '');
        $confirmPass = (string) ($_POST['confirm_password'] ?? '');
        $ip = client_ip();
        $pdo = db();

        if (mb_strlen($studentName) < 2) {
            $err = 'Please enter the student full name.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $err = 'Please enter a valid email address.';
        } elseif (strlen(preg_replace('/\D+/', '', $phone)) < 10) {
            $err = 'Please enter a valid 10-digit phone number.';
        } elseif ($classGrade === '' || $courseInterest === '') {
            $err = 'Please specify class/grade and subject or course interest.';
        } elseif (strlen($pass) < 8) {
            $err = 'Password must be at least 8 characters long.';
        } elseif ($pass !== $confirmPass) {
            $err = 'Password and confirm password do not match.';
        } elseif (!check_rate_limit($pdo, 'student_reg', $ip, 5, 15, true)) {
            $err = 'Too many registration requests. Please wait 15 minutes and try again.';
        } else {
            $dupUser = $pdo->prepare("SELECT id FROM users WHERE email = ? AND deleted_at IS NULL LIMIT 1");
            $dupUser->execute([$email]);
            if ($dupUser->fetchColumn()) {
                $err = 'An account with this email already exists. Please use Student Sign In or Forgot Password.';
            } else {
                $otpCode = sprintf('%06d', random_int(0, 999999));
                $otpHash = password_hash($otpCode, PASSWORD_DEFAULT);
                $passHash = password_hash($pass, PASSWORD_DEFAULT);

                $pdo->prepare(
                    "INSERT INTO online_registrations
                     (branch_id, student_name, parent_name, email, phone, class_grade, board, course_interest, message, password_hash, email_verified, verification_code_hash, verification_expires_at, status, ip_address)
                     VALUES (1, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, DATE_ADD(NOW(), INTERVAL 30 MINUTE), 'New', ?)"
                )->execute([
                    $studentName,
                    $parentName,
                    $email,
                    $phone,
                    $classGrade,
                    $board,
                    $courseInterest,
                    $message,
                    $passHash,
                    $otpHash,
                    $ip,
                ]);

                $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://';
                $host = !empty($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : YU_MAIL_DOMAIN;
                $verifyUrl = $scheme . $host . '/student/verify-email.php?email=' . urlencode($email);

                send_student_verification_email($email, $studentName, $otpCode, $verifyUrl);

                $adminNotify = get_setting('admin_2fa_email', YU_DEMO_ADMIN_EMAIL);
                $admBody = '<p>A new student registration was submitted on the website:</p><ul>'
                    . '<li><strong>Student:</strong> ' . e($studentName) . '</li>'
                    . '<li><strong>Parent:</strong> ' . e($parentName ?: '-') . '</li>'
                    . '<li><strong>Email:</strong> ' . e($email) . '</li>'
                    . '<li><strong>Phone:</strong> ' . e($phone) . '</li>'
                    . '<li><strong>Class / Board:</strong> ' . e($classGrade) . ' (' . e($board) . ')</li>'
                    . '<li><strong>Subject / Course:</strong> ' . e($courseInterest) . '</li>'
                    . '</ul>';
                send_branded_email($adminNotify, 'Admissions Team', 'New Student Registration - ' . $studentName, $admBody);

                $_SESSION['pending_verify_email'] = $email;
                flash_set('success', 'Registration submitted! A 6-digit verification code has been sent from ' . YU_MAIL_FROM_EMAIL . ' to ' . $email . '.');
                header('Location: /student/verify-email.php?email=' . urlencode($email));
                exit;
            }
        }
    }
}

$captchaQ = generate_public_captcha();
$pageTitle = 'Student Admission Registration';
$portalMode = 'student';
$showPanelSidebar = false;
include dirname(__DIR__) . '/erp/includes/site_header.php';
?>
<div style="max-width:680px;margin:20px auto;">
  <div class="yu-card">
    <div style="font-size:11.5px;font-weight:700;color:#0b7b82;text-transform:uppercase;letter-spacing:.08em;">Yuitor Smart Classes · Student Admission</div>
    <h1 style="margin:4px 0 6px;font-family:'Manrope',sans-serif;font-size:24px;">New Student Registration</h1>
    <p style="margin:0 0 18px;color:#52687c;font-size:14px;">Register your details below. We will send a 6-digit email verification code from <code><?php echo e(YU_MAIL_FROM_EMAIL); ?></code> to confirm your email.</p>

    <?php if ($err !== ''): ?><div class="yu-alert yu-alert-danger"><?php echo e($err); ?></div><?php endif; ?>
    <?php if ($ok !== ''): ?><div class="yu-alert yu-alert-success"><?php echo e($ok); ?></div><?php endif; ?>

    <form method="post">
      <?php echo csrf_field(); ?>
      <input type="text" name="website_url" style="display:none" tabindex="-1" autocomplete="off">

      <div class="yu-form-row">
        <div class="yu-field"><label for="stName">Student Full Name</label><input id="stName" type="text" name="student_name" required value="<?php echo e($old['student_name']); ?>"></div>
        <div class="yu-field"><label for="parName">Parent / Guardian Name</label><input id="parName" type="text" name="parent_name" value="<?php echo e($old['parent_name']); ?>"></div>
      </div>

      <div class="yu-form-row">
        <div class="yu-field"><label for="stEmail">Student Email Address</label><input id="stEmail" type="email" name="email" required value="<?php echo e($old['email']); ?>" placeholder="student@domain.com"></div>
        <div class="yu-field"><label for="stPhone">Mobile Number</label><input id="stPhone" type="tel" name="phone" required value="<?php echo e($old['phone']); ?>" placeholder="+91-7827289292"></div>
      </div>

      <div class="yu-form-row">
        <div class="yu-field">
          <label for="stClass">Class / Target Exam</label>
          <input id="stClass" type="text" name="class_grade" required value="<?php echo e($old['class_grade']); ?>" placeholder="e.g. Class 10, Class 12, JEE, NEET">
        </div>
        <div class="yu-field">
          <label for="stBoard">Board / Track</label>
          <select id="stBoard" name="board">
            <?php foreach (['CBSE', 'UP Board', 'ICSE', 'Competitive Exam', 'Skill Course'] as $bOpt): ?>
              <option value="<?php echo e($bOpt); ?>" <?php echo $old['board'] === $bOpt ? 'selected' : ''; ?>><?php echo e($bOpt); ?></option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>

      <div class="yu-field" style="margin-bottom:12px;">
        <label for="stCourse">Subject / Course Interest</label>
        <input id="stCourse" type="text" name="course_interest" required value="<?php echo e($old['course_interest']); ?>" placeholder="Mathematics, Science, Physics, Coding, Spoken English">
      </div>

      <div class="yu-form-row">
        <div class="yu-field"><label for="stPass">Create Password (min 8 chars)</label><input id="stPass" type="password" name="password" minlength="8" required autocomplete="new-password"></div>
        <div class="yu-field"><label for="stPass2">Confirm Password</label><input id="stPass2" type="password" name="confirm_password" minlength="8" required autocomplete="new-password"></div>
      </div>

      <div class="yu-field" style="margin-bottom:12px;">
        <label for="stMsg">Preferred Batch Timing / Notes (Optional)</label>
        <textarea id="stMsg" name="message" rows="2"><?php echo e($old['message']); ?></textarea>
      </div>

      <div class="yu-field" style="margin-bottom:16px;">
        <label for="stCap">Security Check: What is <?php echo e($captchaQ); ?>?</label>
        <input id="stCap" type="number" name="captcha" required>
      </div>

      <button type="submit" class="yu-btn yu-btn-primary" style="width:100%;padding:12px;">Submit Registration &amp; Send Verification Code</button>
    </form>

    <div style="margin-top:14px;display:flex;justify-content:space-between;flex-wrap:wrap;gap:10px;font-size:13.5px;">
      <a href="/student/login.php" style="color:#2563eb;font-weight:700;text-decoration:none;">Already registered? Student Sign In &rarr;</a>
      <a href="/student/verify-email.php" style="color:#0b7b82;font-weight:600;text-decoration:none;">Verify Email Code</a>
    </div>
  </div>
</div>
<?php include dirname(__DIR__) . '/erp/includes/site_footer.php'; ?>
