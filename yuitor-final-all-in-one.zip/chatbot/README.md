# Yuitor Smart Classes — AI Customer Support Chatbot & Knowledge Base

Yeh package aapki website ke liye ek complete, fast aur secure customer-support chatbot + **100,000+ Q&A pairs (~100 MB)** ka knowledge base deta hai. Ismein Hindi, English aur Hinglish (typos aur casual messages ke saath) support shamil hai.

---

## Folder Structure
- `backend/` — FastAPI server (`main.py`), SQLite FTS5 + Hinglish/typo search engine (`engine.py`), aur pre-answer security firewall (`security.py`)
- `data/` — `dataset.jsonl` + `dataset.csv` (~100 MB, 100k+ unique Q&A pairs), `tests.jsonl`, aur fast search index `kb.sqlite`
- `widget/` — Single-script floating chat widget (`chatbot-widget.js`) + demo page (`demo.html`)
- `business_config.json` — Aapke business ki saari verified details (fees, phone, email, address, courses, policies)
- `generate_dataset.py` — Knowledge base & test suite generator script
- `run_tests.py` — Accuracy, security aur guardrail tests runner

---

## 1. Local Computer par Kaise Chalayein
1. Python 3.10+ install hona chahiye.
2. Dependencies install karein:
   ```bash
   pip install -r requirements.txt
   ```
3. Environment file banayein:
   ```bash
   cp .env.example .env
   ```
   *(Optional: agar live cricket score API chahiye toh `.env` mein `SPORTS_API_KEY` aur `SPORTS_API_URL` daal dein.)*
4. FastAPI server start karein:
   ```bash
   uvicorn backend.main:app --host 0.0.0.0 --port 8000
   ```
5. Browser mein `widget/demo.html` kholein (ya `python -m http.server 5500` chala kar `http://localhost:5500/widget/demo.html` dekhein).

---

## 2. Apni Business Info Kaise Update Karein
- `business_config.json` kholein aur apna phone, email, address, timing, courses/fees ya refund/privacy policy edit karein.
- Dhyaan rahe: `business_config.json` mein kabhi bhi admin password, API keys, OTP ya personal mobile numbers na daalein.

---

## 3. Dataset (100,000+ Q&A) Dobara Kaise Banayein
Jab bhi aap `business_config.json` update karein, yeh command chalayein:
```bash
python generate_dataset.py
```
Yeh automatically `data/dataset.jsonl`, `data/dataset.csv`, `data/tests.jsonl` aur `data/kb.sqlite` naye data se regenerate kar dega.

---

## 4. Tests Kaise Run Karein
Accuracy aur 200+ security attack tests verify karne ke liye:
```bash
python run_tests.py
```

---

## 5. Apni Website par Chat Widget Kaise Lagayein
Apni HTML/PHP website ke `</body>` tag se theek pehle bas yeh ek `<script>` line add kar dein:
```html
<script
  src="https://YOUR-BACKEND-DOMAIN/widget/chatbot-widget.js"
  data-api="https://YOUR-BACKEND-DOMAIN/chat"
  data-title="Yuitor Smart Support">
</script>
```
Widget mein automatic mobile responsiveness, quick-reply buttons (`Fee`, `Admission`, `Contact`, `Refund policy`), typing indicator, 300-character limit aur keyboard accessibility (`Enter`, `Esc`, `Tab`) included hai.

---

## 6. Replit par Kaise Deploy Karein
1. Replit par naya **Python** Repl banayein aur is ZIP ke saare files upload karein.
2. Replit Shell mein run karein:
   ```bash
   pip install -r requirements.txt
   ```
   *(Agar `data/kb.sqlite` size ke liye skip kiya ho, toh ek baar `python generate_dataset.py` ya server boot apne aap index bana lega.)*
3. Replit **Secrets** (Environment Variables) mein optional keys add karein:
   - `ALLOWED_ORIGINS` = `https://yuitor.com,https://www.yuitor.com` (ya `*` testing ke liye)
   - `RATE_LIMIT_PER_MIN` = `45`
   - `SPORTS_API_KEY` (optional)
4. `.replit` ya Run command set karein:
   ```bash
   uvicorn backend.main:app --host 0.0.0.0 --port $PORT
   ```
5. Replit se milne wala live HTTPS URL apni website ke `<script data-api="https://YOUR-REPL-URL/chat">` mein lagayein.
