(() => {
  "use strict";
  if (document.getElementById("yu-ai-guide-root")) return;

  let csrfToken = "";
  fetch("/api/csrf.php", { credentials: "same-origin" })
    .then((r) => r.json())
    .then((d) => { csrfToken = d.csrf_token || ""; })
    .catch(() => {});

  const root = document.createElement("div");
  root.id = "yu-ai-guide-root";
  root.style.cssText = "position:fixed;bottom:92px;right:20px;z-index:9999;font-family:system-ui,-apple-system,sans-serif;";

  const toggle = document.createElement("button");
  toggle.type = "button";
  toggle.textContent = "AI Website Guide";
  toggle.style.cssText = "background:#0f172a;color:#fff;border:2px solid #12a1a1;padding:11px 18px;border-radius:999px;font-weight:700;font-size:14px;cursor:pointer;box-shadow:0 10px 25px rgba(15,23,42,.28);";

  const box = document.createElement("div");
  box.hidden = true;
  box.style.cssText = "width:340px;max-width:calc(100vw - 32px);background:#fff;border:1px solid #cbd9e6;border-radius:16px;box-shadow:0 18px 40px rgba(15,23,42,.24);overflow:hidden;margin-bottom:10px;";

  box.innerHTML = `
    <div style="background:#0f172a;color:#fff;padding:12px 14px;display:flex;justify-content:space-between;align-items:center;">
      <div>
        <div style="font-weight:700;font-size:14px;">Yuitor AI Guide</div>
        <div style="font-size:11px;color:#78d3d3;">Admission, Login, Fees &amp; Contact Help</div>
      </div>
      <button type="button" id="yu-chat-close" style="background:none;border:0;color:#fff;font-size:20px;cursor:pointer;line-height:1;">&times;</button>
    </div>
    <div id="yu-chat-msgs" style="height:260px;overflow-y:auto;padding:12px;background:#f5f9fc;display:flex;flex-direction:column;gap:8px;font-size:13px;">
      <div style="background:#fff;border:1px solid #dbe6ef;color:#0f172a;padding:9px 11px;border-radius:12px;max-width:88%;">
        Namaste! Main Yuitor AI Guide hoon. Registration, admission process, ERP login, fee payment ya contact ke baare me poochein.
      </div>
    </div>
    <form id="yu-chat-form" style="display:flex;gap:6px;padding:10px;border-top:1px solid #dbe6ef;background:#fff;">
      <input id="yu-chat-in" type="text" maxlength="350" required placeholder="Apna sawaal likhein..." style="flex:1;padding:8px 10px;border:1px solid #cbd9e6;border-radius:10px;font-size:13px;">
      <button type="submit" style="background:#12a1a1;color:#fff;border:0;padding:8px 14px;border-radius:10px;font-weight:700;cursor:pointer;">Send</button>
    </form>
  `;

  root.append(box, toggle);
  document.body.appendChild(root);

  const msgs = box.querySelector("#yu-chat-msgs");
  const form = box.querySelector("#yu-chat-form");
  const input = box.querySelector("#yu-chat-in");
  const closeBtn = box.querySelector("#yu-chat-close");

  const addBubble = (text, isUser) => {
    const div = document.createElement("div");
    div.style.cssText = isUser
      ? "align-self:flex-end;background:#0f172a;color:#fff;padding:9px 11px;border-radius:12px;max-width:88%;white-space:pre-line;"
      : "align-self:flex-start;background:#fff;border:1px solid #dbe6ef;color:#0f172a;padding:9px 11px;border-radius:12px;max-width:88%;white-space:pre-line;";
    div.textContent = text;
    msgs.appendChild(div);
    msgs.scrollTop = msgs.scrollHeight;
  };

  toggle.addEventListener("click", () => { box.hidden = !box.hidden; });
  closeBtn.addEventListener("click", () => { box.hidden = true; });

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const txt = input.value.trim();
    if (!txt) return;
    addBubble(txt, true);
    input.value = "";
    input.disabled = true;

    try {
      if (!csrfToken) {
        const c = await fetch("/api/csrf.php", { credentials: "same-origin" }).then((r) => r.json());
        csrfToken = c.csrf_token || "";
      }
      const res = await fetch("/api/chatbot.php", {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-CSRF-TOKEN": csrfToken },
        credentials: "same-origin",
        body: JSON.stringify({ message: txt, csrf_token: csrfToken }),
      });
      const data = await res.json();
      addBubble(data.reply || "Dobara try karein.", false);
    } catch {
      addBubble("Network error. Kripya internet check karein.", false);
    } finally {
      input.disabled = false;
      input.focus();
    }
  });
})();
