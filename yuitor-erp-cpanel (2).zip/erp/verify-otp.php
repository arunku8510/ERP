<?php
require_once __DIR__ . '/includes/auth.php';
send_security_headers();
start_secure_session();

if (empty($_SESSION['pending_2fa_uid'])) {
    redirect_to('index.php');
}
$uid = (int)$_SESSION['pending_2fa_uid'];
$destEmail = (string)($_SESSION['pending_2fa_email'] ?? '');
$stmt = db()->prepare("SELECT * FROM users WHERE id = ? AND is_active = 1 AND deleted_at IS NULL LIMIT 1");
$stmt->execute([$uid]);
$user = $stmt->fetch();
if (!$user) {
    unset($_SESSION['pending_2fa_uid']);
    redirect_to('index.php');
}

$msg = '';
$err = '';
if (!empty($_SESSION['otp_mail_warn'])) {
    $err = $_SESSION['otp_mail_warn'];
    unset($_SESSION['otp_mail_warn']);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    if (isset($_POST['resend'])) {
        $lastResend = (int)($_SESSION['last_otp_resend'] ?? 0);
        if (time() - $lastResend < 45) {
            $err = 'Please wait ' . (45 - (time() - $lastResend)) . ' seconds before requesting a new OTP.';
        } else {
            $otp = generate_6digit_otp($uid, 'admin_2fa', 10);
            $res = send_otp_email($destEmail, $user['full_name'], $otp);
            $_SESSION['last_otp_resend'] = time();
            $msg = $res['ok'] ? 'A fresh 6-digit OTP has been sent to ' . mask_email($destEmail) : ('Mail error: ' . $res['error']);
        }
    } else {
        $code = trim((string)($_POST['otp_code'] ?? ''));
        if (verify_6digit_otp($uid, 'admin_2fa', $code)) {
            unset($_SESSION['pending_2fa_uid'], $_SESSION['pending_2fa_email']);
            complete_user_login($user);
            redirect_to(role_home($user['role']));
        } else {
            $err = 'Invalid or expired 6-digit OTP code. Please try again.';
        }
    }
}

$pageTitle = 'Verify 6-Digit Admin OTP';
$showPanelSidebar = false;
include __DIR__ . '/includes/site_header.php';
$brandLogo = get_setting('institute_logo', '/erp/assets/images/yuitor-smart-classes-logo.png');
?>
<div style="max-width:480px;margin:24px auto;">
  <div class="yu-card">
    <div style="display:flex;align-items:center;gap:12px;margin-bottom:10px;">
      <div style="width:46px;height:46px;border-radius:50%;background:#eef6fa;border:1.5px solid #bfe3eb;padding:3px;flex-shrink:0;overflow:hidden;">
        <img src="<?php echo e($brandLogo); ?>" alt="Yuitor Smart Classes" style="width:100%;height:100%;object-fit:contain;border-radius:50%;">
      </div>
      <div>
        <div style="font-size:11px;font-weight:700;color:#0b7b82;text-transform:uppercase;letter-spacing:.08em;display:flex;align-items:center;gap:5px;"><?php echo yu_icon('otp', 13); ?> Yuitor Smart Classes Security</div>
        <h1 style="margin:2px 0 0;font-family:'Manrope',sans-serif;font-size:22px;">Admin 2-Step Verification</h1>
      </div>
    </div>
    <p style="margin:0 0 16px;font-size:13.5px;color:#52687c;">Enter the 6-digit numeric OTP sent from <code>No-reply@yuitor.com</code> to <strong><?php echo e(mask_email($destEmail)); ?></strong>.</p>
    <?php if ($msg !== ''): ?><div class="yu-alert yu-alert-success" style="display:flex;align-items:center;gap:8px;"><?php echo yu_icon('check', 16); ?> <span><?php echo e($msg); ?></span></div><?php endif; ?>
    <?php if ($err !== ''): ?><div class="yu-alert yu-alert-danger" style="display:flex;align-items:center;gap:8px;"><?php echo yu_icon('alert', 16); ?> <span><?php echo e($err); ?></span></div><?php endif; ?>
    <form method="post">
      <?php echo csrf_field(); ?>
      <div class="yu-field" style="margin-bottom:14px;">
        <label for="otpCode" style="display:flex;align-items:center;gap:6px;"><?php echo yu_icon('shield', 14); ?> 6-Digit OTP Code</label>
        <input id="otpCode" type="text" name="otp_code" maxlength="6" pattern="\d{6}" inputmode="numeric" required placeholder="000000" style="font-size:22px;letter-spacing:8px;text-align:center;font-weight:800;">
      </div>
      <button type="submit" class="yu-btn yu-btn-primary" style="width:100%;padding:12px;"><?php echo yu_icon('check', 16); ?> Verify &amp; Open Admin Panel</button>
    </form>
    <form method="post" style="margin-top:12px;display:flex;justify-content:space-between;align-items:center;">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="resend" value="1">
      <button type="submit" class="yu-btn yu-btn-outline yu-btn-sm"><?php echo yu_icon('mail', 14); ?> Resend OTP</button>
      <a href="<?php echo e(erp_url('index.php')); ?>" style="font-size:13px;color:#52687c;">Back to Sign In</a>
    </form>
  </div>
</div>
<?php include __DIR__ . '/includes/site_footer.php'; ?>
