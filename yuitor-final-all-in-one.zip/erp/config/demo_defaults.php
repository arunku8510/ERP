<?php
// Yuitor Smart Classes - Centralized Environment & Official Domain Config Loader

if (!function_exists('yu_load_env_file')) {
    function yu_load_env_file(): array {
        static $loaded = null;
        if ($loaded !== null) {
            return $loaded;
        }
        $loaded = [];
        $candidates = [
            dirname(__DIR__, 2) . '/.env',
            dirname(__DIR__) . '/.env',
        ];
        foreach ($candidates as $envPath) {
            if (!is_file($envPath) || !is_readable($envPath)) {
                continue;
            }
            $lines = @file($envPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            if (!is_array($lines)) {
                continue;
            }
            foreach ($lines as $line) {
                $line = trim($line);
                if ($line === '' || $line[0] === '#' || strpos($line, '=') === false) {
                    continue;
                }
                list($k, $v) = explode('=', $line, 2);
                $k = trim($k);
                $v = trim($v);
                if (strlen($v) >= 2 && (($v[0] === '"' && substr($v, -1) === '"') || ($v[0] === "'" && substr($v, -1) === "'"))) {
                    $v = substr($v, 1, -1);
                }
                if ($k !== '' && !isset($loaded[$k])) {
                    $loaded[$k] = $v;
                }
            }
        }
        return $loaded;
    }
}

if (!function_exists('yu_env')) {
    function yu_env(string $key, string $default = ''): string {
        $val = getenv($key);
        if ($val !== false && trim((string) $val) !== '') {
            return trim((string) $val);
        }
        if (isset($_ENV[$key]) && trim((string) $_ENV[$key]) !== '') {
            return trim((string) $_ENV[$key]);
        }
        $fileEnv = yu_load_env_file();
        if (isset($fileEnv[$key]) && trim((string) $fileEnv[$key]) !== '') {
            return trim((string) $fileEnv[$key]);
        }
        return $default;
    }
}

if (!function_exists('yu_normalize_sender_email')) {
    function yu_normalize_sender_email(string $email): string {
        $email = trim($email);
        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return 'No-reply@yuitor.com';
        }
        $domain = strtolower((string) substr(strrchr($email, '@') ?: '', 1));
        if ($domain === 'example.com' || $domain === 'example.org' || $domain === 'example.net' || $domain === 'localhost') {
            return 'No-reply@yuitor.com';
        }
        return $email;
    }
}

define('YU_MAIL_DOMAIN', yu_env('MAIL_DOMAIN', 'yuitor.com'));
define('YU_MAIL_FROM_EMAIL', yu_normalize_sender_email(yu_env('MAIL_FROM_EMAIL', yu_env('YU_MAIL_FROM_EMAIL', 'No-reply@yuitor.com'))));
define('YU_MAIL_FROM_NAME', yu_env('MAIL_FROM_NAME', 'Yuitor Smart Classes'));

define('YU_INSTITUTE_EMAIL', yu_normalize_sender_email(yu_env('YU_INSTITUTE_EMAIL', 'admission@yuitor.com')));
define('YU_INQUIRY_EMAIL', yu_normalize_sender_email(yu_env('YU_INQUIRY_EMAIL', 'inquiry@yuitor.com')));
define('YU_DEMO_EMAIL', YU_INSTITUTE_EMAIL);
define('YU_DEMO_NOREPLY', YU_MAIL_FROM_EMAIL);
define('YU_DEMO_ADMIN_EMAIL', yu_normalize_sender_email(yu_env('YU_ADMIN_EMAIL', 'No-reply@yuitor.com')));
define('YU_DEMO_PHONE', yu_env('YU_INSTITUTE_PHONE', '+91-7827289292'));
define('YU_DEMO_BRANCH_PHONE', yu_env('YU_BRANCH_PHONE', '+91-1232314337'));
define('YU_DEMO_ADDRESS', yu_env('YU_INSTITUTE_ADDRESS', 'Trimurti Vihar, near Venus Academy, Muradnagar - 201206'));
define('YU_DEMO_UPI_PRIMARY', yu_env('YU_UPI_PRIMARY', 'Yuitor@ybl'));
define('YU_DEMO_UPI_ALT', yu_env('YU_UPI_ALT', 'Yuitor@icicibank'));
define('YU_GEMINI_API_KEY', yu_env('GEMINI_API_KEY', ''));
define('YU_GEMINI_MODEL', yu_env('GEMINI_MODEL', 'gemini-2.5-flash'));
